"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  BarChart3,
  Box,
  CreditCard,
  FileText,
  Home,
  LayoutDashboard,
  Package,
  Settings,
  ShoppingCart,
  Users,
} from "lucide-react"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export default function Sidebar({ className }: SidebarProps) {
  const pathname = usePathname()
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Skip rendering sidebar on login page
  if (pathname === "/login") {
    return null
  }

  const sidebarItems = [
    {
      title: "Dashboard",
      href: "/",
      icon: <Home className="h-5 w-5" />,
    },
    {
      title: "Inventar",
      href: "/inventory",
      icon: <Package className="h-5 w-5" />,
      submenu: [
        {
          title: "Übersicht",
          href: "/inventory",
        },
        {
          title: "Produkte",
          href: "/inventory/products",
        },
      ],
    },
    {
      title: "Verkauf",
      href: "/sales",
      icon: <ShoppingCart className="h-5 w-5" />,
      submenu: [
        {
          title: "Übersicht",
          href: "/sales",
        },
        {
          title: "Aufträge",
          href: "/sales/orders",
        },
        {
          title: "Kunden",
          href: "/sales/customers",
        },
      ],
    },
    {
      title: "Finanzen",
      href: "/finance",
      icon: <CreditCard className="h-5 w-5" />,
      submenu: [
        {
          title: "Übersicht",
          href: "/finance",
        },
        {
          title: "Transaktionen",
          href: "/finance/transactions",
        },
      ],
    },
    {
      title: "Personal",
      href: "/hr",
      icon: <Users className="h-5 w-5" />,
      submenu: [
        {
          title: "Übersicht",
          href: "/hr",
        },
        {
          title: "Mitarbeiter",
          href: "/hr/employees",
        },
      ],
    },
    {
      title: "Projekte",
      href: "/projects",
      icon: <LayoutDashboard className="h-5 w-5" />,
      submenu: [
        {
          title: "Übersicht",
          href: "/projects",
        },
        {
          title: "Projektliste",
          href: "/projects/overview",
        },
      ],
    },
    {
      title: "Berichte",
      href: "/reports",
      icon: <BarChart3 className="h-5 w-5" />,
    },
    {
      title: "Dokumente",
      href: "/documents",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      title: "Einstellungen",
      href: "/settings",
      icon: <Settings className="h-5 w-5" />,
    },
  ]

  // Find active parent menu
  const activeParent = sidebarItems.find(
    (item) => pathname === item.href || (item.submenu && item.submenu.some((subitem) => pathname === subitem.href)),
  )

  return (
    <div className={cn("pb-12", className)}>
      <div className="py-4">
        <div className="px-3 py-2">
          {isMobile ? (
            <div className="hidden">{/* Mobile menu is handled in the header */}</div>
          ) : (
            <div className="space-y-1">
              {sidebarItems.map((item) => (
                <div key={item.href} className="mb-2">
                  <Link href={item.href} passHref>
                    <Button
                      variant={pathname === item.href || activeParent === item ? "secondary" : "ghost"}
                      className={cn(
                        "w-full justify-start",
                        (pathname === item.href || activeParent === item) && "font-bold",
                      )}
                    >
                      {item.icon}
                      <span className="ml-2">{item.title}</span>
                    </Button>
                  </Link>

                  {item.submenu && activeParent === item && (
                    <div className="ml-6 mt-1 space-y-1">
                      {item.submenu.map((subitem) => (
                        <Link key={subitem.href} href={subitem.href} passHref>
                          <Button
                            variant={pathname === subitem.href ? "secondary" : "ghost"}
                            size="sm"
                            className={cn("w-full justify-start", pathname === subitem.href && "font-medium")}
                          >
                            <Box className="mr-2 h-4 w-4" />
                            {subitem.title}
                          </Button>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

