"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useData } from "@/contexts/data-context"

// Sample sales data
const initialSales = [
  {
    id: "ORD001",
    customer: "Acme Corp",
    date: "2023-03-15",
    items: 5,
    total: 1299.95,
    status: "Delivered",
  },
  {
    id: "ORD002",
    customer: "TechStart Inc",
    date: "2023-03-14",
    items: 2,
    total: 599.98,
    status: "Processing",
  },
]

// Sample customers data
const initialCustomers = [
  {
    id: "CUS001",
    name: "Acme Corp",
    email: "contact@acmecorp.com",
    phone: "+1 234 567 890",
    orders: 12,
    spent: 15499.95,
    status: "Active",
  },
]

export default function SalesPage() {
  const { loading } = useData()
  const [activeTab, setActiveTab] = useState("orders")
  const [sales] = useState(initialSales)
  const [customersList] = useState(initialCustomers)

  // Calculate summary data
  const totalSales = sales.reduce((sum, order) => sum + order.total, 0)
  const totalCustomers = customersList.length
  const activeCustomers = customersList.filter((c) => c.status === "Active").length

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Sales Management</h1>
      </div>

      <Tabs defaultValue="orders" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
        </TabsList>

        <div className="grid gap-4 md:grid-cols-3">
          {activeTab === "orders" && (
            <>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{sales.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{totalSales.toFixed(2)}</div>
                </CardContent>
              </Card>
            </>
          )}

          {activeTab === "customers" && (
            <>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalCustomers}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Customers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{activeCustomers}</div>
                  <p className="text-xs text-muted-foreground">
                    {Math.round((activeCustomers / totalCustomers) * 100)}% of total
                  </p>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <TabsContent value="orders" className="space-y-4">
          <div className="p-4 border rounded-md">
            <h3 className="font-medium mb-2">Orders List</h3>
            <ul className="space-y-2">
              {sales.map((order) => (
                <li key={order.id} className="p-2 bg-muted rounded-md">
                  {order.id} - {order.customer} - €{order.total.toFixed(2)}
                </li>
              ))}
            </ul>
          </div>
        </TabsContent>

        <TabsContent value="customers" className="space-y-4">
          <div className="p-4 border rounded-md">
            <h3 className="font-medium mb-2">Customers List</h3>
            <ul className="space-y-2">
              {customersList.map((customer) => (
                <li key={customer.id} className="p-2 bg-muted rounded-md">
                  {customer.id} - {customer.name} - {customer.email}
                </li>
              ))}
            </ul>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

