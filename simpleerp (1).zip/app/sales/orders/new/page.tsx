"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useData } from "@/contexts/data-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Trash2, Plus, ArrowLeft } from "lucide-react"

export default function NewOrderPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { data, addItem } = useData()

  const customers = data?.customers || []
  const products = data?.products || []

  const [orderItems, setOrderItems] = useState<
    Array<{
      productId: string
      productName: string
      quantity: number
      price: number
      discount: number
      total: number
    }>
  >([])

  const [formData, setFormData] = useState({
    customer: "",
    date: new Date().toISOString().split("T")[0],
    dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    status: "Draft",
    paymentStatus: "Unpaid",
    notes: "",
  })

  const [selectedProduct, setSelectedProduct] = useState("")
  const [quantity, setQuantity] = useState(1)
  const [discount, setDiscount] = useState(0)

  // Calculate total order amount
  const orderTotal = orderItems.reduce((sum, item) => sum + item.total, 0)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleAddItem = () => {
    if (!selectedProduct || quantity <= 0) {
      toast({
        title: "Fehler",
        description: "Bitte wählen Sie ein Produkt und geben Sie eine gültige Menge ein.",
        variant: "destructive",
      })
      return
    }

    const product = products.find((p) => p.id === selectedProduct)
    if (!product) return

    const price = product.price
    const itemDiscount = Math.min(discount, price * quantity)
    const total = price * quantity - itemDiscount

    const newItem = {
      productId: product.id,
      productName: product.name,
      quantity,
      price,
      discount: itemDiscount,
      total,
    }

    setOrderItems([...orderItems, newItem])
    setSelectedProduct("")
    setQuantity(1)
    setDiscount(0)
  }

  const handleRemoveItem = (index: number) => {
    setOrderItems(orderItems.filter((_, i) => i !== index))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.customer) {
      toast({
        title: "Fehler",
        description: "Bitte wählen Sie einen Kunden aus.",
        variant: "destructive",
      })
      return
    }

    if (orderItems.length === 0) {
      toast({
        title: "Fehler",
        description: "Bitte fügen Sie mindestens ein Produkt hinzu.",
        variant: "destructive",
      })
      return
    }

    try {
      const customer = customers.find((c) => c.id === formData.customer)

      const newOrder = {
        id: `SO${Date.now().toString().slice(-6)}`,
        customer: formData.customer,
        customerName: customer ? customer.name : "Unbekannter Kunde",
        date: formData.date,
        dueDate: formData.dueDate,
        items: orderItems,
        total: orderTotal,
        status: formData.status,
        paymentStatus: formData.paymentStatus,
        notes: formData.notes,
      }

      if (typeof addItem === "function") {
        addItem("salesOrders", newOrder)

        toast({
          title: "Auftrag erstellt",
          description: `Auftrag ${newOrder.id} wurde erfolgreich erstellt.`,
        })

        router.push("/sales/orders")
      } else {
        throw new Error("addItem function is not available")
      }
    } catch (error) {
      console.error("Error creating order:", error)
      toast({
        title: "Fehler",
        description: "Beim Erstellen des Auftrags ist ein Fehler aufgetreten.",
        variant: "destructive",
      })
    }
  }

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString("de-DE", {
      style: "currency",
      currency: "EUR",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => router.push("/sales/orders")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold tracking-tight">Neuer Auftrag</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Auftragsdetails</CardTitle>
              <CardDescription>Grundlegende Informationen zum Auftrag</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="customer">Kunde *</Label>
                <Select value={formData.customer} onValueChange={(value) => handleSelectChange("customer", value)}>
                  <SelectTrigger id="customer">
                    <SelectValue placeholder="Kunden auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.id}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="date">Auftragsdatum *</Label>
                  <Input id="date" name="date" type="date" value={formData.date} onChange={handleChange} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dueDate">Fälligkeitsdatum *</Label>
                  <Input
                    id="dueDate"
                    name="dueDate"
                    type="date"
                    value={formData.dueDate}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="status">Status *</Label>
                  <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Status auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Draft">Entwurf</SelectItem>
                      <SelectItem value="Processing">In Bearbeitung</SelectItem>
                      <SelectItem value="Shipped">Versendet</SelectItem>
                      <SelectItem value="Delivered">Geliefert</SelectItem>
                      <SelectItem value="Cancelled">Storniert</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="paymentStatus">Zahlungsstatus *</Label>
                  <Select
                    value={formData.paymentStatus}
                    onValueChange={(value) => handleSelectChange("paymentStatus", value)}
                  >
                    <SelectTrigger id="paymentStatus">
                      <SelectValue placeholder="Zahlungsstatus auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Unpaid">Unbezahlt</SelectItem>
                      <SelectItem value="Partial">Teilweise bezahlt</SelectItem>
                      <SelectItem value="Paid">Bezahlt</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notizen</Label>
                <Textarea id="notes" name="notes" value={formData.notes} onChange={handleChange} rows={4} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Produkte hinzufügen</CardTitle>
              <CardDescription>Fügen Sie Produkte zum Auftrag hinzu</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="product">Produkt</Label>
                <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                  <SelectTrigger id="product">
                    <SelectValue placeholder="Produkt auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name} - {formatCurrency(product.price)} ({product.quantity} auf Lager)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Menge</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(Number.parseInt(e.target.value) || 1)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="discount">Rabatt (€)</Label>
                  <Input
                    id="discount"
                    type="number"
                    min="0"
                    step="0.01"
                    value={discount}
                    onChange={(e) => setDiscount(Number.parseFloat(e.target.value) || 0)}
                  />
                </div>
              </div>

              <Button type="button" onClick={handleAddItem} className="w-full">
                <Plus className="mr-2 h-4 w-4" />
                Produkt hinzufügen
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Auftragspositionen</CardTitle>
            <CardDescription>Übersicht der Produkte im Auftrag</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Produkt</TableHead>
                    <TableHead className="text-right">Preis</TableHead>
                    <TableHead className="text-right">Menge</TableHead>
                    <TableHead className="text-right">Rabatt</TableHead>
                    <TableHead className="text-right">Gesamt</TableHead>
                    <TableHead className="text-right">Aktionen</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orderItems.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        Keine Produkte hinzugefügt
                      </TableCell>
                    </TableRow>
                  ) : (
                    orderItems.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell>{item.productName}</TableCell>
                        <TableCell className="text-right">{formatCurrency(item.price)}</TableCell>
                        <TableCell className="text-right">{item.quantity}</TableCell>
                        <TableCell className="text-right">{formatCurrency(item.discount)}</TableCell>
                        <TableCell className="text-right font-medium">{formatCurrency(item.total)}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => handleRemoveItem(index)}>
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Entfernen</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                  <TableRow>
                    <TableCell colSpan={4} className="text-right font-bold">
                      Gesamtbetrag:
                    </TableCell>
                    <TableCell className="text-right font-bold">{formatCurrency(orderTotal)}</TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={() => router.push("/sales/orders")}>
            Abbrechen
          </Button>
          <Button type="submit">Auftrag speichern</Button>
        </div>
      </form>
    </div>
  )
}

