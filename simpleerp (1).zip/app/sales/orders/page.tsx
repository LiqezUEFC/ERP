"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { useData } from "@/contexts/data-context"
import { FileDown, Filter, Plus, Search, Trash } from "lucide-react"

export default function OrdersPage() {
  const { salesOrders = [], deleteSalesOrder, isLoading } = useData()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [paymentFilter, setPaymentFilter] = useState("all")

  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Lade Auftragsdaten...</h2>
          <p className="text-muted-foreground">Bitte warten Sie einen Moment.</p>
        </div>
      </div>
    )
  }

  // Filter orders
  const filteredOrders = salesOrders
    ? salesOrders.filter((order) => {
        if (!order) return false

        const matchesSearch =
          (order.id?.toLowerCase() || "").includes(searchTerm.toLowerCase()) ||
          (order.customerName?.toLowerCase() || "").includes(searchTerm.toLowerCase())
        const matchesStatus = statusFilter === "all" || order.status === statusFilter
        const matchesPayment = paymentFilter === "all" || order.paymentStatus === paymentFilter

        return matchesSearch && matchesStatus && matchesPayment
      })
    : []

  const handleDeleteOrder = (id: string) => {
    if (window.confirm("Sind Sie sicher, dass Sie diesen Auftrag löschen möchten?")) {
      if (typeof deleteSalesOrder === "function") {
        deleteSalesOrder(id)
        toast({
          title: "Auftrag gelöscht",
          description: "Der Auftrag wurde erfolgreich gelöscht.",
        })
      }
    }
  }

  const exportToCSV = () => {
    // Create CSV content
    const headers = ["ID", "Kunde", "Datum", "Fälligkeitsdatum", "Gesamtbetrag", "Status", "Zahlungsstatus"]
    const csvContent = [
      headers.join(","),
      ...filteredOrders.map((order) =>
        [
          order.id,
          `"${order.customerName}"`,
          order.date,
          order.dueDate,
          order.total,
          `"${order.status}"`,
          `"${order.paymentStatus}"`,
        ].join(","),
      ),
    ].join("\n")

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", "auftraege.csv")
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Export erfolgreich",
      description: "Die Auftragsdaten wurden als CSV-Datei exportiert.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Aufträge</h1>
          <p className="text-muted-foreground">Verwalten Sie Ihre Verkaufsaufträge.</p>
        </div>
        <div className="flex gap-2">
          <Button asChild>
            <Link href="/sales/orders/new">
              <Plus className="mr-2 h-4 w-4" />
              Auftrag hinzufügen
            </Link>
          </Button>
          <Button variant="outline" onClick={exportToCSV}>
            <FileDown className="mr-2 h-4 w-4" />
            Exportieren
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Auftragsliste</CardTitle>
          <CardDescription>
            Alle Verkaufsaufträge ({filteredOrders.length} von {salesOrders.length})
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-col gap-4 md:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Suchen nach Auftragsnummer oder Kunde..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <div className="w-[180px]">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle Status</SelectItem>
                    <SelectItem value="Draft">Entwurf</SelectItem>
                    <SelectItem value="Processing">In Bearbeitung</SelectItem>
                    <SelectItem value="Shipped">Versendet</SelectItem>
                    <SelectItem value="Delivered">Geliefert</SelectItem>
                    <SelectItem value="Cancelled">Storniert</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-[180px]">
                <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                  <SelectTrigger>
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Zahlung" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle Zahlungen</SelectItem>
                    <SelectItem value="Unpaid">Unbezahlt</SelectItem>
                    <SelectItem value="Partial">Teilweise bezahlt</SelectItem>
                    <SelectItem value="Paid">Bezahlt</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Auftragsnr.</TableHead>
                  <TableHead>Kunde</TableHead>
                  <TableHead>Datum</TableHead>
                  <TableHead className="text-right">Gesamtbetrag</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Zahlung</TableHead>
                  <TableHead className="text-right">Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.length > 0 ? (
                  filteredOrders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">
                        <Link href={`/sales/orders/${order.id}`} className="hover:underline">
                          {order.id}
                        </Link>
                      </TableCell>
                      <TableCell>{order.customerName}</TableCell>
                      <TableCell>{new Date(order.date).toLocaleDateString("de-DE")}</TableCell>
                      <TableCell className="text-right">
                        {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(order.total)}
                      </TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                            order.status === "Delivered"
                              ? "bg-green-100 text-green-800"
                              : order.status === "Processing"
                                ? "bg-blue-100 text-blue-800"
                                : order.status === "Shipped"
                                  ? "bg-purple-100 text-purple-800"
                                  : order.status === "Draft"
                                    ? "bg-gray-100 text-gray-800"
                                    : "bg-red-100 text-red-800"
                          }`}
                        >
                          {order.status === "Delivered"
                            ? "Geliefert"
                            : order.status === "Processing"
                              ? "In Bearbeitung"
                              : order.status === "Shipped"
                                ? "Versendet"
                                : order.status === "Draft"
                                  ? "Entwurf"
                                  : "Storniert"}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                            order.paymentStatus === "Paid"
                              ? "bg-green-100 text-green-800"
                              : order.paymentStatus === "Partial"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {order.paymentStatus === "Paid"
                            ? "Bezahlt"
                            : order.paymentStatus === "Partial"
                              ? "Teilweise bezahlt"
                              : "Unbezahlt"}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" asChild>
                            <Link href={`/sales/orders/${order.id}`}>
                              <Search className="h-4 w-4" />
                              <span className="sr-only">Details</span>
                            </Link>
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteOrder(order.id)}>
                            <Trash className="h-4 w-4" />
                            <span className="sr-only">Löschen</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      Keine Aufträge gefunden.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

