"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Search, FileText, Video, HelpCircle, Book, Lightbulb, ArrowRight, ExternalLink } from "lucide-react"

export default function HelpPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("faq")

  // FAQ-Daten
  const faqItems = [
    {
      question: "Wie füge ich ein neues Produkt hinzu?",
      answer:
        "Um ein neues Produkt hinzuzufügen, navigieren Sie zum Bereich 'Inventar' > 'Produkte'. Klicken Sie auf die Schaltfläche 'Produkt hinzufügen' und füllen Sie das Formular mit den Produktdetails aus. Klicken Sie auf 'Speichern', um das Produkt zu erstellen.",
    },
    {
      question: "Wie erstelle ich einen neuen Verkaufsauftrag?",
      answer:
        "Gehen Sie zum Bereich 'Verkauf' > 'Aufträge' und klicken Sie auf 'Auftrag erstellen'. Wählen Sie einen Kunden aus, fügen Sie Produkte hinzu und legen Sie die Mengen fest. Sie können auch Rabatte anwenden und den Zahlungsstatus festlegen, bevor Sie den Auftrag speichern.",
    },
    {
      question: "Wie kann ich den Bestand eines Produkts aktualisieren?",
      answer:
        "Sie können den Bestand eines Produkts auf zwei Arten aktualisieren: 1) Direkt über die Produktdetailseite unter 'Inventar' > 'Produkte', indem Sie auf 'Bearbeiten' klicken. 2) Durch Erstellen einer Bestandsanpassung unter 'Inventar' > 'Bestandsanpassungen'.",
    },
    {
      question: "Wie erstelle ich einen Bericht?",
      answer:
        "Navigieren Sie zum Bereich 'Berichte'. Wählen Sie den gewünschten Berichtstyp (Verkauf, Inventar, Finanzen oder Kunden) und den Zeitraum aus. Sie können den Bericht anzeigen, drucken oder als CSV-Datei exportieren.",
    },
    {
      question: "Wie füge ich einen neuen Benutzer hinzu?",
      answer:
        "Gehen Sie zu 'Einstellungen' > 'Benutzer' und klicken Sie auf 'Benutzer hinzufügen'. Füllen Sie die erforderlichen Informationen aus und weisen Sie die entsprechenden Berechtigungen zu. Der neue Benutzer erhält eine E-Mail mit Anmeldeinformationen.",
    },
    {
      question: "Wie kann ich eine Rechnung erstellen?",
      answer:
        "Rechnungen werden automatisch aus Verkaufsaufträgen generiert. Gehen Sie zu 'Verkauf' > 'Rechnungen' und klicken Sie auf 'Rechnung erstellen'. Wählen Sie einen bestehenden Auftrag aus oder erstellen Sie eine neue Rechnung von Grund auf.",
    },
    {
      question: "Wie kann ich Daten importieren?",
      answer:
        "In den meisten Modulen finden Sie eine 'Importieren'-Schaltfläche. Klicken Sie darauf und laden Sie eine CSV-Datei mit Ihren Daten hoch. Das System führt Sie durch den Prozess der Feldzuordnung und Datenvalidierung.",
    },
    {
      question: "Wie kann ich Daten exportieren?",
      answer:
        "In den meisten Modulen finden Sie eine 'Exportieren'-Schaltfläche. Klicken Sie darauf, um die Daten als CSV-Datei herunterzuladen. In den Berichten können Sie auch PDF-Exporte erstellen.",
    },
    {
      question: "Wie kann ich ein Backup meiner Daten erstellen?",
      answer:
        "Gehen Sie zu 'Einstellungen' > 'System' > 'Backup'. Klicken Sie auf 'Backup erstellen', um eine vollständige Sicherung Ihrer Daten zu erstellen. Sie können auch automatische Backups planen.",
    },
    {
      question: "Wie kann ich mein Passwort ändern?",
      answer:
        "Klicken Sie auf Ihren Benutzernamen in der oberen rechten Ecke und wählen Sie 'Profil'. Dort finden Sie die Option 'Passwort ändern'.",
    },
  ]

  // Tutorials-Daten
  const tutorials = [
    {
      title: "Erste Schritte mit EnterpriseERP",
      description: "Lernen Sie die Grundlagen des Systems kennen",
      icon: <Book className="h-8 w-8 text-blue-500" />,
      link: "/help/tutorials/getting-started",
    },
    {
      title: "Inventarverwaltung",
      description: "Produkte, Kategorien und Bestandsanpassungen verwalten",
      icon: <Package className="h-8 w-8 text-green-500" />,
      link: "/help/tutorials/inventory-management",
    },
    {
      title: "Verkaufsprozess",
      description: "Von der Anfrage bis zur Rechnung",
      icon: <ShoppingCart className="h-8 w-8 text-purple-500" />,
      link: "/help/tutorials/sales-process",
    },
    {
      title: "Finanzmanagement",
      description: "Transaktionen, Konten und Berichte",
      icon: <DollarSign className="h-8 w-8 text-yellow-500" />,
      link: "/help/tutorials/finance-management",
    },
    {
      title: "Projektmanagement",
      description: "Projekte und Aufgaben verwalten",
      icon: <Briefcase className="h-8 w-8 text-red-500" />,
      link: "/help/tutorials/project-management",
    },
    {
      title: "Berichterstellung",
      description: "Berichte erstellen und analysieren",
      icon: <BarChart3 className="h-8 w-8 text-indigo-500" />,
      link: "/help/tutorials/reporting",
    },
  ]

  // Video-Tutorials
  const videoTutorials = [
    {
      title: "Einführung in EnterpriseERP",
      duration: "5:32",
      thumbnail: "/placeholder.svg?height=120&width=200",
      link: "#video-intro",
    },
    {
      title: "Produkte und Inventar verwalten",
      duration: "8:45",
      thumbnail: "/placeholder.svg?height=120&width=200",
      link: "#video-inventory",
    },
    {
      title: "Verkaufsaufträge erstellen",
      duration: "6:18",
      thumbnail: "/placeholder.svg?height=120&width=200",
      link: "#video-sales",
    },
    {
      title: "Finanzberichte verstehen",
      duration: "7:22",
      thumbnail: "/placeholder.svg?height=120&width=200",
      link: "#video-finance",
    },
    {
      title: "Projekte und Aufgaben verwalten",
      duration: "9:10",
      thumbnail: "/placeholder.svg?height=120&width=200",
      link: "#video-projects",
    },
    {
      title: "Benutzer und Berechtigungen",
      duration: "4:55",
      thumbnail: "/placeholder.svg?height=120&width=200",
      link: "#video-users",
    },
  ]

  // Dokumentation
  const documentation = [
    {
      title: "Benutzerhandbuch",
      description: "Vollständige Dokumentation aller Funktionen",
      icon: <FileText className="h-8 w-8 text-blue-500" />,
      link: "/help/docs/user-manual",
    },
    {
      title: "Administrator-Handbuch",
      description: "Systemkonfiguration und -verwaltung",
      icon: <Settings className="h-8 w-8 text-red-500" />,
      link: "/help/docs/admin-manual",
    },
    {
      title: "API-Dokumentation",
      description: "Integration mit anderen Systemen",
      icon: <Code className="h-8 w-8 text-green-500" />,
      link: "/help/docs/api",
    },
    {
      title: "Datenmodell",
      description: "Struktur und Beziehungen der Daten",
      icon: <Database className="h-8 w-8 text-purple-500" />,
      link: "/help/docs/data-model",
    },
    {
      title: "Versionshinweise",
      description: "Neue Funktionen und Verbesserungen",
      icon: <ListChecks className="h-8 w-8 text-yellow-500" />,
      link: "/help/docs/release-notes",
    },
    {
      title: "Fehlerbehebung",
      description: "Häufige Probleme und Lösungen",
      icon: <AlertTriangle className="h-8 w-8 text-orange-500" />,
      link: "/help/docs/troubleshooting",
    },
  ]

  // Tipps und Tricks
  const tips = [
    {
      title: "Tastenkombinationen",
      description:
        "Arbeiten Sie schneller mit Tastenkombinationen: Strg+S zum Speichern, Strg+N für neue Einträge, Strg+F zum Suchen.",
      icon: <Keyboard className="h-8 w-8 text-blue-500" />,
    },
    {
      title: "Dashboard anpassen",
      description:
        "Passen Sie Ihr Dashboard an, indem Sie auf das Zahnrad-Symbol klicken und die gewünschten Widgets auswählen.",
      icon: <LayoutDashboard className="h-8 w-8 text-green-500" />,
    },
    {
      title: "Schnellsuche",
      description:
        "Drücken Sie '/' an beliebiger Stelle, um die globale Suche zu öffnen und schnell zu finden, was Sie brauchen.",
      icon: <Search className="h-8 w-8 text-purple-500" />,
    },
    {
      title: "Berichte planen",
      description:
        "Richten Sie geplante Berichte ein, die automatisch per E-Mail an Sie oder Ihr Team gesendet werden.",
      icon: <Clock className="h-8 w-8 text-yellow-500" />,
    },
    {
      title: "Massenaktionen",
      description:
        "Wählen Sie mehrere Einträge aus und verwenden Sie das Aktionsmenü für Massenbearbeitungen oder -löschungen.",
      icon: <ListChecks className="h-8 w-8 text-red-500" />,
    },
    {
      title: "Filter speichern",
      description:
        "Speichern Sie häufig verwendete Filter, indem Sie auf das Stern-Symbol neben der Filterleiste klicken.",
      icon: <Filter className="h-8 w-8 text-indigo-500" />,
    },
  ]

  // Filtere FAQ-Elemente basierend auf Suchbegriff
  const filteredFaq = faqItems.filter(
    (item) =>
      item.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Hilfe & Support</h1>
          <p className="text-muted-foreground">
            Finden Sie Antworten auf Ihre Fragen und lernen Sie, wie Sie EnterpriseERP optimal nutzen können.
          </p>
        </div>
        <Button variant="default">
          <HelpCircle className="mr-2 h-4 w-4" />
          Support kontaktieren
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Suchen Sie nach Hilfe, Tutorials oder Dokumentation..."
          className="pl-8"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <Tabs defaultValue="faq" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="faq" className="flex items-center gap-2">
            <HelpCircle className="h-4 w-4" />
            <span className="hidden sm:inline">FAQ</span>
          </TabsTrigger>
          <TabsTrigger value="tutorials" className="flex items-center gap-2">
            <Book className="h-4 w-4" />
            <span className="hidden sm:inline">Tutorials</span>
          </TabsTrigger>
          <TabsTrigger value="videos" className="flex items-center gap-2">
            <Video className="h-4 w-4" />
            <span className="hidden sm:inline">Videos</span>
          </TabsTrigger>
          <TabsTrigger value="docs" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span className="hidden sm:inline">Dokumentation</span>
          </TabsTrigger>
          <TabsTrigger value="tips" className="flex items-center gap-2">
            <Lightbulb className="h-4 w-4" />
            <span className="hidden sm:inline">Tipps & Tricks</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="faq" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Häufig gestellte Fragen</CardTitle>
              <CardDescription>Antworten auf die häufigsten Fragen zu EnterpriseERP</CardDescription>
            </CardHeader>
            <CardContent>
              {searchTerm && filteredFaq.length === 0 ? (
                <div className="text-center py-8">
                  <HelpCircle className="mx-auto h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-4 text-lg font-medium">Keine Ergebnisse gefunden</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Wir konnten keine FAQ-Einträge finden, die zu Ihrer Suche passen.
                  </p>
                  <Button variant="link" onClick={() => setSearchTerm("")}>
                    Suche zurücksetzen
                  </Button>
                </div>
              ) : (
                <Accordion type="single" collapsible className="w-full">
                  {(searchTerm ? filteredFaq : faqItems).map((item, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger>{item.question}</AccordionTrigger>
                      <AccordionContent>
                        <p className="text-muted-foreground">{item.answer}</p>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tutorials" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Schritt-für-Schritt-Tutorials</CardTitle>
              <CardDescription>
                Lernen Sie, wie Sie die verschiedenen Funktionen von EnterpriseERP nutzen können
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {tutorials.map((tutorial, index) => (
                  <Card key={index} className="overflow-hidden">
                    <CardHeader className="p-4">
                      <div className="flex items-start gap-4">
                        {tutorial.icon}
                        <div>
                          <CardTitle className="text-lg">{tutorial.title}</CardTitle>
                          <CardDescription>{tutorial.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <Button variant="link" className="px-0" asChild>
                        <a href={tutorial.link}>
                          Tutorial ansehen
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </a>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="videos" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Video-Tutorials</CardTitle>
              <CardDescription>Lernen Sie visuell mit unseren Video-Anleitungen</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {videoTutorials.map((video, index) => (
                  <Card key={index} className="overflow-hidden">
                    <div className="relative">
                      <img
                        src={video.thumbnail || "/placeholder.svg"}
                        alt={video.title}
                        className="w-full object-cover"
                        style={{ aspectRatio: "16/9" }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="rounded-full bg-black/50 p-3">
                          <Play className="h-6 w-6 text-white" />
                        </div>
                      </div>
                      <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                        {video.duration}
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-medium">{video.title}</h3>
                      <Button variant="link" className="px-0 mt-2" asChild>
                        <a href={video.link}>
                          Video ansehen
                          <ExternalLink className="ml-2 h-3 w-3" />
                        </a>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="docs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Dokumentation</CardTitle>
              <CardDescription>Ausführliche Dokumentation zu allen Aspekten von EnterpriseERP</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {documentation.map((doc, index) => (
                  <Card key={index} className="overflow-hidden">
                    <CardHeader className="p-4">
                      <div className="flex items-start gap-4">
                        {doc.icon}
                        <div>
                          <CardTitle className="text-lg">{doc.title}</CardTitle>
                          <CardDescription>{doc.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <Button variant="link" className="px-0" asChild>
                        <a href={doc.link}>
                          Dokumentation lesen
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </a>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tips" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tipps & Tricks</CardTitle>
              <CardDescription>Nützliche Hinweise, um Ihre Produktivität zu steigern</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {tips.map((tip, index) => (
                  <Card key={index} className="overflow-hidden">
                    <CardHeader className="p-4">
                      <div className="flex items-start gap-4">
                        {tip.icon}
                        <div>
                          <CardTitle className="text-lg">{tip.title}</CardTitle>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <p className="text-sm text-muted-foreground">{tip.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Noch Fragen?</CardTitle>
          <CardDescription>
            Wenn Sie weitere Unterstützung benötigen, kontaktieren Sie unser Support-Team
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardContent className="p-6 flex flex-col items-center text-center">
                <Mail className="h-10 w-10 text-blue-500 mb-4" />
                <h3 className="font-medium text-lg mb-2">E-Mail Support</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Senden Sie uns eine E-Mail und wir antworten innerhalb von 24 Stunden.
                </p>
                <Button variant="outline" className="w-full">
                  support@enterprise-erp.de
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 flex flex-col items-center text-center">
                <Phone className="h-10 w-10 text-green-500 mb-4" />
                <h3 className="font-medium text-lg mb-2">Telefon-Support</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Rufen Sie uns an für sofortige Unterstützung während der Geschäftszeiten.
                </p>
                <Button variant="outline" className="w-full">
                  +49 123 456 7890
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 flex flex-col items-center text-center">
                <MessageSquare className="h-10 w-10 text-purple-500 mb-4" />
                <h3 className="font-medium text-lg mb-2">Live-Chat</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Chatten Sie mit einem Support-Mitarbeiter in Echtzeit.
                </p>
                <Button className="w-full">Chat starten</Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-4">
            <p className="text-sm text-muted-foreground">
              Unser Support-Team ist Montag bis Freitag von 9:00 bis 17:00 Uhr für Sie da.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Fehlende Icons
function Package(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m16.5 9.4-9-5.19M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
      <polyline points="3.29 7 12 12 20.71 7" />
      <line x1="12" x2="12" y1="22" y2="12" />
    </svg>
  )
}

function ShoppingCart(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="8" cy="21" r="1" />
      <circle cx="19" cy="21" r="1" />
      <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
    </svg>
  )
}

function DollarSign(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="12" x2="12" y1="2" y2="22" />
      <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
    </svg>
  )
}

function Briefcase(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="14" x="2" y="7" rx="2" ry="2" />
      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
    </svg>
  )
}

function BarChart3(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 3v18h18" />
      <path d="M18 17V9" />
      <path d="M13 17V5" />
      <path d="M8 17v-3" />
    </svg>
  )
}

function Settings(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

function Code(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="16 18 22 12 16 6" />
      <polyline points="8 6 2 12 8 18" />
    </svg>
  )
}

function Database(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <ellipse cx="12" cy="5" rx="9" ry="3" />
      <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
      <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
    </svg>
  )
}

function ListChecks(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m3 7 3 3 3-3" />
      <path d="M6 10V5" />
      <line x1="12" x2="21" y1="7" y2="7" />
      <path d="m3 17 3 3 3-3" />
      <path d="M6 20v-5" />
      <line x1="12" x2="21" y1="17" y2="17" />
    </svg>
  )
}

function AlertTriangle(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
      <path d="M12 9v4" />
      <path d="M12 17h.01" />
    </svg>
  )
}

function Keyboard(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="16" x="2" y="4" rx="2" ry="2" />
      <path d="M6 8h.001" />
      <path d="M10 8h.001" />
      <path d="M14 8h.001" />
      <path d="M18 8h.001" />
      <path d="M8 12h.001" />
      <path d="M12 12h.001" />
      <path d="M16 12h.001" />
      <path d="M7 16h10" />
    </svg>
  )
}

function LayoutDashboard(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="7" height="9" x="3" y="3" rx="1" />
      <rect width="7" height="5" x="14" y="3" rx="1" />
      <rect width="7" height="9" x="14" y="12" rx="1" />
      <rect width="7" height="5" x="3" y="16" rx="1" />
    </svg>
  )
}

function Clock(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  )
}

function Play(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polygon points="5 3 19 12 5 21 5 3" />
    </svg>
  )
}

function Phone(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
    </svg>
  )
}

function Mail(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="16" x="2" y="4" rx="2" />
      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
    </svg>
  )
}

function MessageSquare(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  )
}

