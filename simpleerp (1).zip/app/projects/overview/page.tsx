"use client"

import { useState } from "react"
import { useData, type Project } from "@/contexts/data-context"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Plus, Search, Filter, Download, Upload } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { format } from "date-fns"
import { de } from "date-fns/locale"

export default function ProjectsOverviewPage() {
  const { data, loading: isLoading } = useData()

  // Use default empty arrays to prevent "undefined" errors
  const projects = data?.projects || []
  const tasks = data?.tasks || []
  const employees = data?.employees || []
  const customers = data?.customers || []

  // Create wrapper functions that handle the data safely
  const addProject = (project) => {
    if (data) {
      data.addItem("projects", { id: `PRJ-${Date.now()}`, ...project })
    }
  }

  const updateProject = (id, project) => {
    if (data) {
      data.updateItem("projects", id, project)
    }
  }

  const deleteProject = (id) => {
    if (data) {
      data.deleteItem("projects", id)
    }
  }

  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [currentProject, setCurrentProject] = useState<Project | null>(null)

  const [newProject, setNewProject] = useState<Omit<Project, "id">>({
    name: "",
    description: "",
    startDate: new Date().toISOString().split("T")[0],
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    status: "Not Started",
    budget: 0,
    manager: "",
    client: "",
    team: [],
  })

  // Apply filters
  const filteredProjects = projects.filter((project) => {
    const matchesSearch =
      project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.id.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = !statusFilter || project.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const handleAddProject = () => {
    if (!newProject.manager || !newProject.client) {
      alert("Bitte wählen Sie einen Projektleiter und einen Kunden aus.")
      return
    }

    addProject(newProject)

    // Reset form
    setNewProject({
      name: "",
      description: "",
      startDate: new Date().toISOString().split("T")[0],
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      status: "Not Started",
      budget: 0,
      manager: "",
      client: "",
      team: [],
    })

    setIsAddDialogOpen(false)
  }

  const handleEditProject = () => {
    if (currentProject) {
      updateProject(currentProject.id, currentProject)
      setIsEditDialogOpen(false)
    }
  }

  const handleDeleteProject = () => {
    if (currentProject) {
      deleteProject(currentProject.id)
      setIsDeleteDialogOpen(false)
    }
  }

  const openEditDialog = (project: Project) => {
    setCurrentProject({ ...project })
    setIsEditDialogOpen(true)
  }

  const openDeleteDialog = (project: Project) => {
    setCurrentProject(project)
    setIsDeleteDialogOpen(true)
  }

  const openViewDialog = (project: Project) => {
    setCurrentProject(project)
    setIsViewDialogOpen(true)
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd.MM.yyyy", { locale: de })
    } catch (error) {
      return dateString
    }
  }

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString("de-DE", {
      style: "currency",
      currency: "EUR",
    })
  }

  const getProjectProgress = (projectId: string) => {
    const projectTasks = tasks.filter((task) => task.projectId === projectId)
    if (projectTasks.length === 0) return 0

    const completedTasks = projectTasks.filter((task) => task.status === "Completed").length
    return Math.round((completedTasks / projectTasks.length) * 100)
  }

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "Not Started":
        return "bg-gray-100 text-gray-800 hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-300"
      case "In Progress":
        return "bg-blue-100 text-blue-800 hover:bg-blue-100 dark:bg-blue-900 dark:text-blue-300"
      case "On Hold":
        return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-300"
      case "Completed":
        return "bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300"
      case "Cancelled":
        return "bg-red-100 text-red-800 hover:bg-red-100 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const getStatusTranslation = (status: string) => {
    switch (status) {
      case "Not Started":
        return "Nicht begonnen"
      case "In Progress":
        return "In Bearbeitung"
      case "On Hold":
        return "Pausiert"
      case "Completed":
        return "Abgeschlossen"
      case "Cancelled":
        return "Abgebrochen"
      default:
        return status
    }
  }

  // Calculate summary data
  const totalProjects = projects.length
  const activeProjects = projects.filter((p) => p.status === "In Progress").length
  const completedProjects = projects.filter((p) => p.status === "Completed").length
  const delayedProjects = projects.filter((p) => {
    const today = new Date()
    const endDate = new Date(p.endDate)
    return p.status !== "Completed" && p.status !== "Cancelled" && endDate < today
  }).length

  if (isLoading || !data) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-24" />
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Skeleton className="h-10 flex-1 md:max-w-sm" />
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
        <Skeleton className="h-[500px] w-full" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Projektübersicht</h1>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Projekt erstellen
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Neues Projekt erstellen</DialogTitle>
              <DialogDescription>Geben Sie die Details des neuen Projekts ein.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Projektname</Label>
                <Input
                  id="name"
                  value={newProject.name}
                  onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Beschreibung</Label>
                <Textarea
                  id="description"
                  value={newProject.description}
                  onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Startdatum</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={newProject.startDate}
                    onChange={(e) => setNewProject({ ...newProject, startDate: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endDate">Enddatum</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={newProject.endDate}
                    onChange={(e) => setNewProject({ ...newProject, endDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={newProject.status}
                    onValueChange={(value) => setNewProject({ ...newProject, status: value as any })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Status auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Not Started">Nicht begonnen</SelectItem>
                      <SelectItem value="In Progress">In Bearbeitung</SelectItem>
                      <SelectItem value="On Hold">Pausiert</SelectItem>
                      <SelectItem value="Completed">Abgeschlossen</SelectItem>
                      <SelectItem value="Cancelled">Abgebrochen</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="budget">Budget (€)</Label>
                  <Input
                    id="budget"
                    type="number"
                    value={newProject.budget}
                    onChange={(e) => setNewProject({ ...newProject, budget: Number.parseFloat(e.target.value) || 0 })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="manager">Projektleiter</Label>
                  <Select
                    value={newProject.manager}
                    onValueChange={(value) => setNewProject({ ...newProject, manager: value })}
                  >
                    <SelectTrigger id="manager">
                      <SelectValue placeholder="Projektleiter auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((employee) => (
                        <SelectItem key={employee.id} value={employee.id}>
                          {employee.name} ({employee.position})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="client">Kunde</Label>
                  <Select
                    value={newProject.client}
                    onValueChange={(value) => setNewProject({ ...newProject, client: value })}
                  >
                    <SelectTrigger id="client">
                      <SelectValue placeholder="Kunde auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id}>
                          {customer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="team">Projektteam</Label>
                <Select
                  value={newProject.team[0] || ""}
                  onValueChange={(value) => {
                    const updatedTeam = [...newProject.team]
                    if (value && !updatedTeam.includes(value)) {
                      updatedTeam.push(value)
                    }
                    setNewProject({ ...newProject, team: updatedTeam })
                  }}
                >
                  <SelectTrigger id="team">
                    <SelectValue placeholder="Teammitglieder auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees
                      .filter((e) => !newProject.team.includes(e.id))
                      .map((employee) => (
                        <SelectItem key={employee.id} value={employee.id}>
                          {employee.name} ({employee.position})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>

                {newProject.team.length > 0 && (
                  <div className="mt-2 space-y-2">
                    <Label>Ausgewählte Teammitglieder</Label>
                    <div className="flex flex-wrap gap-2">
                      {newProject.team.map((memberId) => {
                        const member = employees.find((e) => e.id === memberId)
                        return (
                          <Badge key={memberId} className="flex items-center gap-1">
                            {member?.name || memberId}
                            <button
                              type="button"
                              onClick={() => {
                                const updatedTeam = newProject.team.filter((id) => id !== memberId)
                                setNewProject({ ...newProject, team: updatedTeam })
                              }}
                              className="ml-1 rounded-full hover:bg-primary/20"
                            >
                              ×
                            </button>
                          </Badge>
                        )
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Abbrechen
              </Button>
              <Button onClick={handleAddProject}>Projekt erstellen</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Alle Projekte</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalProjects}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Aktive Projekte</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{activeProjects}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Abgeschlossene Projekte</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{completedProjects}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Verzögerte Projekte</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{delayedProjects}</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1 md:max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Projekte suchen..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
                <span className="sr-only">Filter</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[200px]">
              <DropdownMenuLabel>Filter</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">Status</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setStatusFilter(null)}>Alle Status</DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setStatusFilter("Not Started")}
                className={statusFilter === "Not Started" ? "bg-muted" : ""}
              >
                Nicht begonnen
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setStatusFilter("In Progress")}
                className={statusFilter === "In Progress" ? "bg-muted" : ""}
              >
                In Bearbeitung
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setStatusFilter("On Hold")}
                className={statusFilter === "On Hold" ? "bg-muted" : ""}
              >
                Pausiert
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setStatusFilter("Completed")}
                className={statusFilter === "Completed" ? "bg-muted" : ""}
              >
                Abgeschlossen
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setStatusFilter("Cancelled")}
                className={statusFilter === "Cancelled" ? "bg-muted" : ""}
              >
                Abgebrochen
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Exportieren
          </Button>
          <Button variant="outline" size="sm">
            <Upload className="mr-2 h-4 w-4" />
            Importieren
          </Button>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Projektname</TableHead>
              <TableHead>Kunde</TableHead>
              <TableHead>Zeitraum</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Fortschritt</TableHead>
              <TableHead className="text-right">Aktionen</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProjects.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  Keine Projekte gefunden
                </TableCell>
              </TableRow>
            ) : (
              filteredProjects.map((project) => {
                const progress = getProjectProgress(project.id)
                const customer = customers.find((c) => c.id === project.client)

                return (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.id}</TableCell>
                    <TableCell>{project.name}</TableCell>
                    <TableCell>{customer ? customer.name : project.client}</TableCell>
                    <TableCell>
                      {formatDate(project.startDate)} - {formatDate(project.endDate)}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusBadgeClass(project.status)}>
                        {getStatusTranslation(project.status)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={progress} className="h-2 w-full" />
                        <span className="text-xs font-medium">{progress}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuContent align="end">
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              Aktionen
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuLabel>Aktionen</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => openViewDialog(project)}>Anzeigen</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openEditDialog(project)}>Bearbeiten</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openDeleteDialog(project)}>Löschen</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>

      {isViewDialogOpen && currentProject && (
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{currentProject.name}</DialogTitle>
              <DialogDescription>Details zu diesem Projekt anzeigen.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label>Projektname</Label>
                <p>{currentProject.name}</p>
              </div>
              <div className="space-y-2">
                <Label>Beschreibung</Label>
                <p>{currentProject.description}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Startdatum</Label>
                  <p>{formatDate(currentProject.startDate)}</p>
                </div>
                <div className="space-y-2">
                  <Label>Enddatum</Label>
                  <p>{formatDate(currentProject.endDate)}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Badge className={getStatusBadgeClass(currentProject.status)}>
                    {getStatusTranslation(currentProject.status)}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <Label>Budget</Label>
                  <p>{formatCurrency(currentProject.budget)}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Projektleiter</Label>
                  <p>{employees.find((e) => e.id === currentProject.manager)?.name}</p>
                </div>
                <div className="space-y-2">
                  <Label>Kunde</Label>
                  <p>{customers.find((c) => c.id === currentProject.client)?.name}</p>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Projektteam</Label>
                {currentProject.team.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {currentProject.team.map((memberId) => {
                      const member = employees.find((e) => e.id === memberId)
                      return (
                        <Badge key={memberId} className="flex items-center gap-1">
                          {member?.name || memberId}
                        </Badge>
                      )
                    })}
                  </div>
                ) : (
                  <p>Keine Teammitglieder ausgewählt.</p>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                Schließen
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {isEditDialogOpen && currentProject && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Projekt bearbeiten</DialogTitle>
              <DialogDescription>Ändern Sie die Details des Projekts.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Projektname</Label>
                <Input
                  id="name"
                  value={currentProject.name}
                  onChange={(e) => setCurrentProject({ ...currentProject, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Beschreibung</Label>
                <Textarea
                  id="description"
                  value={currentProject.description}
                  onChange={(e) => setCurrentProject({ ...currentProject, description: e.target.value })}
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Startdatum</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={currentProject.startDate}
                    onChange={(e) => setCurrentProject({ ...currentProject, startDate: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endDate">Enddatum</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={currentProject.endDate}
                    onChange={(e) => setCurrentProject({ ...currentProject, endDate: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={currentProject.status}
                    onValueChange={(value) => setCurrentProject({ ...currentProject, status: value as any })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Status auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Not Started">Nicht begonnen</SelectItem>
                      <SelectItem value="In Progress">In Bearbeitung</SelectItem>
                      <SelectItem value="On Hold">Pausiert</SelectItem>
                      <SelectItem value="Completed">Abgeschlossen</SelectItem>
                      <SelectItem value="Cancelled">Abgebrochen</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="budget">Budget (€)</Label>
                  <Input
                    id="budget"
                    type="number"
                    value={currentProject.budget}
                    onChange={(e) =>
                      setCurrentProject({ ...currentProject, budget: Number.parseFloat(e.target.value) || 0 })
                    }
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="manager">Projektleiter</Label>
                  <Select
                    value={currentProject.manager}
                    onValueChange={(value) => setCurrentProject({ ...currentProject, manager: value })}
                  >
                    <SelectTrigger id="manager">
                      <SelectValue placeholder="Projektleiter auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((employee) => (
                        <SelectItem key={employee.id} value={employee.id}>
                          {employee.name} ({employee.position})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="client">Kunde</Label>
                  <Select
                    value={currentProject.client}
                    onValueChange={(value) => setCurrentProject({ ...currentProject, client: value })}
                  >
                    <SelectTrigger id="client">
                      <SelectValue placeholder="Kunde auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers.map((customer) => (
                        <SelectItem key={customer.id} value={customer.id}>
                          {customer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="team">Projektteam</Label>
                <Select
                  value={currentProject.team[0] || ""}
                  onValueChange={(value) => {
                    const updatedTeam = [...currentProject.team]
                    if (value && !updatedTeam.includes(value)) {
                      updatedTeam.push(value)
                    }
                    setCurrentProject({ ...currentProject, team: updatedTeam })
                  }}
                >
                  <SelectTrigger id="team">
                    <SelectValue placeholder="Teammitglieder auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees
                      .filter((e) => !currentProject.team.includes(e.id))
                      .map((employee) => (
                        <SelectItem key={employee.id} value={employee.id}>
                          {employee.name} ({employee.position})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                {currentProject.team.length > 0 && (
                  <div className="mt-2 space-y-2">
                    <Label>Ausgewählte Teammitglieder</Label>
                    <div className="flex flex-wrap gap-2">
                      {currentProject.team.map((memberId) => {
                        const member = employees.find((e) => e.id === memberId)
                        return (
                          <Badge key={memberId} className="flex items-center gap-1">
                            {member?.name || memberId}
                            <button
                              type="button"
                              onClick={() => {
                                const updatedTeam = currentProject.team.filter((id) => id !== memberId)
                                setCurrentProject({ ...currentProject, team: updatedTeam })
                              }}
                              className="ml-1 rounded-full hover:bg-primary/20"
                            >
                              ×
                            </button>
                          </Badge>
                        )
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Abbrechen
              </Button>
              <Button onClick={handleEditProject}>Änderungen speichern</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {isDeleteDialogOpen && currentProject && (
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Projekt löschen</DialogTitle>
              <DialogDescription>
                Sind Sie sicher, dass Sie das Projekt "{currentProject.name}" löschen möchten?
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Abbrechen
              </Button>
              <Button variant="destructive" onClick={handleDeleteProject}>
                Projekt löschen
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

