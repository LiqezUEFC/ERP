"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useData } from "@/contexts/data-context"
import { BarChart3, Calendar, CheckCircle, Clock, Filter, Plus, Search } from "lucide-react"

export default function ProjectsPage() {
  const { projects = [], tasks = [], employees = [], customers = [], isLoading } = useData()
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  // Filter projects based on search term and active tab
  const filteredProjects = projects.filter((project) => {
    const matchesSearch =
      project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.id.toLowerCase().includes(searchTerm.toLowerCase())

    if (activeTab === "all") return matchesSearch
    if (activeTab === "active") return project.status === "In Progress" && matchesSearch
    if (activeTab === "completed") return project.status === "Completed" && matchesSearch
    if (activeTab === "upcoming") return project.status === "Not Started" && matchesSearch

    return false
  })

  // Calculate project statistics
  const totalProjects = projects.length
  const activeProjects = projects.filter((p) => p.status === "In Progress").length
  const completedProjects = projects.filter((p) => p.status === "Completed").length
  const upcomingProjects = projects.filter((p) => p.status === "Not Started").length

  // Calculate project progress
  const getProjectProgress = (projectId: string) => {
    const projectTasks = tasks.filter((task) => task.projectId === projectId)
    if (projectTasks.length === 0) return 0

    const completedTasks = projectTasks.filter((task) => task.status === "Completed").length
    return Math.round((completedTasks / projectTasks.length) * 100)
  }

  // Get project manager name
  const getManagerName = (managerId: string) => {
    const manager = employees.find((e) => e.id === managerId)
    return manager ? manager.name : "Nicht zugewiesen"
  }

  // Get client name
  const getClientName = (clientId: string) => {
    const client = customers.find((c) => c.id === clientId)
    return client ? client.name : "Nicht zugewiesen"
  }

  // Format date
  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString("de-DE")
    } catch (error) {
      return dateString
    }
  }

  // Get status badge class
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "Not Started":
        return "bg-gray-100 text-gray-800 hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-300"
      case "In Progress":
        return "bg-blue-100 text-blue-800 hover:bg-blue-100 dark:bg-blue-900 dark:text-blue-300"
      case "On Hold":
        return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-300"
      case "Completed":
        return "bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300"
      case "Cancelled":
        return "bg-red-100 text-red-800 hover:bg-red-100 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  // Get status translation
  const getStatusTranslation = (status: string) => {
    switch (status) {
      case "Not Started":
        return "Nicht begonnen"
      case "In Progress":
        return "In Bearbeitung"
      case "On Hold":
        return "Pausiert"
      case "Completed":
        return "Abgeschlossen"
      case "Cancelled":
        return "Abgebrochen"
      default:
        return status
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Lade Projektdaten...</h2>
          <p className="text-muted-foreground">Bitte warten Sie einen Moment.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Projekte</h1>
          <p className="text-muted-foreground">Verwalten Sie Ihre Projekte und Aufgaben</p>
        </div>
        <div className="flex gap-2">
          <Button asChild>
            <Link href="/projects/overview">
              <BarChart3 className="mr-2 h-4 w-4" />
              Projektübersicht
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/projects/new">
              <Plus className="mr-2 h-4 w-4" />
              Projekt erstellen
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alle Projekte</CardTitle>
            <Box className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalProjects}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aktive Projekte</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{activeProjects}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Abgeschlossene Projekte</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{completedProjects}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kommende Projekte</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{upcomingProjects}</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1 md:max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Projekte suchen..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
            <span className="sr-only">Filter</span>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">Alle Projekte</TabsTrigger>
          <TabsTrigger value="active">Aktive</TabsTrigger>
          <TabsTrigger value="completed">Abgeschlossen</TabsTrigger>
          <TabsTrigger value="upcoming">Kommende</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredProjects.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-8 text-center">
                <div className="mb-2 rounded-full bg-muted p-3">
                  <Search className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mb-1 text-lg font-medium">Keine Projekte gefunden</h3>
                <p className="text-sm text-muted-foreground">
                  Versuchen Sie, Ihre Suchkriterien zu ändern oder ein neues Projekt zu erstellen.
                </p>
              </div>
            ) : (
              filteredProjects.map((project) => {
                const progress = getProjectProgress(project.id)
                return (
                  <Card key={project.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{project.name}</CardTitle>
                          <CardDescription className="mt-1 line-clamp-2">{project.description}</CardDescription>
                        </div>
                        <Badge className={getStatusBadgeClass(project.status)}>
                          {getStatusTranslation(project.status)}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="mb-4 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Fortschritt</span>
                          <span className="font-medium">{progress}%</span>
                        </div>
                        <Progress value={progress} className="h-2" />
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Projektleiter</span>
                          <span>{getManagerName(project.manager)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Kunde</span>
                          <span>{getClientName(project.client)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Zeitraum</span>
                          <span>
                            {formatDate(project.startDate)} - {formatDate(project.endDate)}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="pt-2">
                      <Button asChild className="w-full">
                        <Link href={`/projects/${project.id}`}>Details anzeigen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                )
              })
            )}
          </div>
        </TabsContent>
        <TabsContent value="active" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredProjects.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-8 text-center">
                <div className="mb-2 rounded-full bg-muted p-3">
                  <Clock className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mb-1 text-lg font-medium">Keine aktiven Projekte</h3>
                <p className="text-sm text-muted-foreground">Es gibt derzeit keine aktiven Projekte.</p>
              </div>
            ) : (
              filteredProjects.map((project) => {
                const progress = getProjectProgress(project.id)
                return (
                  <Card key={project.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{project.name}</CardTitle>
                          <CardDescription className="mt-1 line-clamp-2">{project.description}</CardDescription>
                        </div>
                        <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 dark:bg-blue-900 dark:text-blue-300">
                          In Bearbeitung
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="mb-4 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Fortschritt</span>
                          <span className="font-medium">{progress}%</span>
                        </div>
                        <Progress value={progress} className="h-2" />
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Projektleiter</span>
                          <span>{getManagerName(project.manager)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Kunde</span>
                          <span>{getClientName(project.client)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Zeitraum</span>
                          <span>
                            {formatDate(project.startDate)} - {formatDate(project.endDate)}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="pt-2">
                      <Button asChild className="w-full">
                        <Link href={`/projects/${project.id}`}>Details anzeigen</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                )
              })
            )}
          </div>
        </TabsContent>
        <TabsContent value="completed" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredProjects.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-8 text-center">
                <div className="mb-2 rounded-full bg-muted p-3">
                  <CheckCircle className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mb-1 text-lg font-medium">Keine abgeschlossenen Projekte</h3>
                <p className="text-sm text-muted-foreground">Es gibt derzeit keine abgeschlossenen Projekte.</p>
              </div>
            ) : (
              filteredProjects.map((project) => (
                <Card key={project.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{project.name}</CardTitle>
                        <CardDescription className="mt-1 line-clamp-2">{project.description}</CardDescription>
                      </div>
                      <Badge className="bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300">
                        Abgeschlossen
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="mb-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Fortschritt</span>
                        <span className="font-medium">100%</span>
                      </div>
                      <Progress value={100} className="h-2" />
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Projektleiter</span>
                        <span>{getManagerName(project.manager)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Kunde</span>
                        <span>{getClientName(project.client)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Zeitraum</span>
                        <span>
                          {formatDate(project.startDate)} - {formatDate(project.endDate)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2">
                    <Button asChild className="w-full">
                      <Link href={`/projects/${project.id}`}>Details anzeigen</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
        <TabsContent value="upcoming" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredProjects.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-8 text-center">
                <div className="mb-2 rounded-full bg-muted p-3">
                  <Calendar className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mb-1 text-lg font-medium">Keine kommenden Projekte</h3>
                <p className="text-sm text-muted-foreground">Es gibt derzeit keine kommenden Projekte.</p>
              </div>
            ) : (
              filteredProjects.map((project) => (
                <Card key={project.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{project.name}</CardTitle>
                        <CardDescription className="mt-1 line-clamp-2">{project.description}</CardDescription>
                      </div>
                      <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-300">
                        Nicht begonnen
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="mb-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Fortschritt</span>
                        <span className="font-medium">0%</span>
                      </div>
                      <Progress value={0} className="h-2" />
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Projektleiter</span>
                        <span>{getManagerName(project.manager)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Kunde</span>
                        <span>{getClientName(project.client)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Zeitraum</span>
                        <span>
                          {formatDate(project.startDate)} - {formatDate(project.endDate)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2">
                    <Button asChild className="w-full">
                      <Link href={`/projects/${project.id}`}>Details anzeigen</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function Box(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5" />
      <path d="M12 22V12" />
    </svg>
  )
}

