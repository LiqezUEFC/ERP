"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { useData } from "@/contexts/data-context"
import {
  BarChart3,
  CircleDollarSign,
  ClipboardList,
  Package,
  ShoppingCart,
  TrendingUp,
  Users,
  AlertCircle,
} from "lucide-react"

export default function DashboardPage() {
  const { data, loading } = useData()
  const [activeTab, setActiveTab] = useState("overview")

  if (loading || !data) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Lade Dashboard...</h2>
          <p className="text-muted-foreground">Bitte warten Sie einen Moment.</p>
        </div>
      </div>
    )
  }

  // Extract data
  const products = data.products || []
  const customers = data.customers || []
  const salesOrders = data.salesOrders || []
  const purchaseOrders = data.purchaseOrders || []
  const employees = data.employees || []
  const transactions = data.transactions || []

  // Calculate dashboard statistics
  const totalProducts = products.length
  const totalCustomers = customers.length
  const activeCustomers = customers.filter((c) => c.status === "Active").length
  const totalSales = salesOrders.reduce((sum, order) => sum + order.total, 0)
  const pendingSales = salesOrders.filter((o) => o.status === "Processing").length
  const lowStockProducts = products.filter((p) => p.status === "Low Stock" || p.status === "Out of Stock").length
  const pendingPurchases = purchaseOrders.filter((o) => o.status === "Ordered").length
  const activeEmployees = employees.filter((e) => e.status === "Active").length

  // Recent sales orders
  const recentSales = [...salesOrders]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5)

  // Recent transactions
  const recentTransactions = [...transactions]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5)

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Willkommen im EnterpriseERP-System. Hier finden Sie einen Überblick über Ihr Unternehmen.
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild>
            <Link href="/reports">Berichte anzeigen</Link>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 md:w-auto">
          <TabsTrigger value="overview">Übersicht</TabsTrigger>
          <TabsTrigger value="sales">Verkäufe</TabsTrigger>
          <TabsTrigger value="inventory">Inventar</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Gesamtumsatz</CardTitle>
                <CircleDollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(totalSales)}
                </div>
                <p className="text-xs text-muted-foreground">{salesOrders.length} Aufträge insgesamt</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Aktive Kunden</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activeCustomers}</div>
                <p className="text-xs text-muted-foreground">Von {totalCustomers} Kunden insgesamt</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Produkte</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalProducts}</div>
                <p className="text-xs text-muted-foreground">{lowStockProducts} mit niedrigem Bestand</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Offene Aufträge</CardTitle>
                <ClipboardList className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{pendingSales + pendingPurchases}</div>
                <p className="text-xs text-muted-foreground">
                  {pendingSales} Verkäufe, {pendingPurchases} Einkäufe
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Letzte Verkäufe</CardTitle>
                <CardDescription>Die 5 neuesten Verkaufsaufträge</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentSales.length > 0 ? (
                    <div className="rounded-md border">
                      <div className="grid grid-cols-4 border-b p-3 font-medium">
                        <div>Auftrag</div>
                        <div>Kunde</div>
                        <div>Datum</div>
                        <div>Betrag</div>
                      </div>
                      {recentSales.map((order) => (
                        <div key={order.id} className="grid grid-cols-4 items-center p-3">
                          <div className="font-medium">{order.id}</div>
                          <div>{order.customerName}</div>
                          <div>{new Date(order.date).toLocaleDateString("de-DE")}</div>
                          <div>
                            {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(order.total)}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-8 text-center">
                      <ShoppingCart className="mb-2 h-10 w-10 text-muted-foreground" />
                      <h3 className="mb-1 text-lg font-medium">Keine Verkäufe</h3>
                      <p className="text-sm text-muted-foreground">Es wurden noch keine Verkäufe getätigt.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Schnellzugriff</CardTitle>
                <CardDescription>Häufig verwendete Funktionen</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 grid-cols-2">
                  <Button className="h-auto flex-col items-center justify-center gap-2 p-4" variant="outline" asChild>
                    <Link href="/sales/orders/new">
                      <ShoppingCart className="h-8 w-8" />
                      <span>Neuer Verkauf</span>
                    </Link>
                  </Button>
                  <Button className="h-auto flex-col items-center justify-center gap-2 p-4" variant="outline" asChild>
                    <Link href="/inventory/products/new">
                      <Package className="h-8 w-8" />
                      <span>Neues Produkt</span>
                    </Link>
                  </Button>
                  <Button className="h-auto flex-col items-center justify-center gap-2 p-4" variant="outline" asChild>
                    <Link href="/sales/customers/new">
                      <Users className="h-8 w-8" />
                      <span>Neuer Kunde</span>
                    </Link>
                  </Button>
                  <Button className="h-auto flex-col items-center justify-center gap-2 p-4" variant="outline" asChild>
                    <Link href="/reports">
                      <BarChart3 className="h-8 w-8" />
                      <span>Berichte</span>
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Letzte Transaktionen</CardTitle>
              <CardDescription>Die 5 neuesten Finanztransaktionen</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTransactions.length > 0 ? (
                  <div className="rounded-md border">
                    <div className="grid grid-cols-5 border-b p-3 font-medium">
                      <div>ID</div>
                      <div>Datum</div>
                      <div>Beschreibung</div>
                      <div>Kategorie</div>
                      <div>Betrag</div>
                    </div>
                    {recentTransactions.map((transaction) => (
                      <div key={transaction.id} className="grid grid-cols-5 items-center p-3">
                        <div className="font-medium">{transaction.id}</div>
                        <div>{new Date(transaction.date).toLocaleDateString("de-DE")}</div>
                        <div>{transaction.description}</div>
                        <div>{transaction.category}</div>
                        <div className={transaction.type === "Income" ? "text-green-600" : "text-red-600"}>
                          {transaction.type === "Income" ? "+" : "-"}
                          {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(
                            transaction.amount,
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <TrendingUp className="mb-2 h-10 w-10 text-muted-foreground" />
                    <h3 className="mb-1 text-lg font-medium">Keine Transaktionen</h3>
                    <p className="text-sm text-muted-foreground">Es wurden noch keine Finanztransaktionen getätigt.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sales" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Verkaufsübersicht</CardTitle>
              <CardDescription>Übersicht über Ihre Verkäufe und Kunden</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <Button asChild>
                    <Link href="/sales/orders">Alle Verkäufe anzeigen</Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/sales/orders/new">+ Verkauf erstellen</Link>
                  </Button>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Gesamtumsatz</CardTitle>
                      <CircleDollarSign className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(totalSales)}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Aufträge</CardTitle>
                      <ClipboardList className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{salesOrders.length}</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Kunden</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{totalCustomers}</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Durchschnitt</CardTitle>
                      <BarChart3 className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(
                          salesOrders.length > 0 ? totalSales / salesOrders.length : 0,
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Inventarübersicht</CardTitle>
              <CardDescription>Übersicht über Ihre Produkte und Bestände</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <Button asChild>
                    <Link href="/inventory">Zum Inventar</Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/inventory/products/new">+ Produkt hinzufügen</Link>
                  </Button>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Produkte</CardTitle>
                      <Package className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{totalProducts}</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Niedriger Bestand</CardTitle>
                      <AlertCircle className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{lowStockProducts}</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Bestellungen</CardTitle>
                      <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{pendingPurchases}</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Mitarbeiter</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{activeEmployees}</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

