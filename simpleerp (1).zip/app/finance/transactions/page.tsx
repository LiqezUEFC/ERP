"use client"

import { useState } from "react"
import { useData, type Transaction } from "@/contexts/data-context"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Trash2,
  Download,
  Upload,
  FileText,
  TrendingUp,
  TrendingDown,
} from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { format } from "date-fns"
import { de } from "date-fns/locale"
import { useToast } from "@/components/ui/use-toast"

export default function TransactionsPage() {
  const {
    transactions = [],
    accounts = [],
    addTransaction,
    updateTransaction,
    deleteTransaction,
    isLoading = true,
  } = useData() || {}
  const { toast } = useToast()

  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string | null>(null)
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [currentTransaction, setCurrentTransaction] = useState<Transaction | null>(null)

  const [newTransaction, setNewTransaction] = useState<Omit<Transaction, "id">>({
    date: new Date().toISOString().split("T")[0],
    description: "",
    reference: "",
    type: "Expense",
    amount: 0,
    category: "",
    account: "",
    paymentMethod: "Überweisung",
    notes: "",
  })

  // Get unique categories for filter
  const incomeCategories = [
    ...new Set(
      (transactions || [])
        .filter((t) => t?.type === "Income")
        .map((t) => t?.category)
        .filter(Boolean),
    ),
  ]

  const expenseCategories = [
    ...new Set(
      (transactions || [])
        .filter((t) => t?.type === "Expense")
        .map((t) => t?.category)
        .filter(Boolean),
    ),
  ]

  // Calculate summary data
  const totalIncome = (transactions || [])
    .filter((t) => t?.type === "Income")
    .reduce((sum, t) => sum + (t?.amount || 0), 0)

  const totalExpenses = (transactions || [])
    .filter((t) => t?.type === "Expense")
    .reduce((sum, t) => sum + (t?.amount || 0), 0)

  const balance = totalIncome - totalExpenses

  // Apply filters
  const filteredTransactions = (transactions || []).filter((transaction) => {
    if (!transaction) return false

    const matchesSearch =
      (transaction.description || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (transaction.id || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (transaction.reference || "").toLowerCase().includes(searchTerm.toLowerCase())

    const matchesType = !typeFilter || transaction.type === typeFilter
    const matchesCategory = !categoryFilter || transaction.category === categoryFilter

    return matchesSearch && matchesType && matchesCategory
  })

  const handleAddTransaction = () => {
    if (!newTransaction.account || !newTransaction.category) {
      toast({
        title: "Fehler",
        description: "Bitte wählen Sie ein Konto und eine Kategorie aus.",
        variant: "destructive",
      })
      return
    }

    if (typeof addTransaction === "function") {
      try {
        addTransaction(newTransaction)

        toast({
          title: "Erfolg",
          description: "Transaktion wurde erfolgreich hinzugefügt.",
        })

        // Reset form
        setNewTransaction({
          date: new Date().toISOString().split("T")[0],
          description: "",
          reference: "",
          type: "Expense",
          amount: 0,
          category: "",
          account: "",
          paymentMethod: "Überweisung",
          notes: "",
        })

        setIsAddDialogOpen(false)
      } catch (error) {
        console.error("Error adding transaction:", error)
        toast({
          title: "Fehler",
          description: "Beim Hinzufügen der Transaktion ist ein Fehler aufgetreten.",
          variant: "destructive",
        })
      }
    } else {
      toast({
        title: "Fehler",
        description: "Die Funktion zum Hinzufügen von Transaktionen ist nicht verfügbar.",
        variant: "destructive",
      })
    }
  }

  const handleEditTransaction = () => {
    if (currentTransaction && typeof updateTransaction === "function") {
      try {
        updateTransaction(currentTransaction.id, currentTransaction)

        toast({
          title: "Erfolg",
          description: "Transaktion wurde erfolgreich aktualisiert.",
        })

        setIsEditDialogOpen(false)
      } catch (error) {
        console.error("Error updating transaction:", error)
        toast({
          title: "Fehler",
          description: "Beim Aktualisieren der Transaktion ist ein Fehler aufgetreten.",
          variant: "destructive",
        })
      }
    }
  }

  const handleDeleteTransaction = () => {
    if (currentTransaction && typeof deleteTransaction === "function") {
      try {
        deleteTransaction(currentTransaction.id)

        toast({
          title: "Erfolg",
          description: "Transaktion wurde erfolgreich gelöscht.",
        })

        setIsDeleteDialogOpen(false)
      } catch (error) {
        console.error("Error deleting transaction:", error)
        toast({
          title: "Fehler",
          description: "Beim Löschen der Transaktion ist ein Fehler aufgetreten.",
          variant: "destructive",
        })
      }
    }
  }

  const openEditDialog = (transaction: Transaction) => {
    setCurrentTransaction({ ...transaction })
    setIsEditDialogOpen(true)
  }

  const openDeleteDialog = (transaction: Transaction) => {
    setCurrentTransaction(transaction)
    setIsDeleteDialogOpen(true)
  }

  const openViewDialog = (transaction: Transaction) => {
    setCurrentTransaction(transaction)
    setIsViewDialogOpen(true)
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return ""
    try {
      return format(new Date(dateString), "dd.MM.yyyy", { locale: de })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString("de-DE", {
      style: "currency",
      currency: "EUR",
    })
  }

  const exportToCSV = () => {
    try {
      // Create CSV content
      const headers = [
        "ID",
        "Datum",
        "Beschreibung",
        "Kategorie",
        "Konto",
        "Typ",
        "Betrag",
        "Referenz",
        "Zahlungsmethode",
      ]
      const csvContent = [
        headers.join(","),
        ...filteredTransactions.map((transaction) =>
          [
            transaction.id || "",
            transaction.date || "",
            `"${(transaction.description || "").replace(/"/g, '""')}"`,
            `"${(transaction.category || "").replace(/"/g, '""')}"`,
            `"${(transaction.account || "").replace(/"/g, '""')}"`,
            transaction.type || "",
            transaction.amount || 0,
            `"${(transaction.reference || "").replace(/"/g, '""')}"`,
            `"${(transaction.paymentMethod || "").replace(/"/g, '""')}"`,
          ].join(","),
        ),
      ].join("\n")

      // Create download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.setAttribute("href", url)
      link.setAttribute("download", "transaktionen.csv")
      link.style.visibility = "hidden"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "Export erfolgreich",
        description: "Die Transaktionsdaten wurden als CSV-Datei exportiert.",
      })
    } catch (error) {
      console.error("Error exporting to CSV:", error)
      toast({
        title: "Fehler",
        description: "Beim Exportieren der Daten ist ein Fehler aufgetreten.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-24" />
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Skeleton className="h-10 flex-1 md:max-w-sm" />
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
        <Skeleton className="h-[500px] w-full" />
      </div>
    )
  }

  // Add sample data if transactions array is empty
  if (transactions.length === 0) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Finanztransaktionen</h1>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Transaktion hinzufügen
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Neue Transaktion hinzufügen</DialogTitle>
                <DialogDescription>Geben Sie die Details der neuen Transaktion ein.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Typ</Label>
                    <Select
                      value={newTransaction.type}
                      onValueChange={(value) =>
                        setNewTransaction({ ...newTransaction, type: value as "Income" | "Expense" })
                      }
                    >
                      <SelectTrigger id="type">
                        <SelectValue placeholder="Typ auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Income">Einnahme</SelectItem>
                        <SelectItem value="Expense">Ausgabe</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="date">Datum</Label>
                    <Input
                      id="date"
                      type="date"
                      value={newTransaction.date}
                      onChange={(e) => setNewTransaction({ ...newTransaction, date: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Beschreibung</Label>
                  <Input
                    id="description"
                    value={newTransaction.description}
                    onChange={(e) => setNewTransaction({ ...newTransaction, description: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Betrag (€)</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      value={newTransaction.amount}
                      onChange={(e) =>
                        setNewTransaction({ ...newTransaction, amount: Number.parseFloat(e.target.value) || 0 })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reference">Referenz</Label>
                    <Input
                      id="reference"
                      value={newTransaction.reference || ""}
                      onChange={(e) => setNewTransaction({ ...newTransaction, reference: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Kategorie</Label>
                    <Select
                      value={newTransaction.category}
                      onValueChange={(value) => setNewTransaction({ ...newTransaction, category: value })}
                    >
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Kategorie auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        {newTransaction.type === "Income" ? (
                          <>
                            <SelectItem value="Verkäufe">Verkäufe</SelectItem>
                            <SelectItem value="Dienstleistungen">Dienstleistungen</SelectItem>
                            <SelectItem value="Investitionen">Investitionen</SelectItem>
                            <SelectItem value="Sonstiges">Sonstiges</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="Einkäufe">Einkäufe</SelectItem>
                            <SelectItem value="Gehälter">Gehälter</SelectItem>
                            <SelectItem value="Miete">Miete</SelectItem>
                            <SelectItem value="Versorgung">Versorgung</SelectItem>
                            <SelectItem value="Marketing">Marketing</SelectItem>
                            <SelectItem value="Versicherung">Versicherung</SelectItem>
                            <SelectItem value="Sonstiges">Sonstiges</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="account">Konto</Label>
                    <Select
                      value={newTransaction.account}
                      onValueChange={(value) => setNewTransaction({ ...newTransaction, account: value })}
                    >
                      <SelectTrigger id="account">
                        <SelectValue placeholder="Konto auswählen" />
                      </SelectTrigger>
                      <SelectContent>
                        {(accounts || []).map((account) => (
                          <SelectItem key={account?.id || Math.random().toString()} value={account?.id || ""}>
                            {account?.name || ""} ({account?.type || ""})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="paymentMethod">Zahlungsmethode</Label>
                  <Select
                    value={newTransaction.paymentMethod || ""}
                    onValueChange={(value) => setNewTransaction({ ...newTransaction, paymentMethod: value })}
                  >
                    <SelectTrigger id="paymentMethod">
                      <SelectValue placeholder="Zahlungsmethode auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Überweisung">Überweisung</SelectItem>
                      <SelectItem value="Kreditkarte">Kreditkarte</SelectItem>
                      <SelectItem value="Bar">Bar</SelectItem>
                      <SelectItem value="PayPal">PayPal</SelectItem>
                      <SelectItem value="Lastschrift">Lastschrift</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notizen</Label>
                  <Textarea
                    id="notes"
                    value={newTransaction.notes || ""}
                    onChange={(e) => setNewTransaction({ ...newTransaction, notes: e.target.value })}
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Abbrechen
                </Button>
                <Button onClick={handleAddTransaction}>Transaktion hinzufügen</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Einnahmen</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{formatCurrency(0)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Ausgaben</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{formatCurrency(0)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Bilanz</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{formatCurrency(0)}</div>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col items-center justify-center p-12 text-center border rounded-md">
          <div className="mb-4 text-6xl text-muted-foreground">
            <TrendingUp className="h-12 w-12 mx-auto" />
          </div>
          <h3 className="mb-2 text-2xl font-semibold">Keine Transaktionen vorhanden</h3>
          <p className="mb-6 text-muted-foreground">
            Sie haben noch keine Finanztransaktionen erfasst. Fügen Sie Ihre erste Transaktion hinzu, um Ihre Finanzen
            zu verwalten.
          </p>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Erste Transaktion hinzufügen
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Finanztransaktionen</h1>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Transaktion hinzufügen
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Neue Transaktion hinzufügen</DialogTitle>
              <DialogDescription>Geben Sie die Details der neuen Transaktion ein.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Typ</Label>
                  <Select
                    value={newTransaction.type}
                    onValueChange={(value) =>
                      setNewTransaction({ ...newTransaction, type: value as "Income" | "Expense" })
                    }
                  >
                    <SelectTrigger id="type">
                      <SelectValue placeholder="Typ auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Income">Einnahme</SelectItem>
                      <SelectItem value="Expense">Ausgabe</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date">Datum</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newTransaction.date}
                    onChange={(e) => setNewTransaction({ ...newTransaction, date: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Beschreibung</Label>
                <Input
                  id="description"
                  value={newTransaction.description}
                  onChange={(e) => setNewTransaction({ ...newTransaction, description: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">Betrag (€)</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    value={newTransaction.amount}
                    onChange={(e) =>
                      setNewTransaction({ ...newTransaction, amount: Number.parseFloat(e.target.value) || 0 })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reference">Referenz</Label>
                  <Input
                    id="reference"
                    value={newTransaction.reference || ""}
                    onChange={(e) => setNewTransaction({ ...newTransaction, reference: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Kategorie</Label>
                  <Select
                    value={newTransaction.category}
                    onValueChange={(value) => setNewTransaction({ ...newTransaction, category: value })}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Kategorie auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {newTransaction.type === "Income" ? (
                        <>
                          <SelectItem value="Verkäufe">Verkäufe</SelectItem>
                          <SelectItem value="Dienstleistungen">Dienstleistungen</SelectItem>
                          <SelectItem value="Investitionen">Investitionen</SelectItem>
                          <SelectItem value="Sonstiges">Sonstiges</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="Einkäufe">Einkäufe</SelectItem>
                          <SelectItem value="Gehälter">Gehälter</SelectItem>
                          <SelectItem value="Miete">Miete</SelectItem>
                          <SelectItem value="Versorgung">Versorgung</SelectItem>
                          <SelectItem value="Marketing">Marketing</SelectItem>
                          <SelectItem value="Versicherung">Versicherung</SelectItem>
                          <SelectItem value="Sonstiges">Sonstiges</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="account">Konto</Label>
                  <Select
                    value={newTransaction.account}
                    onValueChange={(value) => setNewTransaction({ ...newTransaction, account: value })}
                  >
                    <SelectTrigger id="account">
                      <SelectValue placeholder="Konto auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {(accounts || []).map((account) => (
                        <SelectItem key={account?.id || Math.random().toString()} value={account?.id || ""}>
                          {account?.name || ""} ({account?.type || ""})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="paymentMethod">Zahlungsmethode</Label>
                <Select
                  value={newTransaction.paymentMethod || ""}
                  onValueChange={(value) => setNewTransaction({ ...newTransaction, paymentMethod: value })}
                >
                  <SelectTrigger id="paymentMethod">
                    <SelectValue placeholder="Zahlungsmethode auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Überweisung">Überweisung</SelectItem>
                    <SelectItem value="Kreditkarte">Kreditkarte</SelectItem>
                    <SelectItem value="Bar">Bar</SelectItem>
                    <SelectItem value="PayPal">PayPal</SelectItem>
                    <SelectItem value="Lastschrift">Lastschrift</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notizen</Label>
                <Textarea
                  id="notes"
                  value={newTransaction.notes || ""}
                  onChange={(e) => setNewTransaction({ ...newTransaction, notes: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Abbrechen
              </Button>
              <Button onClick={handleAddTransaction}>Transaktion hinzufügen</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Einnahmen</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalIncome)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Ausgaben</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(totalExpenses)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Bilanz</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${balance >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatCurrency(balance)}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1 md:max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Transaktionen suchen..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
                <span className="sr-only">Filter</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[200px]">
              <DropdownMenuLabel>Filter</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">Typ</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setTypeFilter(null)}>Alle Typen</DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setTypeFilter("Income")}
                className={typeFilter === "Income" ? "bg-muted" : ""}
              >
                Einnahmen
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setTypeFilter("Expense")}
                className={typeFilter === "Expense" ? "bg-muted" : ""}
              >
                Ausgaben
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">Kategorie</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setCategoryFilter(null)}>Alle Kategorien</DropdownMenuItem>
              {typeFilter === "Income"
                ? incomeCategories.map((category) => (
                    <DropdownMenuItem
                      key={category}
                      onClick={() => setCategoryFilter(category)}
                      className={categoryFilter === category ? "bg-muted" : ""}
                    >
                      {category}
                    </DropdownMenuItem>
                  ))
                : typeFilter === "Expense"
                  ? expenseCategories.map((category) => (
                      <DropdownMenuItem
                        key={category}
                        onClick={() => setCategoryFilter(category)}
                        className={categoryFilter === category ? "bg-muted" : ""}
                      >
                        {category}
                      </DropdownMenuItem>
                    ))
                  : [...incomeCategories, ...expenseCategories]
                      .filter((value, index, self) => self.indexOf(value) === index)
                      .map((category) => (
                        <DropdownMenuItem
                          key={category}
                          onClick={() => setCategoryFilter(category)}
                          className={categoryFilter === category ? "bg-muted" : ""}
                        >
                          {category}
                        </DropdownMenuItem>
                      ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={exportToCSV}>
            <Download className="mr-2 h-4 w-4" />
            Exportieren
          </Button>
          <Button variant="outline" size="sm">
            <Upload className="mr-2 h-4 w-4" />
            Importieren
          </Button>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Datum</TableHead>
              <TableHead>Beschreibung</TableHead>
              <TableHead>Kategorie</TableHead>
              <TableHead>Konto</TableHead>
              <TableHead>Typ</TableHead>
              <TableHead className="text-right">Betrag</TableHead>
              <TableHead className="text-right">Aktionen</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTransactions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                  Keine Transaktionen gefunden
                </TableCell>
              </TableRow>
            ) : (
              filteredTransactions.map((transaction) => {
                if (!transaction) return null
                const account = (accounts || []).find((a) => a?.id === transaction.account)

                return (
                  <TableRow key={transaction.id || Math.random().toString()}>
                    <TableCell className="font-medium">{transaction.id || ""}</TableCell>
                    <TableCell>{formatDate(transaction.date)}</TableCell>
                    <TableCell>{transaction.description || ""}</TableCell>
                    <TableCell>{transaction.category || ""}</TableCell>
                    <TableCell>{account ? account.name : transaction.account || ""}</TableCell>
                    <TableCell>
                      <Badge
                        className={
                          transaction.type === "Income"
                            ? "bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300"
                            : "bg-red-100 text-red-800 hover:bg-red-100 dark:bg-red-900 dark:text-red-300"
                        }
                      >
                        <span className="flex items-center">
                          {transaction.type === "Income" ? (
                            <>
                              <TrendingUp className="mr-1 h-3 w-3" />
                              Einnahme
                            </>
                          ) : (
                            <>
                              <TrendingDown className="mr-1 h-3 w-3" />
                              Ausgabe
                            </>
                          )}
                        </span>
                      </Badge>
                    </TableCell>
                    <TableCell
                      className={`text-right font-medium ${
                        transaction.type === "Income" ? "text-green-600" : "text-red-600"
                      }`}
                    >
                      {formatCurrency(transaction.amount || 0)}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Aktionen</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Aktionen</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => openViewDialog(transaction)}>
                            <FileText className="mr-2 h-4 w-4" />
                            Anzeigen
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openEditDialog(transaction)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Bearbeiten
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openDeleteDialog(transaction)}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Löschen
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Transaktionsdetails</DialogTitle>
          </DialogHeader>
          {currentTransaction && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Transaktions-ID</h3>
                  <p className="text-base">{currentTransaction.id || ""}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Typ</h3>
                  <Badge
                    className={
                      currentTransaction.type === "Income"
                        ? "bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300"
                        : "bg-red-100 text-red-800 hover:bg-red-100 dark:bg-red-900 dark:text-red-300"
                    }
                  >
                    <span className="flex items-center">
                      {currentTransaction.type === "Income" ? (
                        <>
                          <TrendingUp className="mr-1 h-3 w-3" />
                          Einnahme
                        </>
                      ) : (
                        <>
                          <TrendingDown className="mr-1 h-3 w-3" />
                          Ausgabe
                        </>
                      )}
                    </span>
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Datum</h3>
                  <p className="text-base">{formatDate(currentTransaction.date)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Betrag</h3>
                  <p
                    className={`text-base font-medium ${
                      currentTransaction.type === "Income" ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {formatCurrency(currentTransaction.amount || 0)}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Beschreibung</h3>
                <p className="text-base">{currentTransaction.description || ""}</p>
              </div>

              {currentTransaction.reference && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Referenz</h3>
                  <p className="text-base">{currentTransaction.reference}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Kategorie</h3>
                  <p className="text-base">{currentTransaction.category || ""}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Konto</h3>
                  <p className="text-base">
                    {(accounts || []).find((a) => a?.id === currentTransaction.account)?.name ||
                      currentTransaction.account ||
                      ""}
                  </p>
                </div>
              </div>

              {currentTransaction.paymentMethod && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Zahlungsmethode</h3>
                  <p className="text-base">{currentTransaction.paymentMethod}</p>
                </div>
              )}

              {currentTransaction.notes && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Notizen</h3>
                  <p className="text-base">{currentTransaction.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Transaktion bearbeiten</DialogTitle>
            <DialogDescription>Bearbeiten Sie die Details der Transaktion.</DialogDescription>
          </DialogHeader>
          {currentTransaction && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-type">Typ</Label>
                  <Select
                    value={currentTransaction.type}
                    onValueChange={(value) =>
                      setCurrentTransaction({ ...currentTransaction, type: value as "Income" | "Expense" })
                    }
                  >
                    <SelectTrigger id="edit-type">
                      <SelectValue placeholder="Typ auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Income">Einnahme</SelectItem>
                      <SelectItem value="Expense">Ausgabe</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-date">Datum</Label>
                  <Input
                    id="edit-date"
                    type="date"
                    value={currentTransaction.date}
                    onChange={(e) => setCurrentTransaction({ ...currentTransaction, date: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-description">Beschreibung</Label>
                <Input
                  id="edit-description"
                  value={currentTransaction.description}
                  onChange={(e) => setCurrentTransaction({ ...currentTransaction, description: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-amount">Betrag (€)</Label>
                  <Input
                    id="edit-amount"
                    type="number"
                    step="0.01"
                    value={currentTransaction.amount}
                    onChange={(e) =>
                      setCurrentTransaction({ ...currentTransaction, amount: Number.parseFloat(e.target.value) || 0 })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-reference">Referenz</Label>
                  <Input
                    id="edit-reference"
                    value={currentTransaction.reference || ""}
                    onChange={(e) => setCurrentTransaction({ ...currentTransaction, reference: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-category">Kategorie</Label>
                  <Select
                    value={currentTransaction.category}
                    onValueChange={(value) => setCurrentTransaction({ ...currentTransaction, category: value })}
                  >
                    <SelectTrigger id="edit-category">
                      <SelectValue placeholder="Kategorie auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {currentTransaction.type === "Income" ? (
                        <>
                          <SelectItem value="Verkäufe">Verkäufe</SelectItem>
                          <SelectItem value="Dienstleistungen">Dienstleistungen</SelectItem>
                          <SelectItem value="Investitionen">Investitionen</SelectItem>
                          <SelectItem value="Sonstiges">Sonstiges</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="Einkäufe">Einkäufe</SelectItem>
                          <SelectItem value="Gehälter">Gehälter</SelectItem>
                          <SelectItem value="Miete">Miete</SelectItem>
                          <SelectItem value="Versorgung">Versorgung</SelectItem>
                          <SelectItem value="Marketing">Marketing</SelectItem>
                          <SelectItem value="Versicherung">Versicherung</SelectItem>
                          <SelectItem value="Sonstiges">Sonstiges</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-account">Konto</Label>
                  <Select
                    value={currentTransaction.account}
                    onValueChange={(value) => setCurrentTransaction({ ...currentTransaction, account: value })}
                  >
                    <SelectTrigger id="edit-account">
                      <SelectValue placeholder="Konto auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {(accounts || []).map((account) => (
                        <SelectItem key={account?.id || Math.random().toString()} value={account?.id || ""}>
                          {account?.name || ""} ({account?.type || ""})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-paymentMethod">Zahlungsmethode</Label>
                <Select
                  value={currentTransaction.paymentMethod || ""}
                  onValueChange={(value) => setCurrentTransaction({ ...currentTransaction, paymentMethod: value })}
                >
                  <SelectTrigger id="edit-paymentMethod">
                    <SelectValue placeholder="Zahlungsmethode auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Überweisung">Überweisung</SelectItem>
                    <SelectItem value="Kreditkarte">Kreditkarte</SelectItem>
                    <SelectItem value="Bar">Bar</SelectItem>
                    <SelectItem value="PayPal">PayPal</SelectItem>
                    <SelectItem value="Lastschrift">Lastschrift</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-notes">Notizen</Label>
                <Textarea
                  id="edit-notes"
                  value={currentTransaction.notes || ""}
                  onChange={(e) => setCurrentTransaction({ ...currentTransaction, notes: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Abbrechen
            </Button>
            <Button onClick={handleEditTransaction}>Änderungen speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Transaktion löschen</DialogTitle>
            <DialogDescription>
              Sind Sie sicher, dass Sie diese Transaktion löschen möchten? Diese Aktion kann nicht rückgängig gemacht
              werden.
            </DialogDescription>
          </DialogHeader>
          {currentTransaction && (
            <div className="py-4">
              <p>
                <strong>Transaktions-ID:</strong> {currentTransaction.id}
              </p>
              <p>
                <strong>Beschreibung:</strong> {currentTransaction.description}
              </p>
              <p>
                <strong>Betrag:</strong> {formatCurrency(currentTransaction.amount)}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Abbrechen
            </Button>
            <Button variant="destructive" onClick={handleDeleteTransaction}>
              Löschen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

