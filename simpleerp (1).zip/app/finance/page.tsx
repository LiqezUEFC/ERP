"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Trash2,
  Download,
  Upload,
  TrendingUp,
  TrendingDown,
} from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from "@/hooks/use-toast"
import { useData } from "@/contexts/data-context"

export default function FinancePage() {
  const { data, loading, error, addItem, updateItem, deleteItem } = useData()
  const { toast } = useToast()

  // Safely access data with fallbacks
  const transactions = data?.transactions || []
  const accounts = data?.accounts || []
  const budgets = data?.budgets || []

  const [activeTab, setActiveTab] = useState("transactions")
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState(null)
  const [categoryFilter, setCategoryFilter] = useState(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [currentItem, setCurrentItem] = useState(null)
  const [newTransaction, setNewTransaction] = useState({
    id: "",
    date: new Date().toISOString().split("T")[0],
    description: "",
    type: "Expense",
    amount: 0,
    category: "Operations",
  })
  const [newAccount, setNewAccount] = useState({
    id: "",
    name: "",
    type: "Bank",
    balance: 0,
    currency: "EUR",
  })
  const [newBudget, setNewBudget] = useState({
    id: "",
    name: "",
    period: "Monthly",
    allocated: 0,
    spent: 0,
    remaining: 0,
    status: "Active",
  })

  // Apply filters based on active tab
  const getFilteredItems = () => {
    if (!data) return []

    switch (activeTab) {
      case "transactions":
        return transactions.filter(
          (transaction) =>
            transaction &&
            (transaction.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
              transaction.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
              transaction.category?.toLowerCase().includes(searchTerm.toLowerCase())) &&
            (!typeFilter || transaction.type === typeFilter) &&
            (!categoryFilter || transaction.category === categoryFilter),
        )
      case "accounts":
        return accounts.filter(
          (account) =>
            account &&
            (account.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
              account.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
              account.type?.toLowerCase().includes(searchTerm.toLowerCase())),
        )
      case "budgets":
        return budgets.filter(
          (budget) =>
            budget &&
            (budget.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
              budget.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
              budget.period?.toLowerCase().includes(searchTerm.toLowerCase())),
        )
      default:
        return []
    }
  }

  const filteredItems = getFilteredItems()

  // Get unique categories for filter
  const categories = [
    ...new Set(transactions.filter((t) => t && t.category).map((transaction) => transaction.category)),
  ]

  // Handle adding new items based on active tab
  const handleAddItem = () => {
    if (typeof addItem !== "function") {
      console.error("addItem is not a function")
      return
    }

    switch (activeTab) {
      case "transactions":
        const transactionId = `TRX${String((transactions?.length || 0) + 1).padStart(3, "0")}`

        addItem("transactions", {
          ...newTransaction,
          id: transactionId,
        })

        setNewTransaction({
          id: "",
          date: new Date().toISOString().split("T")[0],
          description: "",
          type: "Expense",
          amount: 0,
          category: "Operations",
        })

        toast({
          title: "Transaction added",
          description: "The transaction has been added successfully.",
        })
        break

      case "accounts":
        const accountId = `ACC${String((accounts?.length || 0) + 1).padStart(3, "0")}`

        addItem("accounts", {
          ...newAccount,
          id: accountId,
        })

        setNewAccount({
          id: "",
          name: "",
          type: "Bank",
          balance: 0,
          currency: "EUR",
        })

        toast({
          title: "Account added",
          description: "The account has been added successfully.",
        })
        break

      case "budgets":
        const budgetId = `BUD${String((budgets?.length || 0) + 1).padStart(3, "0")}`
        const remaining = newBudget.allocated - newBudget.spent
        const status = remaining < 0 ? "Exceeded" : remaining < newBudget.allocated * 0.1 ? "Warning" : "Active"

        addItem("budgets", {
          ...newBudget,
          id: budgetId,
          remaining,
          status,
        })

        setNewBudget({
          id: "",
          name: "",
          period: "Monthly",
          allocated: 0,
          spent: 0,
          remaining: 0,
          status: "Active",
        })

        toast({
          title: "Budget added",
          description: "The budget has been added successfully.",
        })
        break
    }

    setIsDialogOpen(false)
  }

  // Handle editing items based on active tab
  const handleEditItem = () => {
    if (!currentItem || typeof updateItem !== "function") {
      console.error("currentItem is null or updateItem is not a function")
      return
    }

    switch (activeTab) {
      case "transactions":
        updateItem("transactions", currentItem.id, { ...currentItem })

        toast({
          title: "Transaction updated",
          description: "The transaction has been updated successfully.",
        })
        break

      case "accounts":
        updateItem("accounts", currentItem.id, { ...currentItem })

        toast({
          title: "Account updated",
          description: "The account has been updated successfully.",
        })
        break

      case "budgets":
        // Recalculate remaining and status
        const remaining = currentItem.allocated - currentItem.spent
        const status = remaining < 0 ? "Exceeded" : remaining < currentItem.allocated * 0.1 ? "Warning" : "Active"

        updateItem("budgets", currentItem.id, {
          ...currentItem,
          remaining,
          status,
        })

        toast({
          title: "Budget updated",
          description: "The budget has been updated successfully.",
        })
        break
    }

    setIsEditDialogOpen(false)
  }

  // Handle deleting items based on active tab
  const handleDeleteItem = () => {
    if (!currentItem || typeof deleteItem !== "function") {
      console.error("currentItem is null or deleteItem is not a function")
      return
    }

    switch (activeTab) {
      case "transactions":
        deleteItem("transactions", currentItem.id)

        toast({
          title: "Transaction deleted",
          description: "The transaction has been deleted successfully.",
        })
        break

      case "accounts":
        deleteItem("accounts", currentItem.id)

        toast({
          title: "Account deleted",
          description: "The account has been deleted successfully.",
        })
        break

      case "budgets":
        deleteItem("budgets", currentItem.id)

        toast({
          title: "Budget deleted",
          description: "The budget has been deleted successfully.",
        })
        break
    }

    setIsDeleteDialogOpen(false)
  }

  const openEditDialog = (item) => {
    setCurrentItem({ ...item })
    setIsEditDialogOpen(true)
  }

  const openDeleteDialog = (item) => {
    setCurrentItem(item)
    setIsDeleteDialogOpen(true)
  }

  // Get dialog title and description based on active tab
  const getDialogInfo = () => {
    switch (activeTab) {
      case "transactions":
        return {
          title: "Add New Transaction",
          description: "Enter the details of the new transaction.",
        }
      case "accounts":
        return {
          title: "Add New Account",
          description: "Enter the details of the new account.",
        }
      case "budgets":
        return {
          title: "Create New Budget",
          description: "Enter the details of the new budget.",
        }
      default:
        return {
          title: "Add New Item",
          description: "Enter the details of the new item.",
        }
    }
  }

  // Calculate summary data safely
  const totalIncome = transactions.filter((t) => t && t.type === "Income").reduce((sum, t) => sum + (t.amount || 0), 0)

  const totalExpenses = transactions
    .filter((t) => t && t.type === "Expense")
    .reduce((sum, t) => sum + (t.amount || 0), 0)

  const balance = totalIncome - totalExpenses

  const totalAssets = accounts.filter((a) => a && a.balance > 0).reduce((sum, a) => sum + (a.balance || 0), 0)

  const totalLiabilities = accounts
    .filter((a) => a && a.balance < 0)
    .reduce((sum, a) => sum + Math.abs(a.balance || 0), 0)

  const netWorth = totalAssets - totalLiabilities

  const totalBudgeted = budgets.reduce((sum, b) => (b ? sum + (b.allocated || 0) : sum), 0)

  const totalSpent = budgets.reduce((sum, b) => (b ? sum + (b.spent || 0) : sum), 0)

  const budgetRemaining = totalBudgeted - totalSpent

  if (loading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-24" />
        </div>
        <Skeleton className="h-10 w-full" />
        <div className="grid gap-4 md:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-[500px] w-full" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Financial Management</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              {activeTab === "transactions"
                ? "Add Transaction"
                : activeTab === "accounts"
                  ? "Add Account"
                  : "Create Budget"}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{getDialogInfo().title}</DialogTitle>
              <DialogDescription>{getDialogInfo().description}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              {activeTab === "transactions" && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="date" className="text-right">
                      Date
                    </Label>
                    <Input
                      id="date"
                      type="date"
                      value={newTransaction.date}
                      onChange={(e) => setNewTransaction({ ...newTransaction, date: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="description" className="text-right">
                      Description
                    </Label>
                    <Input
                      id="description"
                      value={newTransaction.description}
                      onChange={(e) => setNewTransaction({ ...newTransaction, description: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="type" className="text-right">
                      Type
                    </Label>
                    <Select
                      value={newTransaction.type}
                      onValueChange={(value) => setNewTransaction({ ...newTransaction, type: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Income">Income</SelectItem>
                        <SelectItem value="Expense">Expense</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="amount" className="text-right">
                      Amount (€)
                    </Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      value={newTransaction.amount}
                      onChange={(e) =>
                        setNewTransaction({
                          ...newTransaction,
                          amount: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="category" className="text-right">
                      Category
                    </Label>
                    <Select
                      value={newTransaction.category}
                      onValueChange={(value) => setNewTransaction({ ...newTransaction, category: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Operations">Operations</SelectItem>
                        <SelectItem value="Sales">Sales</SelectItem>
                        <SelectItem value="Marketing">Marketing</SelectItem>
                        <SelectItem value="IT">IT</SelectItem>
                        <SelectItem value="HR">HR</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {activeTab === "accounts" && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      Account Name
                    </Label>
                    <Input
                      id="name"
                      value={newAccount.name}
                      onChange={(e) => setNewAccount({ ...newAccount, name: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="type" className="text-right">
                      Account Type
                    </Label>
                    <Select
                      value={newAccount.type}
                      onValueChange={(value) => setNewAccount({ ...newAccount, type: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Bank">Bank</SelectItem>
                        <SelectItem value="Cash">Cash</SelectItem>
                        <SelectItem value="Credit Card">Credit Card</SelectItem>
                        <SelectItem value="Investment">Investment</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="balance" className="text-right">
                      Initial Balance (€)
                    </Label>
                    <Input
                      id="balance"
                      type="number"
                      step="0.01"
                      value={newAccount.balance}
                      onChange={(e) =>
                        setNewAccount({
                          ...newAccount,
                          balance: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="currency" className="text-right">
                      Currency
                    </Label>
                    <Select
                      value={newAccount.currency}
                      onValueChange={(value) => setNewAccount({ ...newAccount, currency: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="EUR">EUR</SelectItem>
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="GBP">GBP</SelectItem>
                        <SelectItem value="JPY">JPY</SelectItem>
                        <SelectItem value="CHF">CHF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {activeTab === "budgets" && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      Budget Name
                    </Label>
                    <Input
                      id="name"
                      value={newBudget.name}
                      onChange={(e) => setNewBudget({ ...newBudget, name: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="period" className="text-right">
                      Period
                    </Label>
                    <Select
                      value={newBudget.period}
                      onValueChange={(value) => setNewBudget({ ...newBudget, period: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Monthly">Monthly</SelectItem>
                        <SelectItem value="Quarterly">Quarterly</SelectItem>
                        <SelectItem value="Annual">Annual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="allocated" className="text-right">
                      Allocated Amount (€)
                    </Label>
                    <Input
                      id="allocated"
                      type="number"
                      step="0.01"
                      value={newBudget.allocated}
                      onChange={(e) =>
                        setNewBudget({
                          ...newBudget,
                          allocated: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="spent" className="text-right">
                      Spent Amount (€)
                    </Label>
                    <Input
                      id="spent"
                      type="number"
                      step="0.01"
                      value={newBudget.spent}
                      onChange={(e) =>
                        setNewBudget({
                          ...newBudget,
                          spent: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      className="col-span-3"
                    />
                  </div>
                </>
              )}
            </div>
            <DialogFooter>
              <Button onClick={handleAddItem}>
                {activeTab === "transactions"
                  ? "Add Transaction"
                  : activeTab === "accounts"
                    ? "Add Account"
                    : "Create Budget"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="transactions" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="accounts">Accounts</TabsTrigger>
          <TabsTrigger value="budgets">Budgets</TabsTrigger>
        </TabsList>

        <div className="grid gap-4 md:grid-cols-3">
          {activeTab === "transactions" && (
            <>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Income</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">€{totalIncome.toFixed(2)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">€{totalExpenses.toFixed(2)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${balance >= 0 ? "text-green-600" : "text-red-600"}`}>
                    €{balance.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </>
          )}

          {activeTab === "accounts" && (
            <>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Assets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">€{totalAssets.toFixed(2)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Liabilities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">€{totalLiabilities.toFixed(2)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Net Worth</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${netWorth >= 0 ? "text-green-600" : "text-red-600"}`}>
                    €{netWorth.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </>
          )}

          {activeTab === "budgets" && (
            <>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Budgeted</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{totalBudgeted.toFixed(2)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{totalSpent.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground">
                    {totalBudgeted > 0 ? Math.round((totalSpent / totalBudgeted) * 100) : 0}% of budget
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Remaining</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${budgetRemaining >= 0 ? "text-green-600" : "text-red-600"}`}>
                    €{budgetRemaining.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-1 items-center gap-2">
            <div className="relative flex-1 md:max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder={`Search ${activeTab}...`}
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {activeTab === "transactions" && (
              <>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon">
                      <Filter className="h-4 w-4" />
                      <span className="sr-only">Filter</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-[200px]">
                    <DropdownMenuLabel>Filter by Type</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setTypeFilter(null)}>All Types</DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => setTypeFilter("Income")}
                      className={typeFilter === "Income" ? "bg-muted" : ""}
                    >
                      Income
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => setTypeFilter("Expense")}
                      className={typeFilter === "Expense" ? "bg-muted" : ""}
                    >
                      Expense
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel>Filter by Category</DropdownMenuLabel>
                    <DropdownMenuItem onClick={() => setCategoryFilter(null)}>All Categories</DropdownMenuItem>
                    {categories.map((category) => (
                      <DropdownMenuItem
                        key={category}
                        onClick={() => setCategoryFilter(category)}
                        className={categoryFilter === category ? "bg-muted" : ""}
                      >
                        {category}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
            <Button variant="outline" size="sm">
              <Upload className="mr-2 h-4 w-4" />
              Import
            </Button>
          </div>
        </div>

        <TabsContent value="transactions" className="space-y-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredItems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No transactions found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredItems.map((transaction) => (
                    <TableRow key={transaction?.id || "unknown"}>
                      <TableCell className="font-medium">{transaction?.id || "N/A"}</TableCell>
                      <TableCell>{transaction?.category || "N/A"}</TableCell>
                      <TableCell>
                        <Badge
                          className={
                            transaction?.type === "Income"
                              ? "bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300"
                              : "bg-red-100 text-red-800 hover:bg-red-100 dark:bg-red-900 dark:text-red-300"
                          }
                        >
                          <span className="flex items-center">
                            {transaction?.type === "Income" ? (
                              <>
                                <TrendingUp className="mr-1 h-3 w-3" />
                                Income
                              </>
                            ) : (
                              <>
                                <TrendingDown className="mr-1 h-3 w-3" />
                                Expense
                              </>
                            )}
                          </span>
                        </Badge>
                      </TableCell>
                      <TableCell
                        className={`text-right font-medium ${
                          transaction?.type === "Income" ? "text-green-600" : "text-red-600"
                        }`}
                      >
                        €{(transaction?.amount || 0).toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => openEditDialog(transaction)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openDeleteDialog(transaction)}>
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Account Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Currency</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredItems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No accounts found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredItems.map((account) => (
                    <TableRow key={account?.id || "unknown"}>
                      <TableCell className="font-medium">{account?.id || "N/A"}</TableCell>
                      <TableCell>{account?.name || "N/A"}</TableCell>
                      <TableCell>{account?.type || "N/A"}</TableCell>
                      <TableCell>{account?.currency || "EUR"}</TableCell>
                      <TableCell
                        className={`text-right font-medium ${(account?.balance || 0) >= 0 ? "text-green-600" : "text-red-600"}`}
                      >
                        {account?.currency || "EUR"} {(account?.balance || 0).toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => openEditDialog(account)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openDeleteDialog(account)}>
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="budgets" className="space-y-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Budget Name</TableHead>
                  <TableHead>Period</TableHead>
                  <TableHead className="text-right">Allocated</TableHead>
                  <TableHead className="text-right">Spent</TableHead>
                  <TableHead className="text-right">Remaining</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredItems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      No budgets found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredItems.map((budget) => (
                    <TableRow key={budget?.id || "unknown"}>
                      <TableCell className="font-medium">{budget?.id || "N/A"}</TableCell>
                      <TableCell>{budget?.name || "N/A"}</TableCell>
                      <TableCell>{budget?.period || "N/A"}</TableCell>
                      <TableCell className="text-right">€{(budget?.allocated || 0).toFixed(2)}</TableCell>
                      <TableCell className="text-right">€{(budget?.spent || 0).toFixed(2)}</TableCell>
                      <TableCell
                        className={`text-right font-medium ${
                          (budget?.remaining || 0) >= 0 ? "text-green-600" : "text-red-600"
                        }`}
                      >
                        €{(budget?.remaining || 0).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            budget?.status === "Active"
                              ? "bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300"
                              : budget?.status === "Warning"
                                ? "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-300"
                                : "bg-red-100 text-red-800 hover:bg-red-100 dark:bg-red-900 dark:text-red-300"
                          }
                        >
                          {budget?.status || "N/A"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => openEditDialog(budget)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openDeleteDialog(budget)}>
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {activeTab === "transactions"
                ? "Edit Transaction"
                : activeTab === "accounts"
                  ? "Edit Account"
                  : "Edit Budget"}
            </DialogTitle>
            <DialogDescription>Update the details of the {activeTab.slice(0, -1)}.</DialogDescription>
          </DialogHeader>
          {currentItem && (
            <div className="grid gap-4 py-4">
              {activeTab === "transactions" && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-date" className="text-right">
                      Date
                    </Label>
                    <Input
                      id="edit-date"
                      type="date"
                      value={currentItem.date}
                      onChange={(e) => setCurrentItem({ ...currentItem, date: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-description" className="text-right">
                      Description
                    </Label>
                    <Input
                      id="edit-description"
                      value={currentItem.description}
                      onChange={(e) => setCurrentItem({ ...currentItem, description: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-type" className="text-right">
                      Type
                    </Label>
                    <Select
                      value={currentItem.type}
                      onValueChange={(value) => setCurrentItem({ ...currentItem, type: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Income">Income</SelectItem>
                        <SelectItem value="Expense">Expense</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-amount" className="text-right">
                      Amount (€)
                    </Label>
                    <Input
                      id="edit-amount"
                      type="number"
                      step="0.01"
                      value={currentItem.amount}
                      onChange={(e) =>
                        setCurrentItem({
                          ...currentItem,
                          amount: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-category" className="text-right">
                      Category
                    </Label>
                    <Select
                      value={currentItem.category}
                      onValueChange={(value) => setCurrentItem({ ...currentItem, category: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Operations">Operations</SelectItem>
                        <SelectItem value="Sales">Sales</SelectItem>
                        <SelectItem value="Marketing">Marketing</SelectItem>
                        <SelectItem value="IT">IT</SelectItem>
                        <SelectItem value="HR">HR</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {activeTab === "accounts" && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-name" className="text-right">
                      Account Name
                    </Label>
                    <Input
                      id="edit-name"
                      value={currentItem.name}
                      onChange={(e) => setCurrentItem({ ...currentItem, name: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-type" className="text-right">
                      Account Type
                    </Label>
                    <Select
                      value={currentItem.type}
                      onValueChange={(value) => setCurrentItem({ ...currentItem, type: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Bank">Bank</SelectItem>
                        <SelectItem value="Cash">Cash</SelectItem>
                        <SelectItem value="Credit Card">Credit Card</SelectItem>
                        <SelectItem value="Investment">Investment</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-balance" className="text-right">
                      Balance (€)
                    </Label>
                    <Input
                      id="edit-balance"
                      type="number"
                      step="0.01"
                      value={currentItem.balance}
                      onChange={(e) =>
                        setCurrentItem({
                          ...currentItem,
                          balance: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-currency" className="text-right">
                      Currency
                    </Label>
                    <Select
                      value={currentItem.currency}
                      onValueChange={(value) => setCurrentItem({ ...currentItem, currency: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="EUR">EUR</SelectItem>
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="GBP">GBP</SelectItem>
                        <SelectItem value="JPY">JPY</SelectItem>
                        <SelectItem value="CHF">CHF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {activeTab === "budgets" && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-name" className="text-right">
                      Budget Name
                    </Label>
                    <Input
                      id="edit-name"
                      value={currentItem.name}
                      onChange={(e) => setCurrentItem({ ...currentItem, name: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-period" className="text-right">
                      Period
                    </Label>
                    <Select
                      value={currentItem.period}
                      onValueChange={(value) => setCurrentItem({ ...currentItem, period: value })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Monthly">Monthly</SelectItem>
                        <SelectItem value="Quarterly">Quarterly</SelectItem>
                        <SelectItem value="Annual">Annual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-allocated" className="text-right">
                      Allocated Amount (€)
                    </Label>
                    <Input
                      id="edit-allocated"
                      type="number"
                      step="0.01"
                      value={currentItem.allocated}
                      onChange={(e) =>
                        setCurrentItem({
                          ...currentItem,
                          allocated: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="edit-spent" className="text-right">
                      Spent Amount (€)
                    </Label>
                    <Input
                      id="edit-spent"
                      type="number"
                      step="0.01"
                      value={currentItem.spent}
                      onChange={(e) =>
                        setCurrentItem({
                          ...currentItem,
                          spent: Number.parseFloat(e.target.value) || 0,
                        })
                      }
                      className="col-span-3"
                    />
                  </div>
                </>
              )}
            </div>
          )}
          <DialogFooter>
            <Button onClick={handleEditItem}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Delete {activeTab === "transactions" ? "Transaction" : activeTab === "accounts" ? "Account" : "Budget"}
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this {activeTab.slice(0, -1)}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          {currentItem && (
            <div className="py-4">
              <p>
                <strong>ID:</strong> {currentItem.id}
              </p>
              {activeTab === "transactions" && (
                <>
                  <p>
                    <strong>Description:</strong> {currentItem.description}
                  </p>
                  <p>
                    <strong>Amount:</strong> €{currentItem.amount.toFixed(2)}
                  </p>
                </>
              )}
              {activeTab === "accounts" && (
                <>
                  <p>
                    <strong>Name:</strong> {currentItem.name}
                  </p>
                  <p>
                    <strong>Balance:</strong> {currentItem.currency} {currentItem.balance.toFixed(2)}
                  </p>
                </>
              )}
              {activeTab === "budgets" && (
                <>
                  <p>
                    <strong>Name:</strong> {currentItem.name}
                  </p>
                  <p>
                    <strong>Allocated:</strong> €{currentItem.allocated.toFixed(2)}
                  </p>
                </>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteItem}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

