"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useData } from "@/contexts/data-context"
import { useAuth } from "@/contexts/auth-context"

export default function SettingsPage() {
  const { toast } = useToast()
  const { user } = useAuth()
  const { resetData } = useData()
  const [activeTab, setActiveTab] = useState("profile")

  // Profile settings
  const [profileSettings, setProfileSettings] = useState({
    name: user?.name || "Admin User",
    email: user?.email || "admin@example.com",
    phone: "+49 123 456789",
    bio: "Systemadministrator mit Zugriff auf alle Funktionen.",
    language: "de",
    timezone: "Europe/Berlin",
  })

  // Company settings
  const [companySettings, setCompanySettings] = useState({
    name: "EnterpriseERP GmbH",
    address: "Musterstraße 123",
    city: "Berlin",
    postalCode: "10115",
    country: "Deutschland",
    phone: "+49 30 123456789",
    email: "info@enterprise-erp.de",
    website: "www.enterprise-erp.de",
    taxId: "DE123456789",
    logo: "/placeholder.svg?height=100&width=200",
  })

  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    orderNotifications: true,
    inventoryAlerts: true,
    financialReports: true,
    systemUpdates: true,
    marketingEmails: false,
  })

  // Security settings
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: false,
    passwordExpiry: "90",
    sessionTimeout: "30",
    ipRestriction: false,
  })

  // System settings
  const [systemSettings, setSystemSettings] = useState({
    language: "de",
    dateFormat: "dd.MM.yyyy",
    timeFormat: "24",
    currency: "EUR",
    theme: "system",
    autoBackup: true,
  })

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfileSettings((prev) => ({ ...prev, [name]: value }))
  }

  const handleCompanyChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setCompanySettings((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (section: string, name: string, value: string) => {
    if (section === "profile") {
      setProfileSettings((prev) => ({ ...prev, [name]: value }))
    } else if (section === "system") {
      setSystemSettings((prev) => ({ ...prev, [name]: value }))
    } else if (section === "security") {
      setSecuritySettings((prev) => ({ ...prev, [name]: value }))
    }
  }

  const handleSwitchChange = (section: string, name: string, checked: boolean) => {
    if (section === "notifications") {
      setNotificationSettings((prev) => ({ ...prev, [name]: checked }))
    } else if (section === "security") {
      setSecuritySettings((prev) => ({ ...prev, [name]: checked }))
    } else if (section === "system") {
      setSystemSettings((prev) => ({ ...prev, [name]: checked }))
    }
  }

  const handleSaveSettings = (section: string) => {
    // In a real app, this would save to a backend
    toast({
      title: "Einstellungen gespeichert",
      description: `Die ${getSectionName(section)}-Einstellungen wurden erfolgreich gespeichert.`,
    })
  }

  const handleResetData = () => {
    if (
      window.confirm(
        "Sind Sie sicher, dass Sie alle Daten zurücksetzen möchten? Diese Aktion kann nicht rückgängig gemacht werden.",
      )
    ) {
      resetData()
      toast({
        title: "Daten zurückgesetzt",
        description: "Alle Daten wurden auf die Standardwerte zurückgesetzt.",
      })
    }
  }

  const getSectionName = (section: string) => {
    switch (section) {
      case "profile":
        return "Profil"
      case "company":
        return "Unternehmen"
      case "notifications":
        return "Benachrichtigungs"
      case "security":
        return "Sicherheits"
      case "system":
        return "System"
      default:
        return ""
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Einstellungen</h1>
        <p className="text-muted-foreground">Verwalten Sie Ihre Konto- und Systemeinstellungen.</p>
      </div>

      <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile">Profil</TabsTrigger>
          <TabsTrigger value="company">Unternehmen</TabsTrigger>
          <TabsTrigger value="notifications">Benachrichtigungen</TabsTrigger>
          <TabsTrigger value="security">Sicherheit</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Profileinstellungen</CardTitle>
              <CardDescription>Verwalten Sie Ihre persönlichen Informationen und Einstellungen.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input id="name" name="name" value={profileSettings.name} onChange={handleProfileChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-Mail</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={profileSettings.email}
                    onChange={handleProfileChange}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input id="phone" name="phone" value={profileSettings.phone} onChange={handleProfileChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Sprache</Label>
                  <Select
                    value={profileSettings.language}
                    onValueChange={(value) => handleSelectChange("profile", "language", value)}
                  >
                    <SelectTrigger id="language">
                      <SelectValue placeholder="Sprache auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="de">Deutsch</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="timezone">Zeitzone</Label>
                <Select
                  value={profileSettings.timezone}
                  onValueChange={(value) => handleSelectChange("profile", "timezone", value)}
                >
                  <SelectTrigger id="timezone">
                    <SelectValue placeholder="Zeitzone auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Europe/Berlin">Europe/Berlin</SelectItem>
                    <SelectItem value="Europe/London">Europe/London</SelectItem>
                    <SelectItem value="America/New_York">America/New_York</SelectItem>
                    <SelectItem value="Asia/Tokyo">Asia/Tokyo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Über mich</Label>
                <Textarea id="bio" name="bio" value={profileSettings.bio} onChange={handleProfileChange} rows={4} />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("profile")}>Speichern</Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Passwort ändern</CardTitle>
              <CardDescription>Ändern Sie Ihr Passwort, um Ihr Konto zu schützen.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword">Aktuelles Passwort</Label>
                <Input id="currentPassword" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="newPassword">Neues Passwort</Label>
                <Input id="newPassword" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Passwort bestätigen</Label>
                <Input id="confirmPassword" type="password" />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button>Passwort ändern</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="company" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Unternehmenseinstellungen</CardTitle>
              <CardDescription>Verwalten Sie die Informationen Ihres Unternehmens.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName">Unternehmensname</Label>
                  <Input id="companyName" name="name" value={companySettings.name} onChange={handleCompanyChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyEmail">E-Mail</Label>
                  <Input
                    id="companyEmail"
                    name="email"
                    type="email"
                    value={companySettings.email}
                    onChange={handleCompanyChange}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyPhone">Telefon</Label>
                  <Input id="companyPhone" name="phone" value={companySettings.phone} onChange={handleCompanyChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyWebsite">Website</Label>
                  <Input
                    id="companyWebsite"
                    name="website"
                    value={companySettings.website}
                    onChange={handleCompanyChange}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="companyAddress">Adresse</Label>
                <Input
                  id="companyAddress"
                  name="address"
                  value={companySettings.address}
                  onChange={handleCompanyChange}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyCity">Stadt</Label>
                  <Input id="companyCity" name="city" value={companySettings.city} onChange={handleCompanyChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyPostalCode">Postleitzahl</Label>
                  <Input
                    id="companyPostalCode"
                    name="postalCode"
                    value={companySettings.postalCode}
                    onChange={handleCompanyChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyCountry">Land</Label>
                  <Input
                    id="companyCountry"
                    name="country"
                    value={companySettings.country}
                    onChange={handleCompanyChange}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="companyTaxId">Steuer-ID</Label>
                <Input id="companyTaxId" name="taxId" value={companySettings.taxId} onChange={handleCompanyChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="companyLogo">Logo</Label>
                <div className="flex items-center gap-4">
                  <img
                    src={companySettings.logo || "/placeholder.svg"}
                    alt="Company Logo"
                    className="h-16 w-32 rounded-md border object-contain p-1"
                  />
                  <Input id="companyLogo" type="file" />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("company")}>Speichern</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Benachrichtigungseinstellungen</CardTitle>
              <CardDescription>Verwalten Sie, wie und wann Sie benachrichtigt werden.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>E-Mail-Benachrichtigungen</Label>
                  <p className="text-sm text-muted-foreground">Erhalten Sie Benachrichtigungen per E-Mail.</p>
                </div>
                <Switch
                  checked={notificationSettings.emailNotifications}
                  onCheckedChange={(checked) => handleSwitchChange("notifications", "emailNotifications", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Auftragsbenachrichtigungen</Label>
                  <p className="text-sm text-muted-foreground">
                    Benachrichtigungen über neue und aktualisierte Aufträge.
                  </p>
                </div>
                <Switch
                  checked={notificationSettings.orderNotifications}
                  onCheckedChange={(checked) => handleSwitchChange("notifications", "orderNotifications", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Bestandsalarme</Label>
                  <p className="text-sm text-muted-foreground">Benachrichtigungen bei niedrigem Lagerbestand.</p>
                </div>
                <Switch
                  checked={notificationSettings.inventoryAlerts}
                  onCheckedChange={(checked) => handleSwitchChange("notifications", "inventoryAlerts", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Finanzberichte</Label>
                  <p className="text-sm text-muted-foreground">Wöchentliche und monatliche Finanzberichte.</p>
                </div>
                <Switch
                  checked={notificationSettings.financialReports}
                  onCheckedChange={(checked) => handleSwitchChange("notifications", "financialReports", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Systemaktualisierungen</Label>
                  <p className="text-sm text-muted-foreground">
                    Benachrichtigungen über Systemaktualisierungen und Wartungen.
                  </p>
                </div>
                <Switch
                  checked={notificationSettings.systemUpdates}
                  onCheckedChange={(checked) => handleSwitchChange("notifications", "systemUpdates", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Marketing-E-Mails</Label>
                  <p className="text-sm text-muted-foreground">Erhalten Sie Marketing- und Werbematerialien.</p>
                </div>
                <Switch
                  checked={notificationSettings.marketingEmails}
                  onCheckedChange={(checked) => handleSwitchChange("notifications", "marketingEmails", checked)}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("notifications")}>Speichern</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sicherheitseinstellungen</CardTitle>
              <CardDescription>Verwalten Sie die Sicherheitseinstellungen Ihres Kontos.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Zwei-Faktor-Authentifizierung</Label>
                  <p className="text-sm text-muted-foreground">Erhöhen Sie die Sicherheit Ihres Kontos mit 2FA.</p>
                </div>
                <Switch
                  checked={securitySettings.twoFactorAuth}
                  onCheckedChange={(checked) => handleSwitchChange("security", "twoFactorAuth", checked)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="passwordExpiry">Passwortablauf (Tage)</Label>
                <Select
                  value={securitySettings.passwordExpiry}
                  onValueChange={(value) => handleSelectChange("security", "passwordExpiry", value)}
                >
                  <SelectTrigger id="passwordExpiry">
                    <SelectValue placeholder="Passwortablauf auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 Tage</SelectItem>
                    <SelectItem value="60">60 Tage</SelectItem>
                    <SelectItem value="90">90 Tage</SelectItem>
                    <SelectItem value="180">180 Tage</SelectItem>
                    <SelectItem value="never">Nie</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="sessionTimeout">Sitzungs-Timeout (Minuten)</Label>
                <Select
                  value={securitySettings.sessionTimeout}
                  onValueChange={(value) => handleSelectChange("security", "sessionTimeout", value)}
                >
                  <SelectTrigger id="sessionTimeout">
                    <SelectValue placeholder="Timeout auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 Minuten</SelectItem>
                    <SelectItem value="30">30 Minuten</SelectItem>
                    <SelectItem value="60">60 Minuten</SelectItem>
                    <SelectItem value="120">120 Minuten</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>IP-Einschränkung</Label>
                  <p className="text-sm text-muted-foreground">
                    Beschränken Sie den Zugriff auf bestimmte IP-Adressen.
                  </p>
                </div>
                <Switch
                  checked={securitySettings.ipRestriction}
                  onCheckedChange={(checked) => handleSwitchChange("security", "ipRestriction", checked)}
                />
              </div>

              <div className="space-y-2">
                <Label>Sitzungsverlauf</Label>
                <div className="rounded-md border p-4">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <div>
                        <p className="font-medium">Berlin, Deutschland</p>
                        <p className="text-sm text-muted-foreground">Chrome auf Windows • 192.168.1.1</p>
                      </div>
                      <p className="text-sm text-muted-foreground">Jetzt</p>
                    </div>
                    <div className="flex justify-between">
                      <div>
                        <p className="font-medium">Frankfurt, Deutschland</p>
                        <p className="text-sm text-muted-foreground">Firefox auf macOS • 192.168.1.2</p>
                      </div>
                      <p className="text-sm text-muted-foreground">Vor 2 Tagen</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("security")}>Speichern</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Systemeinstellungen</CardTitle>
              <CardDescription>Verwalten Sie die allgemeinen Systemeinstellungen.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="systemLanguage">Sprache</Label>
                  <Select
                    value={systemSettings.language}
                    onValueChange={(value) => handleSelectChange("system", "language", value)}
                  >
                    <SelectTrigger id="systemLanguage">
                      <SelectValue placeholder="Sprache auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="de">Deutsch</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dateFormat">Datumsformat</Label>
                  <Select
                    value={systemSettings.dateFormat}
                    onValueChange={(value) => handleSelectChange("system", "dateFormat", value)}
                  >
                    <SelectTrigger id="dateFormat">
                      <SelectValue placeholder="Format auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dd.MM.yyyy">DD.MM.YYYY</SelectItem>
                      <SelectItem value="MM/dd/yyyy">MM/DD/YYYY</SelectItem>
                      <SelectItem value="yyyy-MM-dd">YYYY-MM-DD</SelectItem>
                      <SelectItem value="dd MMM yyyy">DD MMM YYYY</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="timeFormat">Zeitformat</Label>
                  <Select
                    value={systemSettings.timeFormat}
                    onValueChange={(value) => handleSelectChange("system", "timeFormat", value)}
                  >
                    <SelectTrigger id="timeFormat">
                      <SelectValue placeholder="Format auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="12">12-Stunden (AM/PM)</SelectItem>
                      <SelectItem value="24">24-Stunden</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currency">Währung</Label>
                  <Select
                    value={systemSettings.currency}
                    onValueChange={(value) => handleSelectChange("system", "currency", value)}
                  >
                    <SelectTrigger id="currency">
                      <SelectValue placeholder="Währung auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="EUR">Euro (€)</SelectItem>
                      <SelectItem value="USD">US-Dollar ($)</SelectItem>
                      <SelectItem value="GBP">Britisches Pfund (£)</SelectItem>
                      <SelectItem value="JPY">Japanischer Yen (¥)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="theme">Erscheinungsbild</Label>
                <Select
                  value={systemSettings.theme}
                  onValueChange={(value) => handleSelectChange("system", "theme", value)}
                >
                  <SelectTrigger id="theme">
                    <SelectValue placeholder="Thema auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Hell</SelectItem>
                    <SelectItem value="dark">Dunkel</SelectItem>
                    <SelectItem value="system">Systemeinstellung</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Automatische Sicherung</Label>
                  <p className="text-sm text-muted-foreground">Automatische tägliche Sicherung der Daten.</p>
                </div>
                <Switch
                  checked={systemSettings.autoBackup}
                  onCheckedChange={(checked) => handleSwitchChange("system", "autoBackup", checked)}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={() => handleSaveSettings("system")}>Speichern</Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Daten verwalten</CardTitle>
              <CardDescription>Verwalten Sie Ihre Systemdaten und führen Sie Wartungsaufgaben durch.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-medium">Datenbank-Backup</h3>
                <p className="text-sm text-muted-foreground">Erstellen Sie eine Sicherungskopie Ihrer Datenbank.</p>
                <Button variant="outline">Backup erstellen</Button>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Daten importieren</h3>
                <p className="text-sm text-muted-foreground">Importieren Sie Daten aus einer CSV- oder Excel-Datei.</p>
                <Button variant="outline">Daten importieren</Button>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Daten exportieren</h3>
                <p className="text-sm text-muted-foreground">Exportieren Sie Ihre Daten in verschiedene Formate.</p>
                <Button variant="outline">Daten exportieren</Button>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Daten zurücksetzen</h3>
                <p className="text-sm text-muted-foreground">
                  Setzen Sie alle Daten auf die Standardwerte zurück. Diese Aktion kann nicht rückgängig gemacht werden.
                </p>
                <Button variant="destructive" onClick={handleResetData}>
                  Daten zurücksetzen
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

