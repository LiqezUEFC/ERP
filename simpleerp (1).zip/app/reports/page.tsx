"use client"

import { useState } from "react"
import { useData } from "@/contexts/data-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Download, Printer, Share2, Users, ShoppingCart, Package, DollarSign } from "lucide-react"

export default function ReportsPage() {
  const { data, loading } = useData()
  const [activeTab, setActiveTab] = useState("sales")

  if (loading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-24" />
        </div>
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-[600px] w-full" />
      </div>
    )
  }

  // Format currency helper
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("de-DE", {
      style: "currency",
      currency: "EUR",
    }).format(amount || 0)
  }

  // Count items in each category
  const countItems = (items = []) => {
    return items.length
  }

  // Calculate total value
  const calculateTotal = (items = []) => {
    return items.reduce((sum, item) => sum + (item.total || 0), 0)
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Berichte & Analysen</h1>
          <p className="text-muted-foreground">Detaillierte Einblicke in Ihre Geschäftsdaten</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Exportieren
          </Button>
          <Button variant="outline" size="sm">
            <Printer className="mr-2 h-4 w-4" />
            Drucken
          </Button>
          <Button variant="outline" size="sm">
            <Share2 className="mr-2 h-4 w-4" />
            Teilen
          </Button>
        </div>
      </div>

      <Tabs defaultValue="sales" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sales" className="flex items-center gap-2">
            <ShoppingCart className="h-4 w-4" />
            <span className="hidden sm:inline">Verkauf</span>
          </TabsTrigger>
          <TabsTrigger value="inventory" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            <span className="hidden sm:inline">Inventar</span>
          </TabsTrigger>
          <TabsTrigger value="finance" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            <span className="hidden sm:inline">Finanzen</span>
          </TabsTrigger>
          <TabsTrigger value="customers" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Kunden</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sales" className="space-y-4 mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Gesamtumsatz</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(calculateTotal(data?.salesOrders))}</div>
                <p className="text-xs text-muted-foreground">{countItems(data?.salesOrders)} Aufträge insgesamt</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Anzahl Kunden</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{countItems(data?.customers)}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Anzahl Produkte</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{countItems(data?.products)}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Anzahl Transaktionen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{countItems(data?.transactions)}</div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Verkaufsübersicht</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Detaillierte Verkaufsberichte werden hier angezeigt.</p>
              <p className="mt-2">Für diese Demo-Version sind keine detaillierten Daten verfügbar.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Inventarübersicht</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Detaillierte Inventarberichte werden hier angezeigt.</p>
              <p className="mt-2">Für diese Demo-Version sind keine detaillierten Daten verfügbar.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="finance" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Finanzübersicht</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Detaillierte Finanzberichte werden hier angezeigt.</p>
              <p className="mt-2">Für diese Demo-Version sind keine detaillierten Daten verfügbar.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customers" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Kundenübersicht</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Detaillierte Kundenberichte werden hier angezeigt.</p>
              <p className="mt-2">Für diese Demo-Version sind keine detaillierten Daten verfügbar.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

