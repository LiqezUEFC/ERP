"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import {
  FileText,
  FilePlus,
  FolderPlus,
  Search,
  Filter,
  MoreHorizontal,
  Download,
  Edit,
  Trash2,
  Share2,
  Eye,
  File,
  FileImage,
  FileSpreadsheet,
  FileIcon as FilePdf,
} from "lucide-react"

export default function DocumentsPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddDocumentDialogOpen, setIsAddDocumentDialogOpen] = useState(false)
  const [isAddFolderDialogOpen, setIsAddFolderDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedItem, setSelectedItem] = useState<any>(null)

  // Sample data for documents
  const [documents, setDocuments] = useState([
    {
      id: "doc1",
      name: "Verkaufsbericht Q1 2023.pdf",
      type: "pdf",
      size: "2.4 MB",
      folder: "Berichte",
      createdBy: "Max Mustermann",
      createdAt: "2023-04-15",
      tags: ["Verkauf", "Bericht", "Q1"],
    },
    {
      id: "doc2",
      name: "Produktkatalog 2023.pdf",
      type: "pdf",
      size: "5.7 MB",
      folder: "Marketing",
      createdBy: "Anna Schmidt",
      createdAt: "2023-03-10",
      tags: ["Produkte", "Katalog"],
    },
    {
      id: "doc3",
      name: "Mitarbeiterliste.xlsx",
      type: "excel",
      size: "1.2 MB",
      folder: "Personal",
      createdBy: "Thomas Weber",
      createdAt: "2023-02-28",
      tags: ["Personal", "Liste"],
    },
    {
      id: "doc4",
      name: "Projektplan ERP-System.docx",
      type: "word",
      size: "843 KB",
      folder: "Projekte",
      createdBy: "Lisa Müller",
      createdAt: "2023-05-02",
      tags: ["Projekt", "Plan", "ERP"],
    },
    {
      id: "doc5",
      name: "Firmenlogo.png",
      type: "image",
      size: "256 KB",
      folder: "Marketing",
      createdBy: "Anna Schmidt",
      createdAt: "2023-01-15",
      tags: ["Logo", "Branding"],
    },
  ])

  // Sample data for folders
  const [folders, setFolders] = useState([
    { id: "folder1", name: "Berichte", documentsCount: 12, createdAt: "2023-01-10" },
    { id: "folder2", name: "Marketing", documentsCount: 8, createdAt: "2023-01-10" },
    { id: "folder3", name: "Personal", documentsCount: 5, createdAt: "2023-01-15" },
    { id: "folder4", name: "Projekte", documentsCount: 7, createdAt: "2023-02-20" },
    { id: "folder5", name: "Finanzen", documentsCount: 10, createdAt: "2023-01-05" },
  ])

  // Form state for new document
  const [newDocument, setNewDocument] = useState({
    name: "",
    folder: "",
    tags: "",
  })

  // Form state for new folder
  const [newFolder, setNewFolder] = useState({
    name: "",
  })

  // Filter documents based on active tab and search term
  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.folder.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    if (activeTab === "all") return matchesSearch
    if (activeTab === "pdf") return doc.type === "pdf" && matchesSearch
    if (activeTab === "excel") return doc.type === "excel" && matchesSearch
    if (activeTab === "word") return doc.type === "word" && matchesSearch
    if (activeTab === "images") return doc.type === "image" && matchesSearch

    return false
  })

  // Handle adding a new document
  const handleAddDocument = () => {
    if (!newDocument.name || !newDocument.folder) {
      toast({
        title: "Fehler",
        description: "Bitte füllen Sie alle Pflichtfelder aus.",
        variant: "destructive",
      })
      return
    }

    // Determine document type from file extension
    const extension = newDocument.name.split(".").pop()?.toLowerCase() || ""
    let type = "other"

    if (extension === "pdf") type = "pdf"
    else if (["xlsx", "xls", "csv"].includes(extension)) type = "excel"
    else if (["docx", "doc"].includes(extension)) type = "word"
    else if (["jpg", "jpeg", "png", "gif", "svg"].includes(extension)) type = "image"

    const newDoc = {
      id: `doc${documents.length + 1}`,
      name: newDocument.name,
      type,
      size: "0 KB", // In a real app, this would be the actual file size
      folder: newDocument.folder,
      createdBy: "Aktueller Benutzer", // In a real app, this would be the current user
      createdAt: new Date().toISOString().split("T")[0],
      tags: newDocument.tags ? newDocument.tags.split(",").map((tag) => tag.trim()) : [],
    }

    setDocuments([...documents, newDoc])
    setNewDocument({ name: "", folder: "", tags: "" })
    setIsAddDocumentDialogOpen(false)

    toast({
      title: "Dokument hinzugefügt",
      description: `${newDoc.name} wurde erfolgreich hinzugefügt.`,
    })
  }

  // Handle adding a new folder
  const handleAddFolder = () => {
    if (!newFolder.name) {
      toast({
        title: "Fehler",
        description: "Bitte geben Sie einen Ordnernamen ein.",
        variant: "destructive",
      })
      return
    }

    const newFolderObj = {
      id: `folder${folders.length + 1}`,
      name: newFolder.name,
      documentsCount: 0,
      createdAt: new Date().toISOString().split("T")[0],
    }

    setFolders([...folders, newFolderObj])
    setNewFolder({ name: "" })
    setIsAddFolderDialogOpen(false)

    toast({
      title: "Ordner erstellt",
      description: `Ordner "${newFolderObj.name}" wurde erfolgreich erstellt.`,
    })
  }

  // Handle deleting an item (document or folder)
  const handleDeleteItem = () => {
    if (!selectedItem) return

    if (selectedItem.type) {
      // It's a document
      setDocuments(documents.filter((doc) => doc.id !== selectedItem.id))
      toast({
        title: "Dokument gelöscht",
        description: `${selectedItem.name} wurde erfolgreich gelöscht.`,
      })
    } else {
      // It's a folder
      setFolders(folders.filter((folder) => folder.id !== selectedItem.id))
      toast({
        title: "Ordner gelöscht",
        description: `Ordner "${selectedItem.name}" wurde erfolgreich gelöscht.`,
      })
    }

    setIsDeleteDialogOpen(false)
    setSelectedItem(null)
  }

  // Get icon based on document type
  const getDocumentIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FilePdf className="h-6 w-6 text-red-500" />
      case "excel":
        return <FileSpreadsheet className="h-6 w-6 text-green-500" />
      case "word":
        return <FileText className="h-6 w-6 text-blue-500" />
      case "image":
        return <FileImage className="h-6 w-6 text-purple-500" />
      default:
        return <File className="h-6 w-6 text-gray-500" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dokumente</h1>
          <p className="text-muted-foreground">Verwalten Sie Ihre Dokumente und Dateien</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isAddDocumentDialogOpen} onOpenChange={setIsAddDocumentDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <FilePlus className="mr-2 h-4 w-4" />
                Dokument hinzufügen
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Neues Dokument hinzufügen</DialogTitle>
                <DialogDescription>Laden Sie ein neues Dokument hoch oder erstellen Sie ein neues.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Dokumentname</Label>
                  <Input
                    id="name"
                    value={newDocument.name}
                    onChange={(e) => setNewDocument({ ...newDocument, name: e.target.value })}
                    placeholder="beispiel.pdf"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="folder">Ordner</Label>
                  <Select
                    value={newDocument.folder}
                    onValueChange={(value) => setNewDocument({ ...newDocument, folder: value })}
                  >
                    <SelectTrigger id="folder">
                      <SelectValue placeholder="Ordner auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {folders.map((folder) => (
                        <SelectItem key={folder.id} value={folder.name}>
                          {folder.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="tags">Tags (durch Komma getrennt)</Label>
                  <Input
                    id="tags"
                    value={newDocument.tags}
                    onChange={(e) => setNewDocument({ ...newDocument, tags: e.target.value })}
                    placeholder="tag1, tag2, tag3"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="file">Datei</Label>
                  <Input id="file" type="file" />
                  <p className="text-sm text-muted-foreground">Maximale Dateigröße: 10MB</p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDocumentDialogOpen(false)}>
                  Abbrechen
                </Button>
                <Button onClick={handleAddDocument}>Hochladen</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddFolderDialogOpen} onOpenChange={setIsAddFolderDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <FolderPlus className="mr-2 h-4 w-4" />
                Ordner erstellen
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Neuen Ordner erstellen</DialogTitle>
                <DialogDescription>
                  Erstellen Sie einen neuen Ordner zur Organisation Ihrer Dokumente.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="folderName">Ordnername</Label>
                  <Input
                    id="folderName"
                    value={newFolder.name}
                    onChange={(e) => setNewFolder({ ...newFolder, name: e.target.value })}
                    placeholder="Neuer Ordner"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddFolderDialogOpen(false)}>
                  Abbrechen
                </Button>
                <Button onClick={handleAddFolder}>Erstellen</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Dokumente durchsuchen..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline" size="icon">
          <Filter className="h-4 w-4" />
          <span className="sr-only">Filter</span>
        </Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">Alle Dokumente</TabsTrigger>
          <TabsTrigger value="pdf">PDF</TabsTrigger>
          <TabsTrigger value="excel">Excel</TabsTrigger>
          <TabsTrigger value="word">Word</TabsTrigger>
          <TabsTrigger value="images">Bilder</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {folders.map((folder) => (
              <Card key={folder.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <FolderPlus className="h-5 w-5 text-yellow-500" />
                    {folder.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{folder.documentsCount} Dokumente</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <p className="text-xs text-muted-foreground">Erstellt am {folder.createdAt}</p>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Aktionen</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Aktionen</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" />
                        Umbenennen
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => {
                          setSelectedItem(folder)
                          setIsDeleteDialogOpen(true)
                        }}
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Löschen
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Ordner</TableHead>
                  <TableHead>Größe</TableHead>
                  <TableHead>Erstellt von</TableHead>
                  <TableHead>Erstellt am</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead className="text-right">Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      Keine Dokumente gefunden
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredDocuments.map((document) => (
                    <TableRow key={document.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getDocumentIcon(document.type)}
                          <span>{document.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{document.folder}</TableCell>
                      <TableCell>{document.size}</TableCell>
                      <TableCell>{document.createdBy}</TableCell>
                      <TableCell>{document.createdAt}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {document.tags.map((tag, index) => (
                            <Badge key={index} variant="outline">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Aktionen</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Aktionen</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              Anzeigen
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              Herunterladen
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Share2 className="mr-2 h-4 w-4" />
                              Teilen
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Bearbeiten
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => {
                                setSelectedItem(document)
                                setIsDeleteDialogOpen(true)
                              }}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Löschen
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="pdf" className="space-y-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Ordner</TableHead>
                  <TableHead>Größe</TableHead>
                  <TableHead>Erstellt am</TableHead>
                  <TableHead className="text-right">Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Keine PDF-Dokumente gefunden
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredDocuments.map((document) => (
                    <TableRow key={document.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FilePdf className="h-5 w-5 text-red-500" />
                          <span>{document.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{document.folder}</TableCell>
                      <TableCell>{document.size}</TableCell>
                      <TableCell>{document.createdAt}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="excel" className="space-y-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Ordner</TableHead>
                  <TableHead>Größe</TableHead>
                  <TableHead>Erstellt am</TableHead>
                  <TableHead className="text-right">Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Keine Excel-Dokumente gefunden
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredDocuments.map((document) => (
                    <TableRow key={document.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileSpreadsheet className="h-5 w-5 text-green-500" />
                          <span>{document.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{document.folder}</TableCell>
                      <TableCell>{document.size}</TableCell>
                      <TableCell>{document.createdAt}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="word" className="space-y-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Ordner</TableHead>
                  <TableHead>Größe</TableHead>
                  <TableHead>Erstellt am</TableHead>
                  <TableHead className="text-right">Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Keine Word-Dokumente gefunden
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredDocuments.map((document) => (
                    <TableRow key={document.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileText className="h-5 w-5 text-blue-500" />
                          <span>{document.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{document.folder}</TableCell>
                      <TableCell>{document.size}</TableCell>
                      <TableCell>{document.createdAt}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="images" className="space-y-4">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Ordner</TableHead>
                  <TableHead>Größe</TableHead>
                  <TableHead>Erstellt am</TableHead>
                  <TableHead className="text-right">Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Keine Bilder gefunden
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredDocuments.map((document) => (
                    <TableRow key={document.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileImage className="h-5 w-5 text-purple-500" />
                          <span>{document.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{document.folder}</TableCell>
                      <TableCell>{document.size}</TableCell>
                      <TableCell>{document.createdAt}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* Delete confirmation dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Löschen bestätigen</DialogTitle>
            <DialogDescription>
              Sind Sie sicher, dass Sie dieses Element löschen möchten? Diese Aktion kann nicht rückgängig gemacht
              werden.
            </DialogDescription>
          </DialogHeader>
          {selectedItem && (
            <div className="py-4">
              <p>
                <strong>Name:</strong> {selectedItem.name}
              </p>
              {selectedItem.type && (
                <p>
                  <strong>Typ:</strong> {selectedItem.type.toUpperCase()}
                </p>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Abbrechen
            </Button>
            <Button variant="destructive" onClick={handleDeleteItem}>
              Löschen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

