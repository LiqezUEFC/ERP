"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useData } from "@/contexts/data-context"

export default function NewProductPage() {
  const router = useRouter()
  const { data, loading } = useData()
  const suppliers = data?.suppliers || []
  const isLoading = loading

  // Safe wrapper for addProduct
  const addProduct = (productData: any) => {
    if (data && typeof data.addItem === "function") {
      // Generate a unique ID for the new product
      const newProduct = {
        ...productData,
        id: `prod-${Date.now()}`,
        status:
          productData.quantity > productData.reorderLevel
            ? "In Stock"
            : productData.quantity > 0
              ? "Low Stock"
              : "Out of Stock",
        lastUpdated: new Date().toISOString(),
      }
      data.addItem("products", newProduct)
    }
  }
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    name: "",
    category: "",
    subcategory: "",
    sku: "",
    price: "",
    cost: "",
    quantity: "",
    reorderLevel: "",
    supplier: "",
    location: "",
    description: "",
  })

  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Lade Daten...</h2>
          <p className="text-muted-foreground">Bitte warten Sie einen Moment.</p>
        </div>
      </div>
    )
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (
      !formData.name ||
      !formData.category ||
      !formData.sku ||
      !formData.price ||
      !formData.cost ||
      !formData.quantity ||
      !formData.reorderLevel ||
      !formData.supplier
    ) {
      toast({
        title: "Fehler",
        description: "Bitte füllen Sie alle Pflichtfelder aus.",
        variant: "destructive",
      })
      return
    }

    try {
      // Convert string values to numbers
      const productData = {
        ...formData,
        price: Number.parseFloat(formData.price) || 0,
        cost: Number.parseFloat(formData.cost) || 0,
        quantity: Number.parseInt(formData.quantity) || 0,
        reorderLevel: Number.parseInt(formData.reorderLevel) || 0,
      }

      addProduct(productData)

      toast({
        title: "Produkt hinzugefügt",
        description: `${formData.name} wurde erfolgreich hinzugefügt.`,
      })

      router.push("/inventory/products")
    } catch (error) {
      console.error("Error adding product:", error)
      toast({
        title: "Fehler",
        description: "Beim Hinzufügen des Produkts ist ein Fehler aufgetreten.",
        variant: "destructive",
      })
    }
  }

  // Get unique categories from products
  const categories = ["Elektronik", "Bürobedarf", "Möbel", "Software", "Hardware", "Sonstiges"]

  const subcategories: Record<string, string[]> = {
    Elektronik: ["Computer", "Telefone", "Tablets", "Zubehör"],
    Bürobedarf: ["Papier", "Stifte", "Ordner", "Druckerzubehör"],
    Möbel: ["Schreibtische", "Stühle", "Schränke", "Regale"],
    Software: ["Betriebssysteme", "Office", "Sicherheit", "Design"],
    Hardware: ["Prozessoren", "Speicher", "Grafikkarten", "Netzwerk"],
    Sonstiges: ["Diverses"],
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Neues Produkt</h1>
        <p className="text-muted-foreground">Fügen Sie ein neues Produkt zu Ihrem Inventar hinzu.</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Produktinformationen</CardTitle>
              <CardDescription>Grundlegende Informationen über das Produkt</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name *</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="category">Kategorie *</Label>
                  <Select value={formData.category} onValueChange={(value) => handleSelectChange("category", value)}>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Kategorie auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subcategory">Unterkategorie</Label>
                  <Select
                    value={formData.subcategory}
                    onValueChange={(value) => handleSelectChange("subcategory", value)}
                    disabled={!formData.category}
                  >
                    <SelectTrigger id="subcategory">
                      <SelectValue placeholder="Unterkategorie auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      {formData.category &&
                        (subcategories[formData.category as keyof typeof subcategories] || []).map((subcategory) => (
                          <SelectItem key={subcategory} value={subcategory}>
                            {subcategory}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="sku">SKU *</Label>
                <Input id="sku" name="sku" value={formData.sku} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Beschreibung</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Preis- und Bestandsinformationen</CardTitle>
              <CardDescription>Informationen zu Preis, Kosten und Bestand</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="price">Verkaufspreis (€) *</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.price}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cost">Einkaufspreis (€) *</Label>
                  <Input
                    id="cost"
                    name="cost"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.cost}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Bestand *</Label>
                  <Input
                    id="quantity"
                    name="quantity"
                    type="number"
                    min="0"
                    value={formData.quantity}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reorderLevel">Mindestbestand *</Label>
                  <Input
                    id="reorderLevel"
                    name="reorderLevel"
                    type="number"
                    min="0"
                    value={formData.reorderLevel}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="supplier">Lieferant *</Label>
                <Select value={formData.supplier} onValueChange={(value) => handleSelectChange("supplier", value)}>
                  <SelectTrigger id="supplier">
                    <SelectValue placeholder="Lieferant auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    {(suppliers || []).map((supplier) => (
                      <SelectItem key={supplier?.id || `supplier-${Math.random()}`} value={supplier?.id || ""}>
                        {supplier?.name || "Unnamed Supplier"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Lagerort</Label>
                <Input id="location" name="location" value={formData.location} onChange={handleChange} />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6 flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={() => router.push("/inventory/products")}>
            Abbrechen
          </Button>
          <Button type="submit">Produkt speichern</Button>
        </div>
      </form>
    </div>
  )
}

