"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useData } from "@/contexts/data-context"
import {
  AlertCircle,
  ArrowUpRight,
  BarChart3,
  Box,
  Package,
  PackageCheck,
  PackageOpen,
  ShoppingCart,
  Truck,
} from "lucide-react"

export default function InventoryPage() {
  const { data, loading: isLoading } = useData()
  const [activeTab, setActiveTab] = useState("overview")

  if (isLoading || !data) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Lade Inventardaten...</h2>
          <p className="text-muted-foreground">Bitte warten Sie einen Moment.</p>
        </div>
      </div>
    )
  }

  const products = data.products || []
  const suppliers = data.suppliers || []
  const purchaseOrders = data.purchaseOrders || []

  // Calculate inventory statistics
  const totalProducts = products.length
  const lowStockProducts = products.filter((product) => product.status === "Low Stock").length
  const outOfStockProducts = products.filter((product) => product.status === "Out of Stock").length
  const activeSuppliers = suppliers.filter((supplier) => supplier.status === "Active").length
  const pendingOrders = purchaseOrders.filter((order) => order.status === "Ordered").length

  // Calculate inventory value
  const inventoryValue = products.reduce((total, product) => {
    return total + product.price * product.quantity
  }, 0)

  // Get top 5 products by value
  const topProductsByValue = [...products].sort((a, b) => b.price * b.quantity - a.price * a.quantity).slice(0, 5)

  // Get low stock products
  const lowStockProductsList = products
    .filter((product) => product.status === "Low Stock" || product.status === "Out of Stock")
    .slice(0, 5)

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inventar</h1>
          <p className="text-muted-foreground">Verwalten Sie Ihre Produkte, Bestände und Lieferanten.</p>
        </div>
        <div className="flex gap-2">
          <Button asChild>
            <Link href="/inventory/products">Produkte verwalten</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/inventory/products/new">+ Produkt hinzufügen</Link>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 md:w-auto">
          <TabsTrigger value="overview">Übersicht</TabsTrigger>
          <TabsTrigger value="products">Produkte</TabsTrigger>
          <TabsTrigger value="suppliers">Lieferanten</TabsTrigger>
          <TabsTrigger value="orders">Bestellungen</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Gesamtprodukte</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalProducts}</div>
                <p className="text-xs text-muted-foreground">
                  {products.filter((p) => p.status === "In Stock").length} auf Lager
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Bestandswert</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(inventoryValue)}
                </div>
                <p className="text-xs text-muted-foreground">{products.length} Produkte insgesamt</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Niedriger Bestand</CardTitle>
                <AlertCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{lowStockProducts + outOfStockProducts}</div>
                <p className="text-xs text-muted-foreground">{outOfStockProducts} nicht auf Lager</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Offene Bestellungen</CardTitle>
                <Truck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{pendingOrders}</div>
                <p className="text-xs text-muted-foreground">Von {activeSuppliers} aktiven Lieferanten</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Top Produkte nach Wert</CardTitle>
                <CardDescription>Die 5 wertvollsten Produkte im Inventar</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topProductsByValue.map((product) => (
                    <div key={product.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Box className="h-8 w-8 rounded-full bg-primary/10 p-1.5 text-primary" />
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {product.quantity} ×{" "}
                            {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(
                              product.price,
                            )}
                          </p>
                        </div>
                      </div>
                      <div className="font-medium">
                        {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(
                          product.price * product.quantity,
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Niedriger Bestand</CardTitle>
                <CardDescription>Produkte, die nachbestellt werden müssen</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {lowStockProductsList.length > 0 ? (
                    lowStockProductsList.map((product) => (
                      <div key={product.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {product.status === "Out of Stock" ? (
                            <PackageOpen className="h-8 w-8 rounded-full bg-destructive/10 p-1.5 text-destructive" />
                          ) : (
                            <PackageCheck className="h-8 w-8 rounded-full bg-warning/10 p-1.5 text-warning" />
                          )}
                          <div>
                            <p className="font-medium">{product.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {product.quantity} auf Lager (Min: {product.reorderLevel})
                            </p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="gap-1" asChild>
                          <Link href={`/inventory/products/${product.id}`}>
                            Details
                            <ArrowUpRight className="h-4 w-4" />
                          </Link>
                        </Button>
                      </div>
                    ))
                  ) : (
                    <div className="flex flex-col items-center justify-center py-8 text-center">
                      <PackageCheck className="mb-2 h-10 w-10 text-primary" />
                      <h3 className="mb-1 text-lg font-medium">Alle Bestände OK</h3>
                      <p className="text-sm text-muted-foreground">Alle Produkte haben ausreichenden Bestand.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Schnellzugriff</CardTitle>
              <CardDescription>Häufig verwendete Inventarfunktionen</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                <Button className="h-auto flex-col items-center justify-center gap-2 p-4" variant="outline" asChild>
                  <Link href="/inventory/products/new">
                    <Package className="h-8 w-8" />
                    <span>Produkt hinzufügen</span>
                  </Link>
                </Button>
                <Button className="h-auto flex-col items-center justify-center gap-2 p-4" variant="outline" asChild>
                  <Link href="/inventory/suppliers/new">
                    <Truck className="h-8 w-8" />
                    <span>Lieferant hinzufügen</span>
                  </Link>
                </Button>
                <Button className="h-auto flex-col items-center justify-center gap-2 p-4" variant="outline" asChild>
                  <Link href="/inventory/purchase-orders/new">
                    <ShoppingCart className="h-8 w-8" />
                    <span>Bestellung erstellen</span>
                  </Link>
                </Button>
                <Button className="h-auto flex-col items-center justify-center gap-2 p-4" variant="outline" asChild>
                  <Link href="/inventory/reports">
                    <BarChart3 className="h-8 w-8" />
                    <span>Bestandsberichte</span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Produktübersicht</CardTitle>
              <CardDescription>Alle Produkte in Ihrem Inventar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <Button asChild>
                    <Link href="/inventory/products">Alle Produkte anzeigen</Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/inventory/products/new">+ Produkt hinzufügen</Link>
                  </Button>
                </div>

                <div className="rounded-md border">
                  <div className="grid grid-cols-5 border-b p-3 font-medium">
                    <div>Name</div>
                    <div>Kategorie</div>
                    <div>Preis</div>
                    <div>Bestand</div>
                    <div>Status</div>
                  </div>
                  {products.slice(0, 5).map((product) => (
                    <div key={product.id} className="grid grid-cols-5 items-center p-3">
                      <div className="font-medium">{product.name}</div>
                      <div>{product.category}</div>
                      <div>
                        {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(product.price)}
                      </div>
                      <div>{product.quantity}</div>
                      <div>
                        <span
                          className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                            product.status === "In Stock"
                              ? "bg-green-100 text-green-800"
                              : product.status === "Low Stock"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }`}
                        >
                          {product.status === "In Stock"
                            ? "Auf Lager"
                            : product.status === "Low Stock"
                              ? "Niedriger Bestand"
                              : "Nicht auf Lager"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="suppliers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Lieferantenübersicht</CardTitle>
              <CardDescription>Alle Lieferanten in Ihrem System</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <Button asChild>
                    <Link href="/inventory/suppliers">Alle Lieferanten anzeigen</Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/inventory/suppliers/new">+ Lieferant hinzufügen</Link>
                  </Button>
                </div>

                <div className="rounded-md border">
                  <div className="grid grid-cols-4 border-b p-3 font-medium">
                    <div>Name</div>
                    <div>Kontakt</div>
                    <div>Zahlungsbedingungen</div>
                    <div>Status</div>
                  </div>
                  {suppliers.slice(0, 5).map((supplier) => (
                    <div key={supplier.id} className="grid grid-cols-4 items-center p-3">
                      <div className="font-medium">{supplier.name}</div>
                      <div>{supplier.contactName}</div>
                      <div>{supplier.paymentTerms}</div>
                      <div>
                        <span
                          className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                            supplier.status === "Active" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                          }`}
                        >
                          {supplier.status === "Active" ? "Aktiv" : "Inaktiv"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bestellungsübersicht</CardTitle>
              <CardDescription>Alle Einkaufsbestellungen</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <Button asChild>
                    <Link href="/inventory/purchase-orders">Alle Bestellungen anzeigen</Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/inventory/purchase-orders/new">+ Bestellung erstellen</Link>
                  </Button>
                </div>

                <div className="rounded-md border">
                  <div className="grid grid-cols-5 border-b p-3 font-medium">
                    <div>Bestellnr.</div>
                    <div>Lieferant</div>
                    <div>Datum</div>
                    <div>Gesamtbetrag</div>
                    <div>Status</div>
                  </div>
                  {purchaseOrders.slice(0, 5).map((order) => (
                    <div key={order.id} className="grid grid-cols-5 items-center p-3">
                      <div className="font-medium">{order.id}</div>
                      <div>{order.supplierName}</div>
                      <div>{new Date(order.date).toLocaleDateString("de-DE")}</div>
                      <div>
                        {new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(order.total)}
                      </div>
                      <div>
                        <span
                          className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                            order.status === "Received"
                              ? "bg-green-100 text-green-800"
                              : order.status === "Ordered"
                                ? "bg-blue-100 text-blue-800"
                                : order.status === "Draft"
                                  ? "bg-gray-100 text-gray-800"
                                  : "bg-red-100 text-red-800"
                          }`}
                        >
                          {order.status === "Received"
                            ? "Erhalten"
                            : order.status === "Ordered"
                              ? "Bestellt"
                              : order.status === "Draft"
                                ? "Entwurf"
                                : "Storniert"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

