"use client"

import { useState } from "react"
import { useData, type Employee } from "@/contexts/data-context"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Plus, Search, Filter, MoreHorizontal, Edit, Trash2, Download, Upload, FileText, Mail } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { format } from "date-fns"

export default function EmployeesPage() {
  const { data, isLoading = false, addItem, updateItem, deleteItem } = useData()
  const employees = data?.employees || []

  const [searchTerm, setSearchTerm] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState<string | null>(null)
  const [statusFilter, setStatusFilter] = useState<string | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(null)

  const [newEmployee, setNewEmployee] = useState<Omit<Employee, "id">>({
    name: "",
    email: "",
    phone: "",
    department: "",
    position: "",
    joinDate: new Date().toISOString().split("T")[0],
    salary: 0,
    status: "Active",
    manager: "",
    address: "",
    emergencyContact: "",
  })

  // Get unique departments for filter
  const departments = [...new Set((employees || []).map((employee) => employee?.department || "").filter(Boolean))]

  // Apply filters
  const filteredEmployees = (employees || []).filter((employee) => {
    if (!employee) return false

    const matchesSearch =
      (employee.name || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (employee.email || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (employee.position || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (employee.id || "").toLowerCase().includes(searchTerm.toLowerCase())

    const matchesDepartment = !departmentFilter || employee.department === departmentFilter
    const matchesStatus = !statusFilter || employee.status === statusFilter

    return matchesSearch && matchesDepartment && matchesStatus
  })

  const addEmployee = (employee: Omit<Employee, "id">) => {
    if (addItem) {
      const id = Math.random().toString(36).substring(2, 10)
      addItem("employees", { id, ...employee })
    }
  }
  const updateEmployee = (id: string, employee: Partial<Employee>) => {
    if (updateItem) {
      updateItem("employees", id, employee)
    }
  }
  const deleteEmployee = (id: string) => {
    if (deleteItem) {
      deleteItem("employees", id)
    }
  }

  const handleAddEmployee = () => {
    addEmployee(newEmployee)
    setNewEmployee({
      name: "",
      email: "",
      phone: "",
      department: "",
      position: "",
      joinDate: new Date().toISOString().split("T")[0],
      salary: 0,
      status: "Active",
      manager: "",
      address: "",
      emergencyContact: "",
    })
    setIsAddDialogOpen(false)
  }

  const handleEditEmployee = () => {
    if (currentEmployee) {
      updateEmployee(currentEmployee.id, currentEmployee)
      setIsEditDialogOpen(false)
    }
  }

  const handleDeleteEmployee = () => {
    if (currentEmployee) {
      deleteEmployee(currentEmployee.id)
      setIsDeleteDialogOpen(false)
    }
  }

  const openEditDialog = (employee: Employee) => {
    setCurrentEmployee({ ...employee })
    setIsEditDialogOpen(true)
  }

  const openDeleteDialog = (employee: Employee) => {
    setCurrentEmployee(employee)
    setIsDeleteDialogOpen(true)
  }

  const openViewDialog = (employee: Employee) => {
    setCurrentEmployee(employee)
    setIsViewDialogOpen(true)
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return ""
    try {
      const date = new Date(dateString)
      if (isNaN(date.getTime())) return dateString
      return format(date, "dd.MM.yyyy")
    } catch (error) {
      return dateString
    }
  }

  const formatCurrency = (amount: number) => {
    if (amount === undefined || amount === null) return "€0.00"
    try {
      return amount.toLocaleString("de-DE", {
        style: "currency",
        currency: "EUR",
      })
    } catch (error) {
      return "€" + amount
    }
  }

  if (isLoading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-24" />
        </div>
        <div className="flex items-center gap-2">
          <Skeleton className="h-10 flex-1 md:max-w-sm" />
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
        <Skeleton className="h-[500px] w-full" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Mitarbeiter</h1>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Mitarbeiter hinzufügen
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Neuen Mitarbeiter hinzufügen</DialogTitle>
              <DialogDescription>Geben Sie die Details des neuen Mitarbeiters ein.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={newEmployee.name}
                    onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-Mail</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newEmployee.email}
                    onChange={(e) => setNewEmployee({ ...newEmployee, email: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input
                    id="phone"
                    value={newEmployee.phone}
                    onChange={(e) => setNewEmployee({ ...newEmployee, phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="joinDate">Eintrittsdatum</Label>
                  <Input
                    id="joinDate"
                    type="date"
                    value={newEmployee.joinDate}
                    onChange={(e) => setNewEmployee({ ...newEmployee, joinDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="department">Abteilung</Label>
                  <Select
                    value={newEmployee.department}
                    onValueChange={(value) => setNewEmployee({ ...newEmployee, department: value })}
                  >
                    <SelectTrigger id="department">
                      <SelectValue placeholder="Abteilung auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Engineering">Engineering</SelectItem>
                      <SelectItem value="Marketing">Marketing</SelectItem>
                      <SelectItem value="Finance">Finance</SelectItem>
                      <SelectItem value="Human Resources">Human Resources</SelectItem>
                      <SelectItem value="Sales">Sales</SelectItem>
                      <SelectItem value="Operations">Operations</SelectItem>
                      <SelectItem value="IT">IT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="position">Position</Label>
                  <Input
                    id="position"
                    value={newEmployee.position}
                    onChange={(e) => setNewEmployee({ ...newEmployee, position: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="salary">Gehalt (€)</Label>
                  <Input
                    id="salary"
                    type="number"
                    value={newEmployee.salary}
                    onChange={(e) => setNewEmployee({ ...newEmployee, salary: Number.parseFloat(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={newEmployee.status}
                    onValueChange={(value) =>
                      setNewEmployee({ ...newEmployee, status: value as "Active" | "On Leave" | "Terminated" })
                    }
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Status auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Active">Aktiv</SelectItem>
                      <SelectItem value="On Leave">Beurlaubt</SelectItem>
                      <SelectItem value="Terminated">Gekündigt</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="manager">Vorgesetzter</Label>
                <Select
                  value={newEmployee.manager || ""}
                  onValueChange={(value) => setNewEmployee({ ...newEmployee, manager: value })}
                >
                  <SelectTrigger id="manager">
                    <SelectValue placeholder="Vorgesetzten auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Kein Vorgesetzter</SelectItem>
                    {employees.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id}>
                        {employee.name} ({employee.position})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Adresse</Label>
                <Textarea
                  id="address"
                  value={newEmployee.address || ""}
                  onChange={(e) => setNewEmployee({ ...newEmployee, address: e.target.value })}
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="emergencyContact">Notfallkontakt</Label>
                <Input
                  id="emergencyContact"
                  value={newEmployee.emergencyContact || ""}
                  onChange={(e) => setNewEmployee({ ...newEmployee, emergencyContact: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Abbrechen
              </Button>
              <Button onClick={handleAddEmployee}>Mitarbeiter hinzufügen</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1 md:max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Mitarbeiter suchen..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
                <span className="sr-only">Filter</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[200px]">
              <DropdownMenuLabel>Filter</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">Abteilung</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setDepartmentFilter(null)}>Alle Abteilungen</DropdownMenuItem>
              {departments.map((department) => (
                <DropdownMenuItem
                  key={department}
                  onClick={() => setDepartmentFilter(department)}
                  className={departmentFilter === department ? "bg-muted" : ""}
                >
                  {department}
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">Status</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setStatusFilter(null)}>Alle Status</DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setStatusFilter("Active")}
                className={statusFilter === "Active" ? "bg-muted" : ""}
              >
                Aktiv
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setStatusFilter("On Leave")}
                className={statusFilter === "On Leave" ? "bg-muted" : ""}
              >
                Beurlaubt
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setStatusFilter("Terminated")}
                className={statusFilter === "Terminated" ? "bg-muted" : ""}
              >
                Gekündigt
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Exportieren
          </Button>
          <Button variant="outline" size="sm">
            <Upload className="mr-2 h-4 w-4" />
            Importieren
          </Button>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Abteilung</TableHead>
              <TableHead>Position</TableHead>
              <TableHead>Eintrittsdatum</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Aktionen</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredEmployees.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  Keine Mitarbeiter gefunden
                </TableCell>
              </TableRow>
            ) : (
              filteredEmployees.map((employee) => (
                <TableRow key={employee.id}>
                  <TableCell className="font-medium">{employee.id}</TableCell>
                  <TableCell>{employee.name}</TableCell>
                  <TableCell>{employee.department}</TableCell>
                  <TableCell>{employee.position}</TableCell>
                  <TableCell>{formatDate(employee.joinDate)}</TableCell>
                  <TableCell>
                    <Badge
                      className={
                        employee.status === "Active"
                          ? "bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300"
                          : employee.status === "On Leave"
                            ? "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-300"
                            : "bg-red-100 text-red-800 hover:bg-red-100 dark:bg-red-900 dark:text-red-300"
                      }
                    >
                      {employee.status === "Active"
                        ? "Aktiv"
                        : employee.status === "On Leave"
                          ? "Beurlaubt"
                          : "Gekündigt"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Aktionen</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Aktionen</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => openViewDialog(employee)}>
                          <FileText className="mr-2 h-4 w-4" />
                          Anzeigen
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => openEditDialog(employee)}>
                          <Edit className="mr-2 h-4 w-4" />
                          Bearbeiten
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => openDeleteDialog(employee)}>
                          <Trash2 className="mr-2 h-4 w-4" />
                          Löschen
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <a href={`mailto:${employee.email}`}>
                            <Mail className="mr-2 h-4 w-4" />
                            E-Mail senden
                          </a>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Mitarbeiterdetails</DialogTitle>
          </DialogHeader>
          {currentEmployee && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Mitarbeiter-ID</h3>
                  <p className="text-base">{currentEmployee.id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                  <Badge
                    className={
                      currentEmployee.status === "Active"
                        ? "bg-green-100 text-green-800 hover:bg-green-100 dark:bg-green-900 dark:text-green-300"
                        : currentEmployee.status === "On Leave"
                          ? "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-300"
                          : "bg-red-100 text-red-800 hover:bg-red-100 dark:bg-red-900 dark:text-red-300"
                    }
                  >
                    {currentEmployee.status === "Active"
                      ? "Aktiv"
                      : currentEmployee.status === "On Leave"
                        ? "Beurlaubt"
                        : "Gekündigt"}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Name</h3>
                  <p className="text-base">{currentEmployee.name}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">E-Mail</h3>
                  <p className="text-base">
                    <a href={`mailto:${currentEmployee.email}`} className="text-blue-600 hover:underline">
                      {currentEmployee.email}
                    </a>
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Telefon</h3>
                  <p className="text-base">{currentEmployee.phone}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Eintrittsdatum</h3>
                  <p className="text-base">{formatDate(currentEmployee.joinDate)}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Abteilung</h3>
                  <p className="text-base">{currentEmployee.department}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Position</h3>
                  <p className="text-base">{currentEmployee.position}</p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Gehalt</h3>
                <p className="text-base">{formatCurrency(currentEmployee.salary)}</p>
              </div>

              {currentEmployee.manager && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Vorgesetzter</h3>
                  <p className="text-base">
                    {(employees || []).find((e) => e && e.id === currentEmployee?.manager)?.name ||
                      currentEmployee?.manager ||
                      ""}
                  </p>
                </div>
              )}

              {currentEmployee.address && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Adresse</h3>
                  <p className="text-base whitespace-pre-line">{currentEmployee.address}</p>
                </div>
              )}

              {currentEmployee.emergencyContact && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Notfallkontakt</h3>
                  <p className="text-base">{currentEmployee.emergencyContact}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Mitarbeiter bearbeiten</DialogTitle>
            <DialogDescription>Bearbeiten Sie die Details des Mitarbeiters.</DialogDescription>
          </DialogHeader>
          {currentEmployee && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Name</Label>
                  <Input
                    id="edit-name"
                    value={currentEmployee.name}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-email">E-Mail</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={currentEmployee.email}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, email: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-phone">Telefon</Label>
                  <Input
                    id="edit-phone"
                    value={currentEmployee.phone}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-joinDate">Eintrittsdatum</Label>
                  <Input
                    id="edit-joinDate"
                    type="date"
                    value={currentEmployee.joinDate}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, joinDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-department">Abteilung</Label>
                  <Select
                    value={currentEmployee.department}
                    onValueChange={(value) => setCurrentEmployee({ ...currentEmployee, department: value })}
                  >
                    <SelectTrigger id="edit-department">
                      <SelectValue placeholder="Abteilung auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Engineering">Engineering</SelectItem>
                      <SelectItem value="Marketing">Marketing</SelectItem>
                      <SelectItem value="Finance">Finance</SelectItem>
                      <SelectItem value="Human Resources">Human Resources</SelectItem>
                      <SelectItem value="Sales">Sales</SelectItem>
                      <SelectItem value="Operations">Operations</SelectItem>
                      <SelectItem value="IT">IT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-position">Position</Label>
                  <Input
                    id="edit-position"
                    value={currentEmployee.position}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, position: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-salary">Gehalt (€)</Label>
                  <Input
                    id="edit-salary"
                    type="number"
                    value={currentEmployee.salary}
                    onChange={(e) =>
                      setCurrentEmployee({ ...currentEmployee, salary: Number.parseFloat(e.target.value) || 0 })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-status">Status</Label>
                  <Select
                    value={currentEmployee.status}
                    onValueChange={(value) =>
                      setCurrentEmployee({ ...currentEmployee, status: value as "Active" | "On Leave" | "Terminated" })
                    }
                  >
                    <SelectTrigger id="edit-status">
                      <SelectValue placeholder="Status auswählen" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Active">Aktiv</SelectItem>
                      <SelectItem value="On Leave">Beurlaubt</SelectItem>
                      <SelectItem value="Terminated">Gekündigt</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-manager">Vorgesetzter</Label>
                <Select
                  value={currentEmployee.manager || ""}
                  onValueChange={(value) => setCurrentEmployee({ ...currentEmployee, manager: value })}
                >
                  <SelectTrigger id="edit-manager">
                    <SelectValue placeholder="Vorgesetzten auswählen" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Kein Vorgesetzter</SelectItem>
                    {(employees || [])
                      .filter((e) => e && e.id !== currentEmployee?.id)
                      .map(
                        (employee) =>
                          employee && (
                            <SelectItem key={employee.id || Math.random().toString()} value={employee.id || ""}>
                              {employee.name || ""} ({employee.position || ""})
                            </SelectItem>
                          ),
                      )}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-address">Adresse</Label>
                <Textarea
                  id="edit-address"
                  value={currentEmployee.address || ""}
                  onChange={(e) => setCurrentEmployee({ ...currentEmployee, address: e.target.value })}
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-emergencyContact">Notfallkontakt</Label>
                <Input
                  id="edit-emergencyContact"
                  value={currentEmployee.emergencyContact || ""}
                  onChange={(e) => setCurrentEmployee({ ...currentEmployee, emergencyContact: e.target.value })}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Abbrechen
            </Button>
            <Button onClick={handleEditEmployee}>Änderungen speichern</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mitarbeiter löschen</DialogTitle>
            <DialogDescription>
              Sind Sie sicher, dass Sie diesen Mitarbeiter löschen möchten? Diese Aktion kann nicht rückgängig gemacht
              werden.
            </DialogDescription>
          </DialogHeader>
          {currentEmployee && (
            <div className="py-4">
              <p>
                <strong>Mitarbeiter-ID:</strong> {currentEmployee.id}
              </p>
              <p>
                <strong>Name:</strong> {currentEmployee.name}
              </p>
              <p>
                <strong>Position:</strong> {currentEmployee.position}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Abbrechen
            </Button>
            <Button variant="destructive" onClick={handleDeleteEmployee}>
              Löschen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

