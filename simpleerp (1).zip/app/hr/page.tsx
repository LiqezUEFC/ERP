"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/components/ui/use-toast"
import { useData } from "@/contexts/data-context"

// Sample employees data
const initialEmployees = [
  {
    id: "EMP001",
    name: "John Doe",
    department: "Engineering",
    position: "Software Developer",
    joinDate: "2022-01-15",
    status: "Active",
    email: "john.doe@example.com",
    phone: "+1 234 567 890",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "EMP002",
    name: "Jane Smith",
    department: "Marketing",
    position: "Marketing Manager",
    joinDate: "2021-06-10",
    status: "Active",
    email: "jane.smith@example.com",
    phone: "+1 234 567 891",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "EMP003",
    name: "Robert Johnson",
    department: "Finance",
    position: "Financial Analyst",
    joinDate: "2022-03-22",
    status: "Active",
    email: "robert.johnson@example.com",
    phone: "+1 234 567 892",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "EMP004",
    name: "Emily Davis",
    department: "Human Resources",
    position: "HR Specialist",
    joinDate: "2021-11-05",
    status: "Active",
    email: "emily.davis@example.com",
    phone: "+1 234 567 893",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: "EMP005",
    name: "Michael Wilson",
    department: "Sales",
    position: "Sales Representative",
    joinDate: "2022-02-18",
    status: "On Leave",
    email: "michael.wilson@example.com",
    phone: "+1 234 567 894",
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

// Sample departments data
const initialDepartments = [
  {
    id: "DEP001",
    name: "Engineering",
    manager: "EMP001",
    employees: 12,
    budget: 500000,
    status: "Active",
  },
  {
    id: "DEP002",
    name: "Marketing",
    manager: "EMP002",
    employees: 8,
    budget: 300000,
    status: "Active",
  },
  {
    id: "DEP003",
    name: "Finance",
    manager: "EMP003",
    employees: 6,
    budget: 250000,
    status: "Active",
  },
  {
    id: "DEP004",
    name: "Human Resources",
    manager: "EMP004",
    employees: 4,
    budget: 200000,
    status: "Active",
  },
  {
    id: "DEP005",
    name: "Sales",
    manager: "EMP005",
    employees: 10,
    budget: 400000,
    status: "Active",
  },
]

// Sample leave requests data
const initialLeaveRequests = [
  {
    id: "LR001",
    employee: "EMP001",
    employeeName: "John Doe",
    type: "Vacation",
    startDate: "2023-04-10",
    endDate: "2023-04-15",
    days: 5,
    status: "Approved",
  },
  {
    id: "LR002",
    employee: "EMP002",
    employeeName: "Jane Smith",
    type: "Sick Leave",
    startDate: "2023-03-22",
    endDate: "2023-03-23",
    days: 2,
    status: "Approved",
  },
  {
    id: "LR003",
    employee: "EMP003",
    employeeName: "Robert Johnson",
    type: "Personal Leave",
    startDate: "2023-05-01",
    endDate: "2023-05-03",
    days: 3,
    status: "Pending",
  },
  {
    id: "LR004",
    employee: "EMP004",
    employeeName: "Emily Davis",
    type: "Vacation",
    startDate: "2023-06-15",
    endDate: "2023-06-25",
    days: 10,
    status: "Pending",
  },
  {
    id: "LR005",
    employee: "EMP005",
    employeeName: "Michael Wilson",
    type: "Sick Leave",
    startDate: "2023-03-15",
    endDate: "2023-03-20",
    days: 5,
    status: "Approved",
  },
]

export default function HRPage() {
  const { employees, addEmployee, updateEmployee, deleteEmployee, isLoading } = useData()
  const { toast } = useToast()
  
  const [activeTab, setActiveTab] = useState("employees")
  const [employeesList, setEmployeesList] = useState(initialEmployees)
  const [departmentsList, setDepartmentsList] = useState(initialDepartments)
  const [leaveRequestsList, setLeaveRequestsList] = useState(initialLeaveRequests)
  const [searchTerm, setSearchTerm] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState<string | null>(null)
  const [statusFilter, setStatusFilter] = useState<string | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [currentItem, setCurrentItem] = useState<any>(null)
  const [newEmployee, setNewEmployee] = useState({
    id: "",
    name: "",
    department: "",
    position: "",
    joinDate: new Date().toISOString().split("T")[0],
    status: "Active",
    email: "",
    phone: "",
    avatar: "/placeholder.svg?height=40&width=40",
  })
  const [newDepartment, setNewDepartment] = useState({
    id: "",
    name: "",
    manager: "",
    employees: 0,
    budget: 0,
    status: "Active",
  })
  const [newLeaveRequest, setNewLeaveRequest] = useState({
    id: "",
    employee: "",
    employeeName: "",
    type: "Vacation",
    startDate: new Date().toISOString().split("T")[0],
    endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    days: 7,
    status: "Pending",
  })

  // Get unique departments for filter
  const departments = [...new Set(employeesList.map(employee => employee.department))]

  // Apply filters based on active tab
  const getFilteredItems = () => {
    switch (activeTab) {
      case "employees":
        return employeesList.filter(
          (employee) =>
            (employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
              employee.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
              employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
              employee.id.toLowerCase().includes(searchTerm.toLowerCase())) &&
            (!departmentFilter || employee.department === departmentFilter) &&
            (!statusFilter || employee.status === statusFilter)
        )
      case "departments":
        return departmentsList.filter(
          (department) =>
            department.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            department.id.toLowerCase().includes(searchTerm.toLowerCase())
        )
      case "leave":
        return leaveRequestsList.filter(
          (request) =>
            request.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            request.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
            request.type.toLowerCase().includes(searchTerm.toLowerCase()) &&
            (!statusFilter || request.status === statusFilter)
        )
      default:
        return []
    }
  }

  const filteredItems = getFilteredItems()

  // Handle adding new items based on active tab
  const handleAddItem = () => {
    switch (activeTab) {
      case "employees":
        const employeeId = `EMP${String(employeesList.length + 1).padStart(3, "0")}`

        setEmployeesList([
          ...employeesList,
          {
            ...newEmployee,
            id: employeeId,
          },
        ])

        // Update department employee count
        if (newEmployee.department) {
          setDepartmentsList(
            departmentsList.map((dept) =>
              dept.name === newEmployee.department
                ? { ...dept, employees: dept.employees + 1 }
                : dept
            )
          )
        }

        setNewEmployee({
          id: "",
          name: "",
          department: "",
          position: "",
          joinDate: new Date().toISOString().split("T")[0],
          status: "Active",
          email: "",
          phone: "",
          avatar: "/placeholder.svg?height=40&width=40",
        })

        toast({
          title: "Employee added",
          description: "The employee has been added successfully.",
        })
        break

      case "departments":
        const departmentId = `DEP${String(departmentsList.length + 1).padStart(3, "0")}`

        setDepartmentsList([
          ...departmentsList,
          {
            ...newDepartment,
            id: departmentId,
          },
        ])

        setNewDepartment({
          id: "",
          name: "",
          manager: "",
          employees: 0,
          budget: 0,
          status: "Active",
        })

        toast({
          title: "Department added",
          description: "The department has been added successfully.",
        })
        break

      case "leave":
        const leaveRequestId = `LR${String(leaveRequestsList.length + 1).padStart(3, "0")}`
        const employee = employeesList.find(e => e.id === newLeaveRequest.employee)
        
        // Calculate days between start and end date
        const startDate = new Date(newLeaveRequest.startDate)
        const endDate = new Date(newLeaveRequest.endDate)
        const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1

        setLeaveRequestsList([
          ...leaveRequestsList,
          {
            ...newLeaveRequest,
            id: leaveRequestId,
            employeeName: employee ? employee.name : "",
            days,
          },
        ])

        setNewLeaveRequest({
          id: "",
          employee: "",
          employeeName: "",
          type: "Vacation",
          startDate: new Date().toISOString().split("T")[0],
          endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
          days: 7,
          status: "Pending",
        })

        toast({
          title: "Leave request submitted",
          description: "The leave request has been submitted successfully.",
        })
        break
    }

    setIsDialogOpen(false)
  }

  // Handle editing items based on active tab
  const handleEditItem = () => {
    if (currentItem) {
      switch (activeTab) {
        case "employees":
          // Check if department changed
          const oldEmployee = employeesList.find(e => e.id === currentItem.id)
          if (oldEmployee && oldEmployee.department !== currentItem.department) {
            // Update old department employee count
            setDepartmentsList(
              departmentsList.map((dept) =>
                dept.name === oldEmployee.department
                  ? { ...dept, employees: Math.max(0, dept.employees - 1) }
                  : dept
              )
            )
            
            // Update new department employee count
            setDepartmentsList(
              departmentsList.map((dept) =>
                dept.name === currentItem.department
                  ? { ...dept, employees: dept.employees + 1 }
                  : dept
              )
            )
          }
          
          setEmployeesList(
            employeesList.map((employee) => 
              employee.id === currentItem.id 
                ? { ...currentItem } 
                : employee
            )
          )
          
          toast({
            title: "Employee updated",
            description: "The employee has been updated successfully.",
          })
          break
          
        case "departments":
          setDepartmentsList(
            departmentsList.map((department) => 
              department.id === currentItem.id 
                ? { ...currentItem } 
                : department
            )
          )
          
          toast({
            title: "Department updated",
            description: "The department has been updated successfully.",
          })
          break
          
        case "leave":
          // Recalculate days if dates changed
          if (currentItem.startDate !== leaveRequestsList.find(r => r.id === currentItem.id)?.startDate ||
              currentItem.endDate !== leaveRequestsList.find(r => r.id === currentItem.id)?.endDate) {
            const startDate = new Date(currentItem.startDate)
            const endDate = new Date(currentItem.endDate)
            const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1
            currentItem.days = days
          }
          
          setLeaveRequestsList(
            leaveRequestsList.map((request) => 
              request.id === currentItem.id 
                ? { ...currentItem } 
                : request
            )
          )
          
          toast({
            title: "Leave request updated",
            description: "The leave request has been updated successfully.",
          })
          break
      }
      
      setIsEditDialogOpen(false)
    }
  }

  // Handle deleting items based on active tab
  const handleDeleteItem = () => {
    if (currentItem) {
      switch (activeTab) {
        case "employees":
          // Update department employee count
          setDepartmentsList(
            departmentsList.map((dept) =>
              dept.name === currentItem.department
                ? { ...dept, employees: Math.max(0, dept.employees - 1) }
                : dept
            )
          )
          
          setEmployeesList(employeesList.filter((employee) => employee.id !== currentItem.id))
          
          toast({
            title: "Employee deleted",
            description: "The employee has been deleted successfully.",
          })
          break
          
        case "departments":
          setDepartmentsList(departmentsList.filter((department) => department.id !== currentItem.id))
          
          toast({
            title: "Department deleted",
            description: "The department has been deleted successfully.",
          })
          break
          
        case "leave":
          setLeaveRequestsList(leaveRequestsList.filter((request) => request.id !== currentItem.id))
          
          toast({
            title: "Leave request deleted",
            description: "The leave request has been deleted successfully.",
          })
          break
      }
      
      setIsDeleteDialogOpen(false)
    }
  }

  const openEditDialog = (item) => {
    setCurrentItem({ ...item })
    setIsEditDialogOpen(true)
  }

  const openDeleteDialog = (item) => {
    setCurrentItem(item)
    setIsDeleteDialogOpen(true)
  }

  const openViewDialog = (item) => {
    setCurrentItem(item)
    setIsViewDialogOpen(true)
  }

  // Get dialog title and description based on active tab
  const getDialogInfo = () => {
    switch (activeTab) {
      case "employees":
        return {
          title: "Add New Employee",
          description: "Enter the details of the new employee.",
        }
      case "departments":
        return {
          title: "Add New Department",
          description: "Enter the details of the new department.",
        }
      case "leave":
        return {
          title: "Submit Leave Request",
          description: "Enter the details of your leave request.",
        }
      default:
        return {
          title: "Add New Item",
          description: "Enter the details of the new item.",
        }
    }
  }

  // Calculate summary data
  const totalEmployees = employeesList.length
  const activeEmployees = employeesList.filter(e => e.status === "Active").length
  const onLeaveEmployees = employeesList.filter(e => e.status === "On Leave").length
  const totalDepartments = departmentsList.length
  const totalBudget = departmentsList.reduce((sum, dept) => sum + dept.budget, 0)
  const pendingLeaveRequests = leaveRequestsList.filter(r => r.status === "Pending").length
  const approvedLeaveRequests = leaveRequestsList.filter(r => r.status === "Approved").length

  if (isLoading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-24" />
        </div>
        <Skeleton className="h-10 w-full" />
        <div className="grid gap-4 md:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-[500px] w-full" />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Human Resources</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              {activeTab === "employees" 
                ? "Add Employee" 
                : activeTab === "departments" 
                  ? "Add Department" 
                  : "Submit Leave Request"}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{getDialogInfo().title}</DialogTitle>
              <DialogDescription>{getDialogInfo().description}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              {activeTab === "employees" && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      Name
                    </Label>
                    <Input
                      id="name"
                      value={newEmployee.name}
                      onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="email" className="text-right">
                      Email
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={newEmployee.email}
                      onChange={(e) => setNewEmployee({ ...newEmployee, email: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="phone" className="text-right">
                      Phone
                    </Label>
                    <Input
                      id="phone"
                      value={newEmployee.phone}
                      onChange={(e) => setNewEmployee({ ...newEmployee, phone: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="department" className="text-right">
                      Department
                    </Label>
                    <Select value={newEmployee.department} onValueChange={(value) => setNewEmployee({ ...newEmployee, department: value })}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departmentsList.map((dept) => (
                          <SelectItem key={dept.id} value={dept.name}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="position" className="text-right">
                      Position
                    </Label>
                    <Input
                      id="position"
                      value={newEmployee.position}
                      onChange={(e) => setNewEmployee({ ...newEmployee, position: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="joinDate" className="text-right">
                      Join Date
                    </Label>
                    <Input
                      id="joinDate"
                      type="date"
                      value={newEmployee.joinDate}
                      onChange={(e) => setNewEmployee({ ...newEmployee, joinDate: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="status" className="text-right">
                      Status
                    </Label>
                    <Select value={newEmployee.status} onValueChange={(value) => setNewEmployee({ ...newEmployee, status: value })}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="On Leave">On Leave</SelectItem>
                        <SelectItem value="Terminated">Terminated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {activeTab === "departments" && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      Department Name
                    </Label>
                    <Input
                      id="name"
                      value={newDepartment.name}
                      onChange={(e) => setNewDepartment({ ...newDepartment, name: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="manager" className="text-right">
                      Manager
                    </Label>
                    <Select value={newDepart

