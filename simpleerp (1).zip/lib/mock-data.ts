// Generate mock data for the ERP system
export function generateMockData() {
  // Generate products
  const products = generateProducts(50)

  // Generate customers
  const customers = generateCustomers(30)

  // Generate suppliers
  const suppliers = generateSuppliers(15)

  // Generate sales orders
  const salesOrders = generateSalesOrders(25, customers, products)

  // Generate purchase orders
  const purchaseOrders = generatePurchaseOrders(20, suppliers, products)

  // Generate employees
  const employees = generateEmployees(20)

  // Generate transactions
  const accounts = generateAccounts(5)
  const transactions = generateTransactions(40, accounts)

  // Generate projects and tasks
  const projects = generateProjects(10, customers, employees)
  const tasks = generateTasks(30, projects, employees)

  return {
    products,
    customers,
    suppliers,
    salesOrders,
    purchaseOrders,
    employees,
    transactions,
    accounts,
    projects,
    tasks,
  }
}

// Helper function to generate a random date within a range
function randomDate(start: Date, end: Date) {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()))
}

// Helper function to generate a random integer within a range
function randomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Helper function to generate a random element from an array
function randomElement<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)]
}

// Generate mock products
function generateProducts(count: number) {
  const categories = ["Electronics", "Office Supplies", "Furniture", "Clothing", "Food", "Tools"]
  const statuses = ["In Stock", "Low Stock", "Out of Stock"]

  return Array.from({ length: count }, (_, i) => {
    const id = `PRD${String(i + 1).padStart(4, "0")}`
    const name = `Product ${i + 1}`
    const category = randomElement(categories)
    const quantity = randomInt(0, 100)
    const reorderLevel = randomInt(5, 20)
    const price = Number.parseFloat((Math.random() * 1000 + 10).toFixed(2))
    const cost = Number.parseFloat((price * 0.6).toFixed(2))

    let status: string
    if (quantity === 0) {
      status = "Out of Stock"
    } else if (quantity <= reorderLevel) {
      status = "Low Stock"
    } else {
      status = "In Stock"
    }

    return {
      id,
      name,
      category,
      subcategory: `${category} Subcategory ${randomInt(1, 3)}`,
      sku: `SKU-${id}`,
      price,
      cost,
      quantity,
      reorderLevel,
      supplier: `SUP${String(randomInt(1, 15)).padStart(4, "0")}`,
      status,
      location: `Warehouse ${randomInt(1, 3)}, Shelf ${randomInt(1, 20)}`,
      description: `This is a description for ${name}. It's a high-quality product in the ${category} category.`,
      imageUrl: `/placeholder.svg?height=200&width=200`,
      lastUpdated: randomDate(new Date(2023, 0, 1), new Date()).toISOString(),
    }
  })
}

// Generate mock customers
function generateCustomers(count: number) {
  const types = ["Individual", "Business"]
  const statuses = ["Active", "Inactive"]

  return Array.from({ length: count }, (_, i) => {
    const id = `CUS${String(i + 1).padStart(4, "0")}`
    const type = randomElement(types)
    const name = type === "Individual" ? `Customer ${i + 1}` : `Business ${i + 1} Ltd.`

    return {
      id,
      name,
      email: `customer${i + 1}@example.com`,
      phone: `+49 ${randomInt(100, 999)} ${randomInt(1000000, 9999999)}`,
      address: `Street ${randomInt(1, 100)}`,
      city: randomElement(["Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt"]),
      postalCode: `${randomInt(10000, 99999)}`,
      country: "Germany",
      status: randomElement(statuses),
      type,
      notes: `Notes for ${name}`,
      createdAt: randomDate(new Date(2022, 0, 1), new Date()).toISOString(),
    }
  })
}

// Generate mock suppliers
function generateSuppliers(count: number) {
  const statuses = ["Active", "Inactive"]
  const paymentTerms = ["Net 30", "Net 60", "Net 90", "Immediate"]

  return Array.from({ length: count }, (_, i) => {
    const id = `SUP${String(i + 1).padStart(4, "0")}`
    const name = `Supplier ${i + 1} GmbH`

    return {
      id,
      name,
      contactName: `Contact ${i + 1}`,
      email: `supplier${i + 1}@example.com`,
      phone: `+49 ${randomInt(100, 999)} ${randomInt(1000000, 9999999)}`,
      address: `Industrial Park ${randomInt(1, 50)}`,
      city: randomElement(["Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt"]),
      postalCode: `${randomInt(10000, 99999)}`,
      country: "Germany",
      status: randomElement(statuses),
      paymentTerms: randomElement(paymentTerms),
      notes: `Notes for ${name}`,
    }
  })
}

// Generate mock sales orders
function generateSalesOrders(count: number, customers: any[], products: any[]) {
  const statuses = ["Draft", "Processing", "Shipped", "Delivered", "Cancelled"]
  const paymentStatuses = ["Unpaid", "Partial", "Paid"]

  return Array.from({ length: count }, (_, i) => {
    const id = `SO${String(i + 1).padStart(4, "0")}`
    const customer = randomElement(customers)
    const date = randomDate(new Date(2023, 0, 1), new Date()).toISOString()
    const dueDate = new Date(new Date(date).getTime() + randomInt(7, 30) * 24 * 60 * 60 * 1000).toISOString()

    // Generate order items
    const itemCount = randomInt(1, 5)
    const items = Array.from({ length: itemCount }, () => {
      const product = randomElement(products)
      const quantity = randomInt(1, 10)
      const price = product.price
      const discount = Number.parseFloat((Math.random() * 0.2 * price).toFixed(2))
      const total = Number.parseFloat(((price - discount) * quantity).toFixed(2))

      return {
        productId: product.id,
        productName: product.name,
        quantity,
        price,
        discount,
        total,
      }
    })

    const total = items.reduce((sum, item) => sum + item.total, 0)

    return {
      id,
      customer: customer.id,
      customerName: customer.name,
      date,
      dueDate,
      items,
      total,
      status: randomElement(statuses),
      paymentStatus: randomElement(paymentStatuses),
      notes: `Notes for order ${id}`,
    }
  })
}

// Generate mock purchase orders
function generatePurchaseOrders(count: number, suppliers: any[], products: any[]) {
  const statuses = ["Draft", "Ordered", "Received", "Cancelled"]
  const paymentStatuses = ["Unpaid", "Partial", "Paid"]

  return Array.from({ length: count }, (_, i) => {
    const id = `PO${String(i + 1).padStart(4, "0")}`
    const supplier = randomElement(suppliers)
    const date = randomDate(new Date(2023, 0, 1), new Date()).toISOString()
    const expectedDelivery = new Date(new Date(date).getTime() + randomInt(7, 30) * 24 * 60 * 60 * 1000).toISOString()

    // Generate order items
    const itemCount = randomInt(1, 5)
    const items = Array.from({ length: itemCount }, () => {
      const product = randomElement(products)
      const quantity = randomInt(5, 50)
      const price = product.cost
      const total = Number.parseFloat((price * quantity).toFixed(2))

      return {
        productId: product.id,
        productName: product.name,
        quantity,
        price,
        total,
      }
    })

    const total = items.reduce((sum, item) => sum + item.total, 0)

    return {
      id,
      supplier: supplier.id,
      supplierName: supplier.name,
      date,
      expectedDelivery,
      items,
      total,
      status: randomElement(statuses),
      paymentStatus: randomElement(paymentStatuses),
      notes: `Notes for purchase order ${id}`,
    }
  })
}

// Generate mock employees
function generateEmployees(count: number) {
  const departments = ["Sales", "Marketing", "Finance", "HR", "IT", "Operations"]
  const positions = ["Manager", "Assistant", "Specialist", "Director", "Coordinator"]
  const statuses = ["Active", "On Leave", "Terminated"]

  return Array.from({ length: count }, (_, i) => {
    const id = `EMP${String(i + 1).padStart(4, "0")}`
    const name = `Employee ${i + 1}`
    const department = randomElement(departments)
    const position = `${department} ${randomElement(positions)}`

    return {
      id,
      name,
      email: `employee${i + 1}@example.com`,
      phone: `+49 ${randomInt(100, 999)} ${randomInt(1000000, 9999999)}`,
      department,
      position,
      joinDate: randomDate(new Date(2020, 0, 1), new Date(2023, 0, 1)).toISOString(),
      salary: randomInt(30000, 100000),
      status: randomElement(statuses),
      manager: i > 5 ? `EMP${String(randomInt(1, 5)).padStart(4, "0")}` : undefined,
      address: `Street ${randomInt(1, 100)}, ${randomElement(["Berlin", "Hamburg", "Munich"])}`,
      emergencyContact: `Emergency Contact ${i + 1}: +49 ${randomInt(100, 999)} ${randomInt(1000000, 9999999)}`,
    }
  })
}

// Generate mock accounts
function generateAccounts(count: number) {
  const types = ["Cash", "Bank", "Credit Card", "Other"]
  const currencies = ["EUR", "USD", "GBP"]

  return Array.from({ length: count }, (_, i) => {
    const id = `ACC${String(i + 1).padStart(4, "0")}`
    const type = randomElement(types)
    const name = `${type} Account ${i + 1}`

    return {
      id,
      name,
      type,
      balance: Number.parseFloat((Math.random() * 100000).toFixed(2)),
      currency: randomElement(currencies),
      notes: `Notes for ${name}`,
    }
  })
}

// Generate mock transactions
function generateTransactions(count: number, accounts: any[]) {
  const types = ["Income", "Expense"]
  const categories = {
    Income: ["Sales", "Investments", "Interest", "Other Income"],
    Expense: ["Rent", "Utilities", "Salaries", "Supplies", "Marketing", "Other Expenses"],
  }
  const paymentMethods = ["Cash", "Bank Transfer", "Credit Card", "PayPal"]

  return Array.from({ length: count }, (_, i) => {
    const id = `TRX${String(i + 1).padStart(4, "0")}`
    const type = randomElement(types)
    const account = randomElement(accounts)
    const date = randomDate(new Date(2023, 0, 1), new Date()).toISOString()

    return {
      id,
      date,
      description: `${type} Transaction ${i + 1}`,
      reference: `REF-${id}`,
      type,
      amount: Number.parseFloat((Math.random() * 5000 + 100).toFixed(2)),
      category: randomElement(categories[type]),
      account: account.id,
      paymentMethod: randomElement(paymentMethods),
      notes: `Notes for transaction ${id}`,
    }
  })
}

// Generate mock projects
function generateProjects(count: number, customers: any[], employees: any[]) {
  const statuses = ["Not Started", "In Progress", "On Hold", "Completed", "Cancelled"]

  return Array.from({ length: count }, (_, i) => {
    const id = `PRJ${String(i + 1).padStart(4, "0")}`
    const name = `Project ${i + 1}`
    const startDate = randomDate(new Date(2023, 0, 1), new Date(2023, 6, 1)).toISOString()
    const endDate = randomDate(new Date(2023, 6, 1), new Date(2024, 0, 1)).toISOString()

    // Assign random team members
    const teamSize = randomInt(2, 5)
    const team = Array.from({ length: teamSize }, () => randomElement(employees).id)

    return {
      id,
      name,
      description: `Description for ${name}`,
      startDate,
      endDate,
      status: randomElement(statuses),
      budget: randomInt(10000, 100000),
      manager: randomElement(employees).id,
      client: randomElement(customers).id,
      team,
    }
  })
}

// Generate mock tasks
function generateTasks(count: number, projects: any[], employees: any[]) {
  const statuses = ["To Do", "In Progress", "Review", "Completed"]
  const priorities = ["Low", "Medium", "High", "Urgent"]

  return Array.from({ length: count }, (_, i) => {
    const id = `TSK${String(i + 1).padStart(4, "0")}`
    const project = randomElement(projects)
    const name = `Task ${i + 1}`
    const startDate = randomDate(new Date(project.startDate), new Date(project.endDate)).toISOString()
    const dueDate = randomDate(new Date(startDate), new Date(project.endDate)).toISOString()

    return {
      id,
      projectId: project.id,
      name,
      description: `Description for ${name}`,
      assignedTo: randomElement(project.team),
      startDate,
      dueDate,
      status: randomElement(statuses),
      priority: randomElement(priorities),
      progress: randomInt(0, 100),
    }
  })
}

