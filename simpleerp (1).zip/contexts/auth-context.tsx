"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

type User = {
  id: string
  name: string
  email: string
  role: string
}

type AuthContextType = {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
}

const defaultUser: User = {
  id: "1",
  name: "Admin User",
  email: "admin@example.com",
  role: "admin",
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Check for existing session on mount
  useEffect(() => {
    const checkAuth = () => {
      try {
        // In a real app, this would verify the session with the server
        // For demo purposes, we'll just check localStorage
        const storedUser = localStorage.getItem("erp-user")

        if (storedUser) {
          setUser(JSON.parse(storedUser))
        } else {
          // Auto-login for demo purposes
          setUser(defaultUser)
          localStorage.setItem("erp-user", JSON.stringify(defaultUser))
        }
      } catch (error) {
        console.error("Auth check failed:", error)
        // Auto-login for demo purposes
        setUser(defaultUser)
      } finally {
        setIsLoading(false)
      }
    }

    // Only run in browser
    if (typeof window !== "undefined") {
      checkAuth()
    } else {
      setIsLoading(false)
    }
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // In a real app, this would validate credentials with the server
      // For demo purposes, we'll accept any login
      setUser(defaultUser)
      localStorage.setItem("erp-user", JSON.stringify(defaultUser))
      return true
    } catch (error) {
      console.error("Login failed:", error)
      return false
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("erp-user")
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

