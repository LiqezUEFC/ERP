"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { generateMockData } from "@/lib/mock-data"

// Define all the data types
export type Product = {
  id: string
  name: string
  category: string
  subcategory?: string
  sku: string
  price: number
  cost: number
  quantity: number
  reorderLevel: number
  supplier: string
  status: "In Stock" | "Low Stock" | "Out of Stock"
  location?: string
  description?: string
  imageUrl?: string
  lastUpdated: string
}

export type Customer = {
  id: string
  name: string
  email: string
  phone: string
  address: string
  city: string
  postalCode: string
  country: string
  status: "Active" | "Inactive"
  type: "Individual" | "Business"
  notes?: string
  createdAt: string
}

export type Supplier = {
  id: string
  name: string
  contactName: string
  email: string
  phone: string
  address: string
  city: string
  postalCode: string
  country: string
  status: "Active" | "Inactive"
  paymentTerms: string
  notes?: string
}

export type SalesOrder = {
  id: string
  customer: string
  customerName: string
  date: string
  dueDate: string
  items: SalesOrderItem[]
  total: number
  status: "Draft" | "Processing" | "Shipped" | "Delivered" | "Cancelled"
  paymentStatus: "Unpaid" | "Partial" | "Paid"
  notes?: string
}

export type SalesOrderItem = {
  productId: string
  productName: string
  quantity: number
  price: number
  discount: number
  total: number
}

export type PurchaseOrder = {
  id: string
  supplier: string
  supplierName: string
  date: string
  expectedDelivery: string
  items: PurchaseOrderItem[]
  total: number
  status: "Draft" | "Ordered" | "Received" | "Cancelled"
  paymentStatus: "Unpaid" | "Partial" | "Paid"
  notes?: string
}

export type PurchaseOrderItem = {
  productId: string
  productName: string
  quantity: number
  price: number
  total: number
}

export type Employee = {
  id: string
  name: string
  email: string
  phone: string
  department: string
  position: string
  joinDate: string
  salary: number
  status: "Active" | "On Leave" | "Terminated"
  manager?: string
  address?: string
  emergencyContact?: string
}

export type Transaction = {
  id: string
  date: string
  description: string
  reference?: string
  type: "Income" | "Expense"
  amount: number
  category: string
  account: string
  paymentMethod?: string
  notes?: string
}

export type Account = {
  id: string
  name: string
  type: "Cash" | "Bank" | "Credit Card" | "Other"
  balance: number
  currency: string
  notes?: string
}

export type Project = {
  id: string
  name: string
  description: string
  startDate: string
  endDate: string
  status: "Not Started" | "In Progress" | "On Hold" | "Completed" | "Cancelled"
  budget: number
  manager: string
  client: string
  team: string[]
}

export type Task = {
  id: string
  projectId: string
  name: string
  description: string
  assignedTo: string
  startDate: string
  dueDate: string
  status: "To Do" | "In Progress" | "Review" | "Completed"
  priority: "Low" | "Medium" | "High" | "Urgent"
  progress: number
}

type DataContextType = {
  data: any
  loading: boolean
  error: string | null
  resetData: () => void
  addItem: (category: string, item: any) => void
  updateItem: (category: string, id: string, item: any) => void
  deleteItem: (category: string, id: string) => void
}

const DataContext = createContext<DataContextType | undefined>(undefined)

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Load or initialize data
  useEffect(() => {
    const loadData = () => {
      try {
        // Try to load from localStorage
        const storedData = localStorage.getItem("erp-data")

        if (storedData) {
          setData(JSON.parse(storedData))
        } else {
          // Generate mock data if no stored data exists
          const mockData = generateMockData()
          setData(mockData)
          localStorage.setItem("erp-data", JSON.stringify(mockData))
        }
      } catch (err) {
        console.error("Failed to load data:", err)
        setError("Failed to load data. Using default data.")

        // Fallback to mock data
        const mockData = generateMockData()
        setData(mockData)
        try {
          localStorage.setItem("erp-data", JSON.stringify(mockData))
        } catch (storageErr) {
          console.error("Failed to store data:", storageErr)
        }
      } finally {
        setLoading(false)
      }
    }

    // Only run in browser environment
    if (typeof window !== "undefined") {
      loadData()
    } else {
      setLoading(false)
    }
  }, [])

  // Reset data to initial state
  const resetData = () => {
    const mockData = generateMockData()
    setData(mockData)
    try {
      localStorage.setItem("erp-data", JSON.stringify(mockData))
    } catch (err) {
      console.error("Failed to store reset data:", err)
      setError("Failed to reset data.")
    }
  }

  // Add a new item to a category
  const addItem = (category: string, item: any) => {
    if (!data || !data[category]) {
      setError(`Category ${category} does not exist`)
      return
    }

    const newData = {
      ...data,
      [category]: [...data[category], item],
    }

    setData(newData)
    try {
      localStorage.setItem("erp-data", JSON.stringify(newData))
    } catch (err) {
      console.error("Failed to store updated data:", err)
      setError("Failed to save new item.")
    }
  }

  // Update an existing item
  const updateItem = (category: string, id: string, updatedItem: any) => {
    if (!data || !data[category]) {
      setError(`Category ${category} does not exist`)
      return
    }

    const newData = {
      ...data,
      [category]: data[category].map((item: any) => (item.id === id ? { ...item, ...updatedItem } : item)),
    }

    setData(newData)
    try {
      localStorage.setItem("erp-data", JSON.stringify(newData))
    } catch (err) {
      console.error("Failed to store updated data:", err)
      setError("Failed to update item.")
    }
  }

  // Delete an item
  const deleteItem = (category: string, id: string) => {
    if (!data || !data[category]) {
      setError(`Category ${category} does not exist`)
      return
    }

    const newData = {
      ...data,
      [category]: data[category].filter((item: any) => item.id !== id),
    }

    setData(newData)
    try {
      localStorage.setItem("erp-data", JSON.stringify(newData))
    } catch (err) {
      console.error("Failed to store updated data:", err)
      setError("Failed to delete item.")
    }
  }

  return (
    <DataContext.Provider
      value={{
        data,
        loading,
        error,
        resetData,
        addItem,
        updateItem,
        deleteItem,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider")
  }
  return context
}

